import database from '../utils/database.js';

class TechnologyService {
  // Get all technologies with related data
  async getAllTechnologies() {
    try {
      const technologies = database.executeCustomQuery(`
        SELECT t.*
        FROM technologies t
        ORDER BY t.name
      `);

      // Populate related data for each technology
      for (const tech of technologies) {
        // Get teams
        const teams = database.read('technology_teams', { technology_id: tech.id });
        tech.teams = teams.map(t => t.team);
        
        // Get business functions
        const businessFunctions = database.read('technology_business_functions', { technology_id: tech.id });
        tech.businessFunctions = businessFunctions.map(bf => bf.business_function);
        
        // Get dependencies
        const dependsOn = database.read('technology_dependencies', { 
          technology_id: tech.id, 
          dependency_type: 'dependsOn' 
        });
        const usedBy = database.read('technology_dependencies', { 
          technology_id: tech.id, 
          dependency_type: 'usedBy' 
        });
        
        tech.dependencies = {
          dependsOn: dependsOn.map(d => d.dependency_name),
          usedBy: usedBy.map(d => d.dependency_name)
        };
        
        // Get history
        tech.history = database.read('technology_history', { technology_id: tech.id }, {
          orderBy: 'date',
          orderDirection: 'DESC'
        });
      }

      return technologies;
    } catch (error) {
      console.error('Error fetching technologies:', error);
      throw error;
    }
  }

  // Get technology by ID
  async getTechnologyById(technologyId) {
    try {
      const technology = database.read('technologies', { id: technologyId }, { single: true });
      
      if (!technology) {
        return null;
      }

      // Populate related data
      const teams = database.read('technology_teams', { technology_id: technologyId });
      technology.teams = teams.map(t => t.team);
      
      const businessFunctions = database.read('technology_business_functions', { technology_id: technologyId });
      technology.businessFunctions = businessFunctions.map(bf => bf.business_function);
      
      const dependsOn = database.read('technology_dependencies', { 
        technology_id: technologyId, 
        dependency_type: 'dependsOn' 
      });
      const usedBy = database.read('technology_dependencies', { 
        technology_id: technologyId, 
        dependency_type: 'usedBy' 
      });
      
      technology.dependencies = {
        dependsOn: dependsOn.map(d => d.dependency_name),
        usedBy: usedBy.map(d => d.dependency_name)
      };
      
      technology.history = database.read('technology_history', { technology_id: technologyId }, {
        orderBy: 'date',
        orderDirection: 'DESC'
      });

      return technology;
    } catch (error) {
      console.error('Error fetching technology by ID:', error);
      throw error;
    }
  }

  // Create new technology
  async createTechnology(technologyData) {
    try {
      const newTechnology = {
        name: technologyData.name,
        category: technologyData.category || '',
        version: technologyData.version || '',
        vendor: technologyData.vendor || '',
        license_type: technologyData.licenseType || '',
        support_level: technologyData.supportLevel || '',
        cost_center: technologyData.costCenter || '',
        installation_date: technologyData.installationDate || null,
        end_of_life: technologyData.endOfLife || null,
        last_updated: new Date().toISOString(),
        updated_by: technologyData.updatedBy || 'System',
        description: technologyData.description || '',
        status: technologyData.status || 'Development'
      };

      const technology = database.create('technologies', newTechnology);

      // Add teams if provided
      if (technologyData.teams && technologyData.teams.length > 0) {
        for (const team of technologyData.teams) {
          database.create('technology_teams', {
            technology_id: technology.id,
            team: team
          });
        }
      }

      // Add business functions if provided
      if (technologyData.businessFunctions && technologyData.businessFunctions.length > 0) {
        for (const businessFunction of technologyData.businessFunctions) {
          database.create('technology_business_functions', {
            technology_id: technology.id,
            business_function: businessFunction
          });
        }
      }

      // Add dependencies if provided
      if (technologyData.dependencies) {
        if (technologyData.dependencies.dependsOn) {
          for (const dependency of technologyData.dependencies.dependsOn) {
            database.create('technology_dependencies', {
              technology_id: technology.id,
              dependency_name: dependency,
              dependency_type: 'dependsOn'
            });
          }
        }
        
        if (technologyData.dependencies.usedBy) {
          for (const dependency of technologyData.dependencies.usedBy) {
            database.create('technology_dependencies', {
              technology_id: technology.id,
              dependency_name: dependency,
              dependency_type: 'usedBy'
            });
          }
        }
      }

      // Add initial history entry
      database.create('technology_history', {
        technology_id: technology.id,
        action: 'Created',
        description: `Technology ${technology.name} created`,
        date: new Date().toISOString(),
        user: technologyData.updatedBy || 'System'
      });

      return await this.getTechnologyById(technology.id);
    } catch (error) {
      console.error('Error creating technology:', error);
      throw error;
    }
  }

  // Update technology
  async updateTechnology(technologyId, updates) {
    try {
      const technologyUpdates = {
        name: updates.name,
        category: updates.category,
        version: updates.version,
        vendor: updates.vendor,
        license_type: updates.licenseType,
        support_level: updates.supportLevel,
        cost_center: updates.costCenter,
        installation_date: updates.installationDate,
        end_of_life: updates.endOfLife,
        last_updated: new Date().toISOString(),
        updated_by: updates.updatedBy || 'System',
        description: updates.description,
        status: updates.status
      };

      // Remove undefined values
      Object.keys(technologyUpdates).forEach(key => 
        technologyUpdates[key] === undefined && delete technologyUpdates[key]
      );

      const result = database.update('technologies', technologyId, technologyUpdates);

      // Update teams if provided
      if (updates.teams) {
        database.getDB().prepare('DELETE FROM technology_teams WHERE technology_id = ?').run(technologyId);
        for (const team of updates.teams) {
          database.create('technology_teams', {
            technology_id: technologyId,
            team: team
          });
        }
      }

      // Update business functions if provided
      if (updates.businessFunctions) {
        database.getDB().prepare('DELETE FROM technology_business_functions WHERE technology_id = ?').run(technologyId);
        for (const businessFunction of updates.businessFunctions) {
          database.create('technology_business_functions', {
            technology_id: technologyId,
            business_function: businessFunction
          });
        }
      }

      // Update dependencies if provided
      if (updates.dependencies) {
        database.getDB().prepare('DELETE FROM technology_dependencies WHERE technology_id = ?').run(technologyId);
        
        if (updates.dependencies.dependsOn) {
          for (const dependency of updates.dependencies.dependsOn) {
            database.create('technology_dependencies', {
              technology_id: technologyId,
              dependency_name: dependency,
              dependency_type: 'dependsOn'
            });
          }
        }
        
        if (updates.dependencies.usedBy) {
          for (const dependency of updates.dependencies.usedBy) {
            database.create('technology_dependencies', {
              technology_id: technologyId,
              dependency_name: dependency,
              dependency_type: 'usedBy'
            });
          }
        }
      }

      // Add history entry for update
      if (result) {
        database.create('technology_history', {
          technology_id: technologyId,
          action: 'Updated',
          description: `Technology updated`,
          date: new Date().toISOString(),
          user: updates.updatedBy || 'System'
        });
      }

      return result;
    } catch (error) {
      console.error('Error updating technology:', error);
      throw error;
    }
  }

  // Delete technology
  async deleteTechnology(technologyId) {
    try {
      return database.delete('technologies', technologyId);
    } catch (error) {
      console.error('Error deleting technology:', error);
      throw error;
    }
  }

  // Search technologies
  async searchTechnologies(query, filters = {}) {
    try {
      let sql = `
        SELECT DISTINCT t.*
        FROM technologies t
        LEFT JOIN technology_teams tt ON t.id = tt.technology_id
        LEFT JOIN technology_business_functions tbf ON t.id = tbf.technology_id
        WHERE 1=1
      `;
      const params = [];

      // Add search query
      if (query) {
        sql += ` AND (
          LOWER(t.name) LIKE ? OR 
          LOWER(t.vendor) LIKE ? OR 
          LOWER(t.description) LIKE ? OR
          LOWER(t.category) LIKE ?
        )`;
        const searchTerm = `%${query.toLowerCase()}%`;
        params.push(searchTerm, searchTerm, searchTerm, searchTerm);
      }

      // Add filters
      if (filters.teams && filters.teams.length > 0) {
        const teamPlaceholders = filters.teams.map(() => '?').join(',');
        sql += ` AND tt.team IN (${teamPlaceholders})`;
        params.push(...filters.teams);
      }

      if (filters.status && filters.status.length > 0) {
        const statusPlaceholders = filters.status.map(() => '?').join(',');
        sql += ` AND t.status IN (${statusPlaceholders})`;
        params.push(...filters.status);
      }

      if (filters.categories && filters.categories.length > 0) {
        const categoryPlaceholders = filters.categories.map(() => '?').join(',');
        sql += ` AND t.category IN (${categoryPlaceholders})`;
        params.push(...filters.categories);
      }

      if (filters.businessFunctions && filters.businessFunctions.length > 0) {
        const bfPlaceholders = filters.businessFunctions.map(() => '?').join(',');
        sql += ` AND tbf.business_function IN (${bfPlaceholders})`;
        params.push(...filters.businessFunctions);
      }

      sql += ` ORDER BY t.name`;

      const technologies = database.executeCustomQuery(sql, params);

      // Populate related data for each technology
      for (const tech of technologies) {
        const teams = database.read('technology_teams', { technology_id: tech.id });
        tech.teams = teams.map(t => t.team);
        
        const businessFunctions = database.read('technology_business_functions', { technology_id: tech.id });
        tech.businessFunctions = businessFunctions.map(bf => bf.business_function);
        
        const dependsOn = database.read('technology_dependencies', { 
          technology_id: tech.id, 
          dependency_type: 'dependsOn' 
        });
        const usedBy = database.read('technology_dependencies', { 
          technology_id: tech.id, 
          dependency_type: 'usedBy' 
        });
        
        tech.dependencies = {
          dependsOn: dependsOn.map(d => d.dependency_name),
          usedBy: usedBy.map(d => d.dependency_name)
        };
        
        tech.history = database.read('technology_history', { technology_id: tech.id }, {
          orderBy: 'date',
          orderDirection: 'DESC',
          limit: 5
        });
      }

      return technologies;
    } catch (error) {
      console.error('Error searching technologies:', error);
      throw error;
    }
  }

  // Get filter options
  async getFilterOptions() {
    try {
      const categories = database.executeCustomQuery(`
        SELECT DISTINCT category FROM technologies WHERE category IS NOT NULL AND category != '' ORDER BY category
      `);

      const teams = database.executeCustomQuery(`
        SELECT DISTINCT team FROM technology_teams ORDER BY team
      `);

      const statuses = database.executeCustomQuery(`
        SELECT DISTINCT status FROM technologies WHERE status IS NOT NULL AND status != '' ORDER BY status
      `);

      const businessFunctions = database.executeCustomQuery(`
        SELECT DISTINCT business_function FROM technology_business_functions ORDER BY business_function
      `);

      const vendors = database.executeCustomQuery(`
        SELECT DISTINCT vendor FROM technologies WHERE vendor IS NOT NULL AND vendor != '' ORDER BY vendor
      `);

      return {
        categories: categories.map(c => c.category),
        teams: teams.map(t => t.team),
        statuses: statuses.map(s => s.status),
        businessFunctions: businessFunctions.map(bf => bf.business_function),
        vendors: vendors.map(v => v.vendor)
      };
    } catch (error) {
      console.error('Error getting filter options:', error);
      throw error;
    }
  }

  // Get technology statistics
  async getStatistics() {
    try {
      const stats = database.executeCustomQuery(`
        SELECT 
          COUNT(*) as total_technologies,
          COUNT(CASE WHEN status = 'Production' THEN 1 END) as production_count,
          COUNT(CASE WHEN status = 'Development' THEN 1 END) as development_count,
          COUNT(CASE WHEN status = 'Planned' THEN 1 END) as planned_count,
          COUNT(CASE WHEN status = 'Deprecated' THEN 1 END) as deprecated_count
        FROM technologies
      `)[0];

      const categoryCounts = database.executeCustomQuery(`
        SELECT category, COUNT(*) as count
        FROM technologies
        WHERE category IS NOT NULL AND category != ''
        GROUP BY category
        ORDER BY count DESC
      `);

      return {
        totalTechnologies: stats.total_technologies,
        productionCount: stats.production_count,
        developmentCount: stats.development_count,
        plannedCount: stats.planned_count,
        deprecatedCount: stats.deprecated_count,
        categoryCounts: categoryCounts
      };
    } catch (error) {
      console.error('Error getting technology statistics:', error);
      throw error;
    }
  }

  // Get team-technology matrix data
  async getTeamTechnologyMatrix() {
    try {
      const matrixData = database.executeCustomQuery(`
        SELECT 
          tt.team,
          t.category,
          COUNT(*) as count
        FROM technology_teams tt
        JOIN technologies t ON tt.technology_id = t.id
        WHERE tt.team IS NOT NULL AND t.category IS NOT NULL
        GROUP BY tt.team, t.category
        ORDER BY tt.team, t.category
      `);

      return matrixData;
    } catch (error) {
      console.error('Error getting team-technology matrix:', error);
      throw error;
    }
  }

  // Bulk operations
  async bulkUpdateTechnologies(technologyIds, updates) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const techId of technologyIds) {
          const updateData = {
            ...updates,
            last_updated: new Date().toISOString()
          };
          database.update('technologies', techId, updateData);
          
          // Add history entry
          database.create('technology_history', {
            technology_id: techId,
            action: 'Bulk Updated',
            description: `Bulk update applied`,
            date: new Date().toISOString(),
            user: updates.updatedBy || 'System'
          });
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk update:', error);
      throw error;
    }
  }

  async bulkDeleteTechnologies(technologyIds) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const techId of technologyIds) {
          database.delete('technologies', techId);
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk delete:', error);
      throw error;
    }
  }

  // Add history entry
  async addHistoryEntry(technologyId, historyData) {
    try {
      return database.create('technology_history', {
        technology_id: technologyId,
        action: historyData.action,
        description: historyData.description,
        date: historyData.date || new Date().toISOString(),
        user: historyData.user || 'System'
      });
    } catch (error) {
      console.error('Error adding history entry:', error);
      throw error;
    }
  }
}

export default new TechnologyService();