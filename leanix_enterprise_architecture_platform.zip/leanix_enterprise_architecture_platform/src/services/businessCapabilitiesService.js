import database from '../utils/database.js';

class BusinessCapabilitiesService {
  // Get all organizational data with hierarchical structure
  async getOrganizationalData() {
    try {
      // Get divisions with related data
      const divisions = database.executeCustomQuery(`
        SELECT 
          d.*,
          COUNT(DISTINCT g.id) as group_count,
          COUNT(DISTINCT t.id) as team_count
        FROM divisions d
        LEFT JOIN groups g ON d.id = g.division_id
        LEFT JOIN teams t ON g.id = t.group_id
        GROUP BY d.id
        ORDER BY d.name
      `);

      // Build hierarchical structure
      const organizationalData = [];

      for (const division of divisions) {
        // Get groups for this division
        const groups = database.executeCustomQuery(`
          SELECT 
            g.*,
            COUNT(t.id) as team_count
          FROM groups g
          LEFT JOIN teams t ON g.id = t.group_id
          WHERE g.division_id = ?
          GROUP BY g.id
          ORDER BY g.name
        `, [division.id]);

        const divisionData = {
          id: division.id,
          name: division.name,
          type: division.type,
          count: division.count,
          status: division.status,
          description: division.description,
          statistics: {
            totalFunctions: division.total_functions,
            activeTeams: division.active_teams,
            applications: division.applications,
            processes: division.processes
          },
          children: []
        };

        // Add groups to division
        for (const group of groups) {
          // Get teams for this group
          const teams = database.executeCustomQuery(`
            SELECT t.*
            FROM teams t
            WHERE t.group_id = ?
            ORDER BY t.name
          `, [group.id]);

          const groupData = {
            id: group.id,
            name: group.name,
            type: group.type,
            count: group.count,
            children: []
          };

          // Add teams to group
          for (const team of teams) {
            // Get team assignments
            const teamAssignments = database.read('team_assignments', { team_id: team.id });
            
            // Get business processes
            const businessProcesses = database.read('business_processes', { team_id: team.id });

            const teamData = {
              id: team.id,
              name: team.name,
              type: team.type,
              abbreviation: team.abbreviation,
              count: team.count,
              teamAssignments: teamAssignments || [],
              businessProcesses: businessProcesses || [],
              applicationLinkages: [], // Will be populated from applications service
              relationships: [] // Will be populated from relationships service
            };

            groupData.children.push(teamData);
          }

          divisionData.children.push(groupData);
        }

        organizationalData.push(divisionData);
      }

      return organizationalData;
    } catch (error) {
      console.error('Error fetching organizational data:', error);
      throw error;
    }
  }

  // Create new division
  async createDivision(divisionData) {
    try {
      const newDivision = {
        id: divisionData.id || `div-${Date.now()}`,
        name: divisionData.name,
        type: 'division',
        count: divisionData.count || 0,
        status: divisionData.status || 'active',
        description: divisionData.description || '',
        total_functions: divisionData.totalFunctions || 0,
        active_teams: divisionData.activeTeams || 0,
        applications: divisionData.applications || 0,
        processes: divisionData.processes || 0
      };

      return database.create('divisions', newDivision);
    } catch (error) {
      console.error('Error creating division:', error);
      throw error;
    }
  }

  // Create new group
  async createGroup(groupData) {
    try {
      const newGroup = {
        id: groupData.id || `group-${Date.now()}`,
        name: groupData.name,
        type: 'group',
        count: groupData.count || 0,
        division_id: groupData.divisionId
      };

      return database.create('groups', newGroup);
    } catch (error) {
      console.error('Error creating group:', error);
      throw error;
    }
  }

  // Create new team
  async createTeam(teamData) {
    try {
      const newTeam = {
        id: teamData.id || `team-${Date.now()}`,
        name: teamData.name,
        type: 'team',
        abbreviation: teamData.abbreviation,
        count: teamData.count || 0,
        group_id: teamData.groupId
      };

      const team = database.create('teams', newTeam);

      // Add team assignments if provided
      if (teamData.teamAssignments && teamData.teamAssignments.length > 0) {
        for (const assignment of teamData.teamAssignments) {
          database.create('team_assignments', {
            team_id: team.id,
            team: assignment.team,
            role: assignment.role,
            members: assignment.members
          });
        }
      }

      // Add business processes if provided
      if (teamData.businessProcesses && teamData.businessProcesses.length > 0) {
        for (const process of teamData.businessProcesses) {
          database.create('business_processes', {
            team_id: team.id,
            name: process.name,
            category: process.category,
            criticality: process.criticality
          });
        }
      }

      return team;
    } catch (error) {
      console.error('Error creating team:', error);
      throw error;
    }
  }

  // Update division
  async updateDivision(divisionId, updates) {
    try {
      return database.update('divisions', divisionId, updates);
    } catch (error) {
      console.error('Error updating division:', error);
      throw error;
    }
  }

  // Update group
  async updateGroup(groupId, updates) {
    try {
      return database.update('groups', groupId, updates);
    } catch (error) {
      console.error('Error updating group:', error);
      throw error;
    }
  }

  // Update team
  async updateTeam(teamId, updates) {
    try {
      const result = database.update('teams', teamId, updates);

      // Update team assignments if provided
      if (updates.teamAssignments) {
        // Delete existing assignments
        database.getDB().prepare('DELETE FROM team_assignments WHERE team_id = ?').run(teamId);
        
        // Add new assignments
        for (const assignment of updates.teamAssignments) {
          database.create('team_assignments', {
            team_id: teamId,
            team: assignment.team,
            role: assignment.role,
            members: assignment.members
          });
        }
      }

      // Update business processes if provided
      if (updates.businessProcesses) {
        // Delete existing processes
        database.getDB().prepare('DELETE FROM business_processes WHERE team_id = ?').run(teamId);
        
        // Add new processes
        for (const process of updates.businessProcesses) {
          database.create('business_processes', {
            team_id: teamId,
            name: process.name,
            category: process.category,
            criticality: process.criticality
          });
        }
      }

      return result;
    } catch (error) {
      console.error('Error updating team:', error);
      throw error;
    }
  }

  // Delete division (cascades to groups and teams)
  async deleteDivision(divisionId) {
    try {
      return database.delete('divisions', divisionId);
    } catch (error) {
      console.error('Error deleting division:', error);
      throw error;
    }
  }

  // Delete group (cascades to teams)
  async deleteGroup(groupId) {
    try {
      return database.delete('groups', groupId);
    } catch (error) {
      console.error('Error deleting group:', error);
      throw error;
    }
  }

  // Delete team (cascades to assignments and processes)
  async deleteTeam(teamId) {
    try {
      return database.delete('teams', teamId);
    } catch (error) {
      console.error('Error deleting team:', error);
      throw error;
    }
  }

  // Search functionality
  async searchNodes(query) {
    try {
      const searchTerm = `%${query.toLowerCase()}%`;
      
      const results = database.executeCustomQuery(`
        SELECT 'division' as type, id, name, description FROM divisions 
        WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ?
        UNION ALL
        SELECT 'group' as type, id, name, NULL as description FROM groups 
        WHERE LOWER(name) LIKE ?
        UNION ALL
        SELECT 'team' as type, id, name, NULL as description FROM teams 
        WHERE LOWER(name) LIKE ?
        ORDER BY name
      `, [searchTerm, searchTerm, searchTerm, searchTerm]);

      return results;
    } catch (error) {
      console.error('Error searching nodes:', error);
      throw error;
    }
  }

  // Get statistics
  async getStatistics() {
    try {
      const stats = database.executeCustomQuery(`
        SELECT 
          (SELECT COUNT(*) FROM divisions) as total_divisions,
          (SELECT COUNT(*) FROM groups) as total_groups,
          (SELECT COUNT(*) FROM teams) as total_teams,
          (SELECT SUM(total_functions) FROM divisions) as total_functions,
          (SELECT COUNT(*) FROM business_processes) as total_processes
      `)[0];

      return {
        totalDivisions: stats.total_divisions,
        totalGroups: stats.total_groups,
        totalTeams: stats.total_teams,
        totalFunctions: stats.total_functions,
        totalProcesses: stats.total_processes
      };
    } catch (error) {
      console.error('Error getting statistics:', error);
      throw error;
    }
  }

  // Bulk operations
  async bulkUpdateTeams(teamIds, updates) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const teamId of teamIds) {
          database.update('teams', teamId, updates);
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk update:', error);
      throw error;
    }
  }

  async bulkDeleteTeams(teamIds) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const teamId of teamIds) {
          database.delete('teams', teamId);
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk delete:', error);
      throw error;
    }
  }
}

export default new BusinessCapabilitiesService();