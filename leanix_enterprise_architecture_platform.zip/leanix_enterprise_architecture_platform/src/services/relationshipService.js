import database from '../utils/database.js';

class RelationshipService {
  // Create relationship between any two entities
  async createRelationship(relationshipData) {
    try {
      const newRelationship = {
        source_type: relationshipData.sourceType, // 'application', 'technology', 'security', 'business'
        source_id: relationshipData.sourceId,
        target_type: relationshipData.targetType,
        target_id: relationshipData.targetId,
        relationship_type: relationshipData.relationshipType, // 'depends_on', 'uses', 'secures', 'supports', etc.
        strength: relationshipData.strength || 0 // 0-100 strength indicator
      };

      return database.create('relationships', newRelationship);
    } catch (error) {
      console.error('Error creating relationship:', error);
      throw error;
    }
  }

  // Get all relationships for a specific entity
  async getRelationshipsForEntity(entityType, entityId) {
    try {
      // Get relationships where entity is source
      const outgoingRelationships = database.executeCustomQuery(`
        SELECT r.*, 
               CASE 
                 WHEN r.target_type = 'application' THEN a.name
                 WHEN r.target_type = 'technology' THEN t.name
                 WHEN r.target_type = 'security' THEN sc.name
                 WHEN r.target_type = 'business' THEN COALESCE(d.name, g.name, te.name)
               END as target_name
        FROM relationships r
        LEFT JOIN applications a ON r.target_type = 'application' AND r.target_id = a.id
        LEFT JOIN technologies t ON r.target_type = 'technology' AND r.target_id = CAST(t.id AS TEXT)
        LEFT JOIN security_components sc ON r.target_type = 'security' AND r.target_id = CAST(sc.id AS TEXT)
        LEFT JOIN divisions d ON r.target_type = 'business' AND r.target_id = d.id
        LEFT JOIN groups g ON r.target_type = 'business' AND r.target_id = g.id
        LEFT JOIN teams te ON r.target_type = 'business' AND r.target_id = te.id
        WHERE r.source_type = ? AND r.source_id = ?
      `, [entityType, entityId]);

      // Get relationships where entity is target
      const incomingRelationships = database.executeCustomQuery(`
        SELECT r.*,
               CASE 
                 WHEN r.source_type = 'application' THEN a.name
                 WHEN r.source_type = 'technology' THEN t.name
                 WHEN r.source_type = 'security' THEN sc.name
                 WHEN r.source_type = 'business' THEN COALESCE(d.name, g.name, te.name)
               END as source_name
        FROM relationships r
        LEFT JOIN applications a ON r.source_type = 'application' AND r.source_id = a.id
        LEFT JOIN technologies t ON r.source_type = 'technology' AND r.source_id = CAST(t.id AS TEXT)
        LEFT JOIN security_components sc ON r.source_type = 'security' AND r.source_id = CAST(sc.id AS TEXT)
        LEFT JOIN divisions d ON r.source_type = 'business' AND r.source_id = d.id
        LEFT JOIN groups g ON r.source_type = 'business' AND r.source_id = g.id
        LEFT JOIN teams te ON r.source_type = 'business' AND r.source_id = te.id
        WHERE r.target_type = ? AND r.target_id = ?
      `, [entityType, entityId]);

      return {
        outgoing: outgoingRelationships,
        incoming: incomingRelationships
      };
    } catch (error) {
      console.error('Error getting relationships for entity:', error);
      throw error;
    }
  }

  // Get all relationships with entity names
  async getAllRelationships() {
    try {
      const relationships = database.executeCustomQuery(`
        SELECT r.*,
               CASE 
                 WHEN r.source_type = 'application' THEN a1.name
                 WHEN r.source_type = 'technology' THEN t1.name
                 WHEN r.source_type = 'security' THEN sc1.name
                 WHEN r.source_type = 'business' THEN COALESCE(d1.name, g1.name, te1.name)
               END as source_name,
               CASE 
                 WHEN r.target_type = 'application' THEN a2.name
                 WHEN r.target_type = 'technology' THEN t2.name
                 WHEN r.target_type = 'security' THEN sc2.name
                 WHEN r.target_type = 'business' THEN COALESCE(d2.name, g2.name, te2.name)
               END as target_name
        FROM relationships r
        LEFT JOIN applications a1 ON r.source_type = 'application' AND r.source_id = a1.id
        LEFT JOIN technologies t1 ON r.source_type = 'technology' AND r.source_id = CAST(t1.id AS TEXT)
        LEFT JOIN security_components sc1 ON r.source_type = 'security' AND r.source_id = CAST(sc1.id AS TEXT)
        LEFT JOIN divisions d1 ON r.source_type = 'business' AND r.source_id = d1.id
        LEFT JOIN groups g1 ON r.source_type = 'business' AND r.source_id = g1.id
        LEFT JOIN teams te1 ON r.source_type = 'business' AND r.source_id = te1.id
        LEFT JOIN applications a2 ON r.target_type = 'application' AND r.target_id = a2.id
        LEFT JOIN technologies t2 ON r.target_type = 'technology' AND r.target_id = CAST(t2.id AS TEXT)
        LEFT JOIN security_components sc2 ON r.target_type = 'security' AND r.target_id = CAST(sc2.id AS TEXT)
        LEFT JOIN divisions d2 ON r.target_type = 'business' AND r.target_id = d2.id
        LEFT JOIN groups g2 ON r.target_type = 'business' AND r.target_id = g2.id
        LEFT JOIN teams te2 ON r.target_type = 'business' AND r.target_id = te2.id
        ORDER BY r.created_at DESC
      `);

      return relationships;
    } catch (error) {
      console.error('Error getting all relationships:', error);
      throw error;
    }
  }

  // Update relationship
  async updateRelationship(relationshipId, updates) {
    try {
      return database.update('relationships', relationshipId, updates);
    } catch (error) {
      console.error('Error updating relationship:', error);
      throw error;
    }
  }

  // Delete relationship
  async deleteRelationship(relationshipId) {
    try {
      return database.delete('relationships', relationshipId);
    } catch (error) {
      console.error('Error deleting relationship:', error);
      throw error;
    }
  }

  // Get relationship matrix for specific types
  async getRelationshipMatrix(sourceType, targetType) {
    try {
      const matrix = database.executeCustomQuery(`
        SELECT r.*,
               CASE 
                 WHEN r.source_type = 'application' THEN a1.name
                 WHEN r.source_type = 'technology' THEN t1.name
                 WHEN r.source_type = 'security' THEN sc1.name
                 WHEN r.source_type = 'business' THEN COALESCE(d1.name, g1.name, te1.name)
               END as source_name,
               CASE 
                 WHEN r.target_type = 'application' THEN a2.name
                 WHEN r.target_type = 'technology' THEN t2.name
                 WHEN r.target_type = 'security' THEN sc2.name
                 WHEN r.target_type = 'business' THEN COALESCE(d2.name, g2.name, te2.name)
               END as target_name
        FROM relationships r
        LEFT JOIN applications a1 ON r.source_type = 'application' AND r.source_id = a1.id
        LEFT JOIN technologies t1 ON r.source_type = 'technology' AND r.source_id = CAST(t1.id AS TEXT)
        LEFT JOIN security_components sc1 ON r.source_type = 'security' AND r.source_id = CAST(sc1.id AS TEXT)
        LEFT JOIN divisions d1 ON r.source_type = 'business' AND r.source_id = d1.id
        LEFT JOIN groups g1 ON r.source_type = 'business' AND r.source_id = g1.id
        LEFT JOIN teams te1 ON r.source_type = 'business' AND r.source_id = te1.id
        LEFT JOIN applications a2 ON r.target_type = 'application' AND r.target_id = a2.id
        LEFT JOIN technologies t2 ON r.target_type = 'technology' AND r.target_id = CAST(t2.id AS TEXT)
        LEFT JOIN security_components sc2 ON r.target_type = 'security' AND r.target_id = CAST(sc2.id AS TEXT)
        LEFT JOIN divisions d2 ON r.target_type = 'business' AND r.target_id = d2.id
        LEFT JOIN groups g2 ON r.target_type = 'business' AND r.target_id = g2.id
        LEFT JOIN teams te2 ON r.target_type = 'business' AND r.target_id = te2.id
        WHERE r.source_type = ? AND r.target_type = ?
        ORDER BY source_name, target_name
      `, [sourceType, targetType]);

      return matrix;
    } catch (error) {
      console.error('Error getting relationship matrix:', error);
      throw error;
    }
  }

  // Get hierarchical tree structure for relationships
  async getHierarchicalTree(rootType, rootId) {
    try {
      const buildTree = async (nodeType, nodeId, visited = new Set()) => {
        const nodeKey = `${nodeType}-${nodeId}`;
        if (visited.has(nodeKey)) {
          return null; // Prevent circular references
        }
        visited.add(nodeKey);

        // Get node details
        let nodeDetails = null;
        switch (nodeType) {
          case 'application':
            nodeDetails = database.read('applications', { id: nodeId }, { single: true });
            break;
          case 'technology':
            nodeDetails = database.read('technologies', { id: nodeId }, { single: true });
            break;
          case 'security':
            nodeDetails = database.read('security_components', { id: nodeId }, { single: true });
            break;
          case 'business':
            nodeDetails = database.read('divisions', { id: nodeId }, { single: true }) ||
                         database.read('groups', { id: nodeId }, { single: true }) ||
                         database.read('teams', { id: nodeId }, { single: true });
            break;
        }

        if (!nodeDetails) return null;

        // Get child relationships
        const childRelationships = database.executeCustomQuery(`
          SELECT * FROM relationships 
          WHERE source_type = ? AND source_id = ?
        `, [nodeType, nodeId]);

        const children = [];
        for (const rel of childRelationships) {
          const child = await buildTree(rel.target_type, rel.target_id, new Set(visited));
          if (child) {
            child.relationshipType = rel.relationship_type;
            child.strength = rel.strength;
            children.push(child);
          }
        }

        return {
          id: nodeId,
          type: nodeType,
          name: nodeDetails.name,
          details: nodeDetails,
          children
        };
      };

      return await buildTree(rootType, rootId);
    } catch (error) {
      console.error('Error getting hierarchical tree:', error);
      throw error;
    }
  }

  // Get network diagram data
  async getNetworkDiagramData() {
    try {
      const nodes = [];
      const links = [];

      // Get all entities as nodes
      const applications = database.read('applications');
      applications.forEach(app => {
        nodes.push({
          id: `app-${app.id}`,
          name: app.name,
          type: 'application',
          group: 'applications'
        });
      });

      const technologies = database.read('technologies');
      technologies.forEach(tech => {
        nodes.push({
          id: `tech-${tech.id}`,
          name: tech.name,
          type: 'technology',
          group: 'technologies'
        });
      });

      const securityComponents = database.read('security_components');
      securityComponents.forEach(comp => {
        nodes.push({
          id: `sec-${comp.id}`,
          name: comp.name,
          type: 'security',
          group: 'security'
        });
      });

      // Get all relationships as links
      const relationships = database.read('relationships');
      relationships.forEach(rel => {
        links.push({
          source: `${rel.source_type.substring(0, 3)}-${rel.source_id}`,
          target: `${rel.target_type.substring(0, 3)}-${rel.target_id}`,
          type: rel.relationship_type,
          strength: rel.strength || 1
        });
      });

      return {
        nodes,
        links
      };
    } catch (error) {
      console.error('Error getting network diagram data:', error);
      throw error;
    }
  }

  // Get relationship statistics
  async getRelationshipStatistics() {
    try {
      const stats = database.executeCustomQuery(`
        SELECT 
          COUNT(*) as total_relationships,
          COUNT(DISTINCT source_type || '-' || source_id) as entities_with_outgoing,
          COUNT(DISTINCT target_type || '-' || target_id) as entities_with_incoming,
          AVG(strength) as avg_strength
        FROM relationships
      `)[0];

      const typeBreakdown = database.executeCustomQuery(`
        SELECT 
          relationship_type,
          COUNT(*) as count
        FROM relationships
        GROUP BY relationship_type
        ORDER BY count DESC
      `);

      const entityTypeBreakdown = database.executeCustomQuery(`
        SELECT 
          source_type,
          target_type,
          COUNT(*) as count
        FROM relationships
        GROUP BY source_type, target_type
        ORDER BY count DESC
      `);

      return {
        totalRelationships: stats.total_relationships,
        entitiesWithOutgoing: stats.entities_with_outgoing,
        entitiesWithIncoming: stats.entities_with_incoming,
        avgStrength: stats.avg_strength ? parseFloat(stats.avg_strength).toFixed(1) : '0',
        typeBreakdown,
        entityTypeBreakdown
      };
    } catch (error) {
      console.error('Error getting relationship statistics:', error);
      throw error;
    }
  }

  // Find shortest path between two entities
  async findShortestPath(sourceType, sourceId, targetType, targetId) {
    try {
      // Simple breadth-first search implementation
      const queue = [{ type: sourceType, id: sourceId, path: [] }];
      const visited = new Set();

      while (queue.length > 0) {
        const current = queue.shift();
        const currentKey = `${current.type}-${current.id}`;

        if (visited.has(currentKey)) continue;
        visited.add(currentKey);

        if (current.type === targetType && current.id === targetId) {
          return current.path;
        }

        // Get all outgoing relationships from current node
        const relationships = database.executeCustomQuery(`
          SELECT target_type, target_id, relationship_type 
          FROM relationships 
          WHERE source_type = ? AND source_id = ?
        `, [current.type, current.id]);

        for (const rel of relationships) {
          const nextKey = `${rel.target_type}-${rel.target_id}`;
          if (!visited.has(nextKey)) {
            queue.push({
              type: rel.target_type,
              id: rel.target_id,
              path: [...current.path, {
                from: { type: current.type, id: current.id },
                to: { type: rel.target_type, id: rel.target_id },
                relationshipType: rel.relationship_type
              }]
            });
          }
        }
      }

      return null; // No path found
    } catch (error) {
      console.error('Error finding shortest path:', error);
      throw error;
    }
  }

  // Bulk create relationships
  async bulkCreateRelationships(relationships) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const rel of relationships) {
          database.create('relationships', {
            source_type: rel.sourceType,
            source_id: rel.sourceId,
            target_type: rel.targetType,
            target_id: rel.targetId,
            relationship_type: rel.relationshipType,
            strength: rel.strength || 0
          });
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk create relationships:', error);
      throw error;
    }
  }

  // Delete all relationships for an entity (used when deleting entities)
  async deleteRelationshipsForEntity(entityType, entityId) {
    try {
      const transaction = database.getDB().transaction(() => {
        // Delete where entity is source
        database.getDB().prepare(`
          DELETE FROM relationships 
          WHERE source_type = ? AND source_id = ?
        `).run(entityType, entityId);

        // Delete where entity is target
        database.getDB().prepare(`
          DELETE FROM relationships 
          WHERE target_type = ? AND target_id = ?
        `).run(entityType, entityId);
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error deleting relationships for entity:', error);
      throw error;
    }
  }
}

export default new RelationshipService();