import database from '../utils/database.js';

class ApplicationService {
  // Get all applications with related data
  async getAllApplications() {
    try {
      const applications = database.executeCustomQuery(`
        SELECT a.*
        FROM applications a
        ORDER BY a.name
      `);

      // Populate related data for each application
      for (const app of applications) {
        // Get teams
        app.teams = database.read('application_teams', { application_id: app.id });
        
        // Get technologies
        app.technologies = database.read('application_technologies', { application_id: app.id });
        
        // Get security controls
        app.securityControls = database.read('application_security_controls', { application_id: app.id });
        
        // Get relationships
        app.relationships = database.read('application_relationships', { application_id: app.id });
      }

      return applications;
    } catch (error) {
      console.error('Error fetching applications:', error);
      throw error;
    }
  }

  // Get application by ID
  async getApplicationById(applicationId) {
    try {
      const application = database.read('applications', { id: applicationId }, { single: true });
      
      if (!application) {
        return null;
      }

      // Populate related data
      application.teams = database.read('application_teams', { application_id: applicationId });
      application.technologies = database.read('application_technologies', { application_id: applicationId });
      application.securityControls = database.read('application_security_controls', { application_id: applicationId });
      application.relationships = database.read('application_relationships', { application_id: applicationId });

      return application;
    } catch (error) {
      console.error('Error fetching application by ID:', error);
      throw error;
    }
  }

  // Create new application
  async createApplication(applicationData) {
    try {
      const newApplication = {
        id: applicationData.id || `APP${Date.now()}`,
        name: applicationData.name,
        description: applicationData.description || '',
        ics_level: applicationData.icsLevel || '0',
        app_group: applicationData.group || '',
        business_process: applicationData.businessProcess || '',
        vendor: applicationData.vendor || '',
        status: applicationData.status || 'Development',
        business_impact: applicationData.businessImpact || '',
        technical_risk: applicationData.technicalRisk || ''
      };

      const application = database.create('applications', newApplication);

      // Add teams if provided
      if (applicationData.teams && applicationData.teams.length > 0) {
        for (const team of applicationData.teams) {
          database.create('application_teams', {
            application_id: application.id,
            name: team.name,
            abbreviation: team.abbreviation,
            role: team.role,
            responsibility: team.responsibility
          });
        }
      }

      // Add technologies if provided
      if (applicationData.technologies && applicationData.technologies.length > 0) {
        for (const tech of applicationData.technologies) {
          database.create('application_technologies', {
            application_id: application.id,
            name: tech.name,
            category: tech.category,
            version: tech.version
          });
        }
      }

      // Add security controls if provided
      if (applicationData.securityControls && applicationData.securityControls.length > 0) {
        for (const control of applicationData.securityControls) {
          database.create('application_security_controls', {
            application_id: application.id,
            name: control.name,
            type: control.type,
            status: control.status
          });
        }
      }

      // Add relationships if provided
      if (applicationData.relationships && applicationData.relationships.length > 0) {
        for (const rel of applicationData.relationships) {
          database.create('application_relationships', {
            application_id: application.id,
            target_application: rel.targetApplication,
            type: rel.type,
            direction: rel.direction
          });
        }
      }

      return await this.getApplicationById(application.id);
    } catch (error) {
      console.error('Error creating application:', error);
      throw error;
    }
  }

  // Update application
  async updateApplication(applicationId, updates) {
    try {
      const applicationUpdates = {
        name: updates.name,
        description: updates.description,
        ics_level: updates.icsLevel,
        app_group: updates.group,
        business_process: updates.businessProcess,
        vendor: updates.vendor,
        status: updates.status,
        business_impact: updates.businessImpact,
        technical_risk: updates.technicalRisk
      };

      // Remove undefined values
      Object.keys(applicationUpdates).forEach(key => 
        applicationUpdates[key] === undefined && delete applicationUpdates[key]
      );

      const result = database.update('applications', applicationId, applicationUpdates);

      // Update teams if provided
      if (updates.teams) {
        database.getDB().prepare('DELETE FROM application_teams WHERE application_id = ?').run(applicationId);
        for (const team of updates.teams) {
          database.create('application_teams', {
            application_id: applicationId,
            name: team.name,
            abbreviation: team.abbreviation,
            role: team.role,
            responsibility: team.responsibility
          });
        }
      }

      // Update technologies if provided
      if (updates.technologies) {
        database.getDB().prepare('DELETE FROM application_technologies WHERE application_id = ?').run(applicationId);
        for (const tech of updates.technologies) {
          database.create('application_technologies', {
            application_id: applicationId,
            name: tech.name,
            category: tech.category,
            version: tech.version
          });
        }
      }

      // Update security controls if provided
      if (updates.securityControls) {
        database.getDB().prepare('DELETE FROM application_security_controls WHERE application_id = ?').run(applicationId);
        for (const control of updates.securityControls) {
          database.create('application_security_controls', {
            application_id: applicationId,
            name: control.name,
            type: control.type,
            status: control.status
          });
        }
      }

      // Update relationships if provided
      if (updates.relationships) {
        database.getDB().prepare('DELETE FROM application_relationships WHERE application_id = ?').run(applicationId);
        for (const rel of updates.relationships) {
          database.create('application_relationships', {
            application_id: applicationId,
            target_application: rel.targetApplication,
            type: rel.type,
            direction: rel.direction
          });
        }
      }

      return result;
    } catch (error) {
      console.error('Error updating application:', error);
      throw error;
    }
  }

  // Delete application
  async deleteApplication(applicationId) {
    try {
      return database.delete('applications', applicationId);
    } catch (error) {
      console.error('Error deleting application:', error);
      throw error;
    }
  }

  // Search applications
  async searchApplications(query, filters = {}) {
    try {
      let sql = `
        SELECT DISTINCT a.*
        FROM applications a
        LEFT JOIN application_teams at ON a.id = at.application_id
        WHERE 1=1
      `;
      const params = [];

      // Add search query
      if (query) {
        sql += ` AND (
          LOWER(a.name) LIKE ? OR 
          LOWER(a.description) LIKE ? OR 
          LOWER(a.vendor) LIKE ? OR 
          LOWER(a.app_group) LIKE ? OR 
          LOWER(a.business_process) LIKE ? OR 
          LOWER(a.status) LIKE ?
        )`;
        const searchTerm = `%${query.toLowerCase()}%`;
        params.push(searchTerm, searchTerm, searchTerm, searchTerm, searchTerm, searchTerm);
      }

      // Add filters
      if (filters.icsLevel) {
        sql += ` AND a.ics_level = ?`;
        params.push(filters.icsLevel);
      }

      if (filters.group) {
        sql += ` AND a.app_group = ?`;
        params.push(filters.group);
      }

      if (filters.vendor) {
        sql += ` AND a.vendor = ?`;
        params.push(filters.vendor);
      }

      if (filters.businessProcess) {
        sql += ` AND a.business_process = ?`;
        params.push(filters.businessProcess);
      }

      if (filters.status) {
        sql += ` AND a.status = ?`;
        params.push(filters.status);
      }

      sql += ` ORDER BY a.name`;

      const applications = database.executeCustomQuery(sql, params);

      // Populate related data for each application
      for (const app of applications) {
        app.teams = database.read('application_teams', { application_id: app.id });
        app.technologies = database.read('application_technologies', { application_id: app.id });
        app.securityControls = database.read('application_security_controls', { application_id: app.id });
        app.relationships = database.read('application_relationships', { application_id: app.id });
      }

      return applications;
    } catch (error) {
      console.error('Error searching applications:', error);
      throw error;
    }
  }

  // Get filter options
  async getFilterOptions() {
    try {
      const groups = database.executeCustomQuery(`
        SELECT DISTINCT app_group FROM applications WHERE app_group IS NOT NULL AND app_group != '' ORDER BY app_group
      `);

      const vendors = database.executeCustomQuery(`
        SELECT DISTINCT vendor FROM applications WHERE vendor IS NOT NULL AND vendor != '' ORDER BY vendor
      `);

      const businessProcesses = database.executeCustomQuery(`
        SELECT DISTINCT business_process FROM applications WHERE business_process IS NOT NULL AND business_process != '' ORDER BY business_process
      `);

      const statuses = database.executeCustomQuery(`
        SELECT DISTINCT status FROM applications WHERE status IS NOT NULL AND status != '' ORDER BY status
      `);

      const icsLevels = database.executeCustomQuery(`
        SELECT DISTINCT ics_level FROM applications WHERE ics_level IS NOT NULL AND ics_level != '' ORDER BY CAST(ics_level AS REAL)
      `);

      return {
        groups: groups.map(g => g.app_group),
        vendors: vendors.map(v => v.vendor),
        businessProcesses: businessProcesses.map(bp => bp.business_process),
        statuses: statuses.map(s => s.status),
        icsLevels: icsLevels.map(il => il.ics_level)
      };
    } catch (error) {
      console.error('Error getting filter options:', error);
      throw error;
    }
  }

  // Get application statistics
  async getStatistics() {
    try {
      const stats = database.executeCustomQuery(`
        SELECT 
          COUNT(*) as total_applications,
          COUNT(CASE WHEN status = 'Production' THEN 1 END) as production_apps,
          COUNT(CASE WHEN status = 'Development' THEN 1 END) as development_apps,
          COUNT(CASE WHEN business_impact = 'Critical' THEN 1 END) as critical_apps,
          AVG(CAST(ics_level AS REAL)) as avg_ics_level
        FROM applications
      `)[0];

      return {
        totalApplications: stats.total_applications,
        productionApps: stats.production_apps,
        developmentApps: stats.development_apps,
        criticalApps: stats.critical_apps,
        avgIcsLevel: stats.avg_ics_level ? parseFloat(stats.avg_ics_level).toFixed(1) : '0'
      };
    } catch (error) {
      console.error('Error getting application statistics:', error);
      throw error;
    }
  }

  // Bulk operations
  async bulkUpdateApplications(applicationIds, updates) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const appId of applicationIds) {
          database.update('applications', appId, updates);
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk update:', error);
      throw error;
    }
  }

  async bulkDeleteApplications(applicationIds) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const appId of applicationIds) {
          database.delete('applications', appId);
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk delete:', error);
      throw error;
    }
  }

  // Get relationship matrix data
  async getRelationshipMatrix() {
    try {
      const relationships = database.executeCustomQuery(`
        SELECT 
          a1.name as source_app,
          a2.name as target_app,
          ar.type,
          ar.direction
        FROM application_relationships ar
        JOIN applications a1 ON ar.application_id = a1.id
        JOIN applications a2 ON ar.target_application = a2.name
        ORDER BY a1.name, a2.name
      `);

      return relationships;
    } catch (error) {
      console.error('Error getting relationship matrix:', error);
      throw error;
    }
  }
}

export default new ApplicationService();