import database from '../utils/database.js';
import businessCapabilitiesService from './businessCapabilitiesService.js';
import applicationService from './applicationService.js';
import technologyService from './technologyService.js';
import securityService from './securityService.js';

class DashboardService {
  // Get comprehensive dashboard statistics
  async getDashboardStats() {
    try {
      // Get statistics from all services
      const [
        businessStats,
        applicationStats,
        technologyStats,
        securityStats
      ] = await Promise.all([
        businessCapabilitiesService.getStatistics(),
        applicationService.getStatistics(),
        technologyService.getStatistics(),
        securityService.getStatistics()
      ]);

      // Calculate overall metrics
      const totalAssets = 
        businessStats.totalFunctions + 
        applicationStats.totalApplications + 
        technologyStats.totalTechnologies + 
        securityStats.totalComponents;

      const complianceRate = await securityService.getComplianceRate();

      return {
        overview: {
          totalAssets,
          businessCapabilities: businessStats.totalFunctions,
          applications: applicationStats.totalApplications,
          technologies: technologyStats.totalTechnologies,
          securityComponents: securityStats.totalComponents,
          complianceRate
        },
        businessCapabilities: businessStats,
        applications: applicationStats,
        technologies: technologyStats,
        security: securityStats
      };
    } catch (error) {
      console.error('Error getting dashboard statistics:', error);
      throw error;
    }
  }

  // Get architecture overview data
  async getArchitectureOverview() {
    try {
      const overview = database.executeCustomQuery(`
        SELECT 
          'divisions' as category,
          COUNT(*) as count,
          'Business Layer' as layer
        FROM divisions
        UNION ALL
        SELECT 
          'applications' as category,
          COUNT(*) as count,
          'Application Layer' as layer
        FROM applications
        UNION ALL
        SELECT 
          'technologies' as category,
          COUNT(*) as count,
          'Technology Layer' as layer
        FROM technologies
        UNION ALL
        SELECT 
          'security_components' as category,
          COUNT(*) as count,
          'Security Layer' as layer
        FROM security_components
      `);

      // Get health metrics
      const healthMetrics = database.executeCustomQuery(`
        SELECT 
          COUNT(CASE WHEN status = 'Production' THEN 1 END) as healthy,
          COUNT(CASE WHEN status = 'Development' THEN 1 END) as developing,
          COUNT(CASE WHEN status = 'Deprecated' THEN 1 END) as at_risk
        FROM (
          SELECT status FROM applications
          UNION ALL
          SELECT status FROM technologies
        ) as combined_status
      `)[0];

      return {
        layers: overview,
        health: {
          healthy: healthMetrics.healthy || 0,
          developing: healthMetrics.developing || 0,
          atRisk: healthMetrics.at_risk || 0
        }
      };
    } catch (error) {
      console.error('Error getting architecture overview:', error);
      throw error;
    }
  }

  // Get compliance overview
  async getComplianceOverview() {
    try {
      const complianceData = database.executeCustomQuery(`
        SELECT 
          criticality,
          COUNT(*) as count,
          (COUNT(*) * 100.0 / (SELECT COUNT(*) FROM security_components)) as percentage
        FROM security_components
        WHERE criticality IS NOT NULL
        GROUP BY criticality
        ORDER BY 
          CASE criticality
            WHEN 'Critical' THEN 1 WHEN'High'THEN 2 WHEN'Medium'THEN 3 WHEN'Low' THEN 4
          END
      `);

      // Calculate overall compliance score
      const totalComponents = complianceData.reduce((sum, item) => sum + item.count, 0);
      const criticalAndHigh = complianceData
        .filter(item => ['Critical', 'High'].includes(item.criticality))
        .reduce((sum, item) => sum + item.count, 0);
      
      const complianceScore = totalComponents > 0 
        ? Math.round(((totalComponents - criticalAndHigh) / totalComponents) * 100)
        : 100;

      return {
        score: complianceScore,
        breakdown: complianceData.map(item => ({
          level: item.criticality,
          count: item.count,
          percentage: parseFloat(item.percentage).toFixed(1)
        })),
        trends: await this.getComplianceTrends()
      };
    } catch (error) {
      console.error('Error getting compliance overview:', error);
      throw error;
    }
  }

  // Get compliance trends (simulated based on last updated dates)
  async getComplianceTrends() {
    try {
      const trends = database.executeCustomQuery(`
        SELECT 
          DATE(last_updated) as date,
          criticality,
          COUNT(*) as count
        FROM security_components
        WHERE last_updated >= DATE('now', '-30 days')
        GROUP BY DATE(last_updated), criticality
        ORDER BY date DESC
        LIMIT 30
      `);

      return trends;
    } catch (error) {
      console.error('Error getting compliance trends:', error);
      return [];
    }
  }

  // Get recent activity across all modules
  async getRecentActivity() {
    try {
      const activities = [];

      // Get recent application updates
      const appUpdates = database.executeCustomQuery(`
        SELECT 
          'application' as type,
          name as item_name,
          'Updated' as action,
          updated_at as timestamp
        FROM applications
        WHERE updated_at IS NOT NULL
        ORDER BY updated_at DESC
        LIMIT 10
      `);

      // Get recent technology updates  
      const techUpdates = database.executeCustomQuery(`
        SELECT 
          'technology' as type,
          name as item_name,
          action,
          date as timestamp
        FROM technology_history
        ORDER BY date DESC
        LIMIT 10
      `);

      // Get recent security audit entries
      const securityUpdates = database.executeCustomQuery(`
        SELECT 
          'security' as type,
          sc.name as item_name,
          sat.action,
          sat.timestamp
        FROM security_audit_trail sat
        JOIN security_components sc ON sat.security_component_id = sc.id
        ORDER BY sat.timestamp DESC
        LIMIT 10
      `);

      // Combine and sort all activities
      activities.push(...appUpdates);
      activities.push(...techUpdates);
      activities.push(...securityUpdates);

      activities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

      return activities.slice(0, 20).map(activity => ({
        type: activity.type,
        itemName: activity.item_name,
        action: activity.action,
        timestamp: activity.timestamp,
        timeAgo: this.getTimeAgo(new Date(activity.timestamp))
      }));
    } catch (error) {
      console.error('Error getting recent activity:', error);
      return [];
    }
  }

  // Get quick actions based on system state
  async getQuickActions() {
    try {
      const actions = [];

      // Check for deprecated technologies
      const deprecatedTech = database.executeCustomQuery(`
        SELECT COUNT(*) as count FROM technologies WHERE status = 'Deprecated'
      `)[0];

      if (deprecatedTech.count > 0) {
        actions.push({
          type: 'warning',
          title: 'Deprecated Technologies',
          description: `${deprecatedTech.count} deprecated technologies need attention`,
          action: 'Review Technologies',
          link: '/technology-architecture'
        });
      }

      // Check for critical security components
      const criticalSecurity = database.executeCustomQuery(`
        SELECT COUNT(*) as count FROM security_components WHERE criticality = 'Critical'
      `)[0];

      if (criticalSecurity.count > 0) {
        actions.push({
          type: 'error',
          title: 'Critical Security Components',
          description: `${criticalSecurity.count} critical security components require review`,
          action: 'Review Security',
          link: '/security-architecture'
        });
      }

      // Check for applications without teams
      const appsWithoutTeams = database.executeCustomQuery(`
        SELECT COUNT(*) as count 
        FROM applications a
        WHERE NOT EXISTS (
          SELECT 1 FROM application_teams at WHERE at.application_id = a.id
        )
      `)[0];

      if (appsWithoutTeams.count > 0) {
        actions.push({
          type: 'info',
          title: 'Unassigned Applications',
          description: `${appsWithoutTeams.count} applications need team assignments`,
          action: 'Assign Teams',
          link: '/application-architecture'
        });
      }

      // Check for upcoming end-of-life technologies
      const eolTech = database.executeCustomQuery(`
        SELECT COUNT(*) as count 
        FROM technologies 
        WHERE end_of_life IS NOT NULL 
        AND DATE(end_of_life) <= DATE('now', '+6 months')
        AND DATE(end_of_life) > DATE('now')
      `)[0];

      if (eolTech.count > 0) {
        actions.push({
          type: 'warning',
          title: 'Upcoming End-of-Life',
          description: `${eolTech.count} technologies approaching end-of-life in 6 months`,
          action: 'Plan Replacements',
          link: '/technology-architecture'
        });
      }

      return actions.slice(0, 6); // Limit to 6 actions
    } catch (error) {
      console.error('Error getting quick actions:', error);
      return [];
    }
  }

  // Get system health metrics
  async getSystemHealth() {
    try {
      const health = {
        overall: 'healthy',
        score: 85,
        metrics: []
      };

      // Check application health
      const appHealth = database.executeCustomQuery(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'Production' THEN 1 END) as production
        FROM applications
      `)[0];

      const appHealthScore = appHealth.total > 0 ? 
        Math.round((appHealth.production / appHealth.total) * 100) : 100;

      health.metrics.push({
        name: 'Applications',
        score: appHealthScore,
        status: appHealthScore >= 80 ? 'healthy' : appHealthScore >= 60 ? 'warning' : 'critical'
      });

      // Check technology health
      const techHealth = database.executeCustomQuery(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'Production' THEN 1 END) as production,
          COUNT(CASE WHEN status = 'Deprecated' THEN 1 END) as deprecated
        FROM technologies
      `)[0];

      const techHealthScore = techHealth.total > 0 ? 
        Math.round(((techHealth.total - techHealth.deprecated) / techHealth.total) * 100) : 100;

      health.metrics.push({
        name: 'Technologies',
        score: techHealthScore,
        status: techHealthScore >= 80 ? 'healthy' : techHealthScore >= 60 ? 'warning' : 'critical'
      });

      // Check security health
      const securityHealth = database.executeCustomQuery(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN criticality = 'Critical' THEN 1 END) as critical
        FROM security_components
      `)[0];

      const securityHealthScore = securityHealth.total > 0 ? 
        Math.round(((securityHealth.total - securityHealth.critical) / securityHealth.total) * 100) : 100;

      health.metrics.push({
        name: 'Security',
        score: securityHealthScore,
        status: securityHealthScore >= 80 ? 'healthy' : securityHealthScore >= 60 ? 'warning' : 'critical'
      });

      // Calculate overall score
      health.score = Math.round(
        health.metrics.reduce((sum, metric) => sum + metric.score, 0) / health.metrics.length
      );

      health.overall = health.score >= 80 ? 'healthy' : health.score >= 60 ? 'warning' : 'critical';

      return health;
    } catch (error) {
      console.error('Error getting system health:', error);
      return {
        overall: 'unknown',
        score: 0,
        metrics: []
      };
    }
  }

  // Helper function to calculate time ago
  getTimeAgo(date) {
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) {
      return `${diffMins} minutes ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hours ago`;
    } else {
      return `${diffDays} days ago`;
    }
  }

  // Get trending data for charts
  async getTrendingData() {
    try {
      // Application creation trends (last 30 days)
      const appTrends = database.executeCustomQuery(`
        SELECT 
          DATE(created_at) as date,
          COUNT(*) as count
        FROM applications
        WHERE created_at >= DATE('now', '-30 days')
        GROUP BY DATE(created_at)
        ORDER BY date
      `);

      // Technology updates trends
      const techTrends = database.executeCustomQuery(`
        SELECT 
          DATE(last_updated) as date,
          COUNT(*) as count
        FROM technologies
        WHERE last_updated >= DATE('now', '-30 days')
        GROUP BY DATE(last_updated)
        ORDER BY date
      `);

      return {
        applications: appTrends,
        technologies: techTrends
      };
    } catch (error) {
      console.error('Error getting trending data:', error);
      return {
        applications: [],
        technologies: []
      };
    }
  }
}

export default new DashboardService();