import database from '../utils/database.js';

class SecurityService {
  // Get all security components with related data
  async getAllSecurityComponents() {
    try {
      const components = database.executeCustomQuery(`
        SELECT sc.*
        FROM security_components sc
        ORDER BY sc.name
      `);

      // Populate related data for each component
      for (const component of components) {
        // Get dependencies
        const dependencies = database.read('security_dependencies', { security_component_id: component.id });
        component.dependencies = dependencies.map(d => d.dependency_name);
        
        // Get audit trail
        component.auditTrail = database.read('security_audit_trail', { security_component_id: component.id }, {
          orderBy: 'timestamp',
          orderDirection: 'DESC',
          limit: 10
        });
      }

      return components;
    } catch (error) {
      console.error('Error fetching security components:', error);
      throw error;
    }
  }

  // Get security component by ID
  async getSecurityComponentById(componentId) {
    try {
      const component = database.read('security_components', { id: componentId }, { single: true });
      
      if (!component) {
        return null;
      }

      // Populate related data
      const dependencies = database.read('security_dependencies', { security_component_id: componentId });
      component.dependencies = dependencies.map(d => d.dependency_name);
      
      component.auditTrail = database.read('security_audit_trail', { security_component_id: componentId }, {
        orderBy: 'timestamp',
        orderDirection: 'DESC'
      });

      return component;
    } catch (error) {
      console.error('Error fetching security component by ID:', error);
      throw error;
    }
  }

  // Create new security component
  async createSecurityComponent(componentData) {
    try {
      const newComponent = {
        name: componentData.name,
        description: componentData.description || '',
        category: componentData.category || '',
        criticality: componentData.criticality || 'Medium',
        environment: componentData.environment || '',
        team_ownership: componentData.teamOwnership || '',
        ics_level: componentData.icsLevel || '0',
        risk_score: componentData.riskScore || 0,
        last_updated: new Date().toISOString().split('T')[0] // Date only
      };

      const component = database.create('security_components', newComponent);

      // Add dependencies if provided
      if (componentData.dependencies && componentData.dependencies.length > 0) {
        for (const dependency of componentData.dependencies) {
          database.create('security_dependencies', {
            security_component_id: component.id,
            dependency_name: dependency
          });
        }
      }

      // Add initial audit trail entry
      database.create('security_audit_trail', {
        security_component_id: component.id,
        action: 'Component created',
        user: componentData.createdBy || 'System',
        timestamp: new Date().toISOString()
      });

      return await this.getSecurityComponentById(component.id);
    } catch (error) {
      console.error('Error creating security component:', error);
      throw error;
    }
  }

  // Update security component
  async updateSecurityComponent(componentId, updates) {
    try {
      const componentUpdates = {
        name: updates.name,
        description: updates.description,
        category: updates.category,
        criticality: updates.criticality,
        environment: updates.environment,
        team_ownership: updates.teamOwnership,
        ics_level: updates.icsLevel,
        risk_score: updates.riskScore,
        last_updated: new Date().toISOString().split('T')[0]
      };

      // Remove undefined values
      Object.keys(componentUpdates).forEach(key => 
        componentUpdates[key] === undefined && delete componentUpdates[key]
      );

      const result = database.update('security_components', componentId, componentUpdates);

      // Update dependencies if provided
      if (updates.dependencies) {
        database.getDB().prepare('DELETE FROM security_dependencies WHERE security_component_id = ?').run(componentId);
        for (const dependency of updates.dependencies) {
          database.create('security_dependencies', {
            security_component_id: componentId,
            dependency_name: dependency
          });
        }
      }

      // Add audit trail entry for update
      if (result) {
        database.create('security_audit_trail', {
          security_component_id: componentId,
          action: 'Component updated',
          user: updates.updatedBy || 'System',
          timestamp: new Date().toISOString()
        });
      }

      return result;
    } catch (error) {
      console.error('Error updating security component:', error);
      throw error;
    }
  }

  // Delete security component
  async deleteSecurityComponent(componentId) {
    try {
      return database.delete('security_components', componentId);
    } catch (error) {
      console.error('Error deleting security component:', error);
      throw error;
    }
  }

  // Search security components
  async searchSecurityComponents(query, filters = {}) {
    try {
      let sql = `
        SELECT DISTINCT sc.*
        FROM security_components sc
        WHERE 1=1
      `;
      const params = [];

      // Add search query
      if (query) {
        sql += ` AND (
          LOWER(sc.name) LIKE ? OR 
          LOWER(sc.description) LIKE ? OR 
          LOWER(sc.category) LIKE ? OR
          LOWER(sc.environment) LIKE ? OR
          LOWER(sc.team_ownership) LIKE ?
        )`;
        const searchTerm = `%${query.toLowerCase()}%`;
        params.push(searchTerm, searchTerm, searchTerm, searchTerm, searchTerm);
      }

      // Add filters
      if (filters.category) {
        sql += ` AND sc.category = ?`;
        params.push(filters.category);
      }

      if (filters.criticality) {
        sql += ` AND sc.criticality = ?`;
        params.push(filters.criticality);
      }

      if (filters.environment) {
        sql += ` AND sc.environment = ?`;
        params.push(filters.environment);
      }

      if (filters.teamOwnership) {
        sql += ` AND sc.team_ownership = ?`;
        params.push(filters.teamOwnership);
      }

      if (filters.icsLevel) {
        sql += ` AND sc.ics_level = ?`;
        params.push(filters.icsLevel);
      }

      sql += ` ORDER BY sc.name`;

      const components = database.executeCustomQuery(sql, params);

      // Populate related data for each component
      for (const component of components) {
        const dependencies = database.read('security_dependencies', { security_component_id: component.id });
        component.dependencies = dependencies.map(d => d.dependency_name);
        
        component.auditTrail = database.read('security_audit_trail', { security_component_id: component.id }, {
          orderBy: 'timestamp',
          orderDirection: 'DESC',
          limit: 5
        });
      }

      return components;
    } catch (error) {
      console.error('Error searching security components:', error);
      throw error;
    }
  }

  // Get filter options
  async getFilterOptions() {
    try {
      const categories = database.executeCustomQuery(`
        SELECT DISTINCT category FROM security_components WHERE category IS NOT NULL AND category != '' ORDER BY category
      `);

      const criticalities = database.executeCustomQuery(`
        SELECT DISTINCT criticality FROM security_components WHERE criticality IS NOT NULL AND criticality != '' ORDER BY criticality
      `);

      const environments = database.executeCustomQuery(`
        SELECT DISTINCT environment FROM security_components WHERE environment IS NOT NULL AND environment != '' ORDER BY environment
      `);

      const teamOwnerships = database.executeCustomQuery(`
        SELECT DISTINCT team_ownership FROM security_components WHERE team_ownership IS NOT NULL AND team_ownership != '' ORDER BY team_ownership
      `);

      const icsLevels = database.executeCustomQuery(`
        SELECT DISTINCT ics_level FROM security_components WHERE ics_level IS NOT NULL AND ics_level != '' 
        ORDER BY CAST(ics_level AS REAL)
      `);

      return {
        categories: categories.map(c => c.category),
        criticalities: criticalities.map(c => c.criticality),
        environments: environments.map(e => e.environment),
        teamOwnerships: teamOwnerships.map(t => t.team_ownership),
        icsLevels: icsLevels.map(i => i.ics_level)
      };
    } catch (error) {
      console.error('Error getting filter options:', error);
      throw error;
    }
  }

  // Get security statistics
  async getStatistics() {
    try {
      const stats = database.executeCustomQuery(`
        SELECT 
          COUNT(*) as total_components,
          COUNT(CASE WHEN criticality = 'Critical' THEN 1 END) as critical_components,
          COUNT(CASE WHEN criticality = 'High' THEN 1 END) as high_components,
          COUNT(CASE WHEN criticality = 'Medium' THEN 1 END) as medium_components,
          COUNT(CASE WHEN criticality = 'Low' THEN 1 END) as low_components,
          AVG(risk_score) as avg_risk_score
        FROM security_components
      `)[0];

      const categoryCounts = database.executeCustomQuery(`
        SELECT category, COUNT(*) as count
        FROM security_components
        WHERE category IS NOT NULL AND category != ''
        GROUP BY category
        ORDER BY count DESC
      `);

      const icsLevelCounts = database.executeCustomQuery(`
        SELECT 
          ics_level,
          COUNT(*) as count
        FROM security_components
        WHERE ics_level IS NOT NULL AND ics_level != ''
        GROUP BY ics_level
        ORDER BY CAST(ics_level AS REAL)
      `);

      return {
        totalComponents: stats.total_components,
        criticalComponents: stats.critical_components,
        highComponents: stats.high_components,
        mediumComponents: stats.medium_components,
        lowComponents: stats.low_components,
        avgRiskScore: stats.avg_risk_score ? parseFloat(stats.avg_risk_score).toFixed(1) : '0',
        categoryCounts: categoryCounts,
        icsLevelCounts: icsLevelCounts
      };
    } catch (error) {
      console.error('Error getting security statistics:', error);
      throw error;
    }
  }

  // Get ICS levels visualization data
  async getICSLevelsData() {
    try {
      const icsData = database.executeCustomQuery(`
        SELECT 
          ics_level,
          COUNT(*) as component_count,
          AVG(risk_score) as avg_risk_score,
          GROUP_CONCAT(DISTINCT category) as categories
        FROM security_components
        WHERE ics_level IS NOT NULL AND ics_level != ''
        GROUP BY ics_level
        ORDER BY CAST(ics_level AS REAL)
      `);

      return icsData.map(item => ({
        level: item.ics_level,
        componentCount: item.component_count,
        avgRiskScore: parseFloat(item.avg_risk_score || 0).toFixed(1),
        categories: item.categories ? item.categories.split(',') : []
      }));
    } catch (error) {
      console.error('Error getting ICS levels data:', error);
      throw error;
    }
  }

  // Add audit trail entry
  async addAuditTrailEntry(componentId, auditData) {
    try {
      return database.create('security_audit_trail', {
        security_component_id: componentId,
        action: auditData.action,
        user: auditData.user,
        timestamp: auditData.timestamp || new Date().toISOString()
      });
    } catch (error) {
      console.error('Error adding audit trail entry:', error);
      throw error;
    }
  }

  // Bulk operations
  async bulkUpdateSecurityComponents(componentIds, updates) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const componentId of componentIds) {
          const updateData = {
            ...updates,
            last_updated: new Date().toISOString().split('T')[0]
          };
          
          // Remove undefined values
          Object.keys(updateData).forEach(key => 
            updateData[key] === undefined && delete updateData[key]
          );
          
          database.update('security_components', componentId, updateData);
          
          // Add audit trail entry
          database.create('security_audit_trail', {
            security_component_id: componentId,
            action: 'Bulk updated',
            user: updates.updatedBy || 'System',
            timestamp: new Date().toISOString()
          });
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk update:', error);
      throw error;
    }
  }

  async bulkDeleteSecurityComponents(componentIds) {
    try {
      const transaction = database.getDB().transaction(() => {
        for (const componentId of componentIds) {
          database.delete('security_components', componentId);
        }
      });

      transaction();
      return true;
    } catch (error) {
      console.error('Error in bulk delete:', error);
      throw error;
    }
  }

  // Get network architecture data
  async getNetworkArchitectureData() {
    try {
      const networkComponents = database.executeCustomQuery(`
        SELECT 
          sc.*,
          sd.dependency_name
        FROM security_components sc
        LEFT JOIN security_dependencies sd ON sc.id = sd.security_component_id
        WHERE sc.category IN ('Network Security', 'Network Infrastructure', 'Firewall')
        ORDER BY sc.name
      `);

      // Group components with their dependencies
      const componentMap = new Map();
      
      for (const component of networkComponents) {
        if (!componentMap.has(component.id)) {
          componentMap.set(component.id, {
            ...component,
            dependencies: []
          });
        }
        
        if (component.dependency_name) {
          componentMap.get(component.id).dependencies.push(component.dependency_name);
        }
      }

      return Array.from(componentMap.values());
    } catch (error) {
      console.error('Error getting network architecture data:', error);
      throw error;
    }
  }

  // Get compliance rate
  async getComplianceRate() {
    try {
      const stats = database.executeCustomQuery(`
        SELECT 
          COUNT(*) as total,
          COUNT(CASE WHEN criticality IN ('Low', 'Medium') THEN 1 END) as compliant
        FROM security_components
      `)[0];

      return stats.total > 0 ? Math.round((stats.compliant / stats.total) * 100) : 0;
    } catch (error) {
      console.error('Error getting compliance rate:', error);
      return 0;
    }
  }
}

export default new SecurityService();