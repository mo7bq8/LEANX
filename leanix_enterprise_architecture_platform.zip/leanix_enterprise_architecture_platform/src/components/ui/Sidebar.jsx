import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Sidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const navigationItems = [
    {
      id: 'dashboard',
      label: 'Platform Dashboard',
      icon: 'LayoutDashboard',
      path: '/platform-dashboard',
      tooltip: 'Central command center with organizational architecture overview'
    },
    {
      id: 'business',
      label: 'Business Architecture',
      icon: 'Building',
      path: '/business-capabilities-management',
      tooltip: 'Organizational structure and capabilities management'
    },
    {
      id: 'application',
      label: 'Application Architecture',
      icon: 'Layers',
      path: '/application-architecture',
      tooltip: 'Application portfolio management and ICS levels'
    },
    {
      id: 'technology',
      label: 'Technology Architecture',
      icon: 'Server',
      path: '/technology-architecture',
      tooltip: 'Technology inventory and team assignments'
    },
    {
      id: 'security',
      label: 'Security Architecture',
      icon: 'Shield',
      path: '/security-architecture',
      tooltip: 'Security components and compliance tracking'
    },
    {
      id: 'relationships',
      label: 'Architecture Relationships',
      icon: 'Network',
      path: '/architecture-relationships',
      tooltip: 'Cross-domain dependency analysis and mapping'
    }
  ];

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const toggleMobile = () => {
    setIsMobileOpen(!isMobileOpen);
  };

  const handleNavigation = (path) => {
    navigate(path);
    setIsMobileOpen(false);
  };

  const isActive = (path) => {
    return location.pathname === path;
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-80 lg:hidden"
          onClick={toggleMobile}
        />
      )}

      {/* Mobile Toggle Button */}
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleMobile}
        className="fixed top-4 left-4 z-90 lg:hidden"
      >
        <Icon name="Menu" size={20} />
      </Button>

      {/* Sidebar */}
      <aside className={`
        fixed top-16 left-0 bottom-0 z-80 bg-card border-r border-border enterprise-shadow-card
        transition-all duration-300 ease-in-out
        ${isCollapsed ? 'w-16' : 'w-64'}
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        lg:fixed
      `}>
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            {!isCollapsed && (
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
                Architecture Modules
              </h2>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleCollapse}
              className="hidden lg:flex h-8 w-8"
            >
              <Icon 
                name={isCollapsed ? "ChevronRight" : "ChevronLeft"} 
                size={16} 
              />
            </Button>
          </div>

          {/* Navigation Items */}
          <nav className="flex-1 p-2 space-y-1">
            {navigationItems.map((item) => {
              const active = isActive(item.path);
              
              return (
                <div key={item.id} className="relative group">
                  <button
                    onClick={() => handleNavigation(item.path)}
                    className={`
                      w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg text-left
                      enterprise-transition group relative
                      ${active 
                        ? 'bg-primary text-primary-foreground shadow-sm' 
                        : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }
                      ${isCollapsed ? 'justify-center' : ''}
                    `}
                  >
                    <Icon 
                      name={item.icon} 
                      size={20} 
                      className={`flex-shrink-0 ${active ? 'text-primary-foreground' : ''}`}
                    />
                    {!isCollapsed && (
                      <span className="text-sm font-medium truncate">
                        {item.label}
                      </span>
                    )}
                    
                    {/* Active Indicator */}
                    {active && (
                      <div className="absolute left-0 top-1/2 transform -translate-y-1/2 w-1 h-6 bg-primary-foreground rounded-r-full" />
                    )}
                  </button>

                  {/* Tooltip for collapsed state */}
                  {isCollapsed && (
                    <div className="absolute left-full top-1/2 transform -translate-y-1/2 ml-2 px-3 py-2 bg-popover border border-border rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-90 whitespace-nowrap">
                      <div className="text-sm font-medium text-foreground">{item.label}</div>
                      <div className="text-xs text-muted-foreground mt-1">{item.tooltip}</div>
                    </div>
                  )}
                </div>
              );
            })}
          </nav>

          {/* Sidebar Footer */}
          <div className="p-4 border-t border-border">
            <div className={`flex items-center space-x-3 ${isCollapsed ? 'justify-center' : ''}`}>
              <div className="w-8 h-8 bg-muted rounded-full flex items-center justify-center">
                <Icon name="Activity" size={16} className="text-muted-foreground" />
              </div>
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-foreground truncate">System Status</p>
                  <p className="text-xs text-success truncate">All systems operational</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Spacer */}
      <div className={`
        transition-all duration-300 ease-in-out
        ${isCollapsed ? 'lg:ml-16' : 'lg:ml-64'}
      `} />
    </>
  );
};

export default Sidebar;