import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import RelationshipMatrix from './components/RelationshipMatrix';
import RelationshipControls from './components/RelationshipControls';
import RelationshipDetails from './components/RelationshipDetails';
import NetworkDiagram from './components/NetworkDiagram';
import HierarchicalTree from './components/HierarchicalTree';

const ArchitectureRelationships = () => {
  const [selectedXAxis, setSelectedXAxis] = useState('Applications');
  const [selectedYAxis, setSelectedYAxis] = useState('Technologies');
  const [viewMode, setViewMode] = useState('matrix');
  const [zoomLevel, setZoomLevel] = useState(1);
  const [selectedRelationship, setSelectedRelationship] = useState(null);
  const [isControlsCollapsed, setIsControlsCollapsed] = useState(false);
  const [isDetailsCollapsed, setIsDetailsCollapsed] = useState(false);
  const [expandedNodes, setExpandedNodes] = useState(['root']);
  const [selectedTypes, setSelectedTypes] = useState(['dependency', 'integration', 'ownership', 'support']);

  // Mock data for different architecture domains
  const mockBusinessFunctions = [
    { id: 'bf1', name: 'Production Planning', type: 'Business Functions', description: 'Strategic production planning and scheduling' },
    { id: 'bf2', name: 'Quality Control', type: 'Business Functions', description: 'Quality assurance and control processes' },
    { id: 'bf3', name: 'Asset Management', type: 'Business Functions', description: 'Physical asset lifecycle management' },
    { id: 'bf4', name: 'Safety Management', type: 'Business Functions', description: 'Workplace safety and compliance' },
    { id: 'bf5', name: 'Environmental Monitoring', type: 'Business Functions', description: 'Environmental compliance and monitoring' },
    { id: 'bf6', name: 'Supply Chain', type: 'Business Functions', description: 'Supply chain optimization and management' }
  ];

  const mockApplications = [
    { id: 'app1', name: 'IBM Maximo', type: 'Applications', description: 'Enterprise asset management system', icsLevel: '3.5' },
    { id: 'app2', name: 'Oracle ERP', type: 'Applications', description: 'Enterprise resource planning system', icsLevel: '4' },
    { id: 'app3', name: 'AspenTech PI', type: 'Applications', description: 'Process information management', icsLevel: '3' },
    { id: 'app4', name: 'LabVantage LIMS', type: 'Applications', description: 'Laboratory information management', icsLevel: '3.7' },
    { id: 'app5', name: 'Wonderware HMI', type: 'Applications', description: 'Human machine interface system', icsLevel: '2' },
    { id: 'app6', name: 'Honeywell DCS', type: 'Applications', description: 'Distributed control system', icsLevel: '1' }
  ];

  const mockTechnologies = [
    { id: 'tech1', name: 'Windows Server 2019', type: 'Technologies', description: 'Enterprise server operating system', status: 'Production' },
    { id: 'tech2', name: 'VMware vSphere', type: 'Technologies', description: 'Virtualization platform', status: 'Production' },
    { id: 'tech3', name: 'Cisco Catalyst', type: 'Technologies', description: 'Network switching infrastructure', status: 'Production' },
    { id: 'tech4', name: 'Azure SQL Database', type: 'Technologies', description: 'Cloud database service', status: 'Development' },
    { id: 'tech5', name: 'Red Hat Linux', type: 'Technologies', description: 'Enterprise Linux distribution', status: 'Production' },
    { id: 'tech6', name: 'Docker Containers', type: 'Technologies', description: 'Application containerization', status: 'Planned' }
  ];

  const mockSecurityComponents = [
    { id: 'sec1', name: 'Palo Alto Firewall', type: 'Security Components', description: 'Next-generation firewall', criticality: 'critical' },
    { id: 'sec2', name: 'CyberArk PAM', type: 'Security Components', description: 'Privileged access management', criticality: 'high' },
    { id: 'sec3', name: 'Splunk SIEM', type: 'Security Components', description: 'Security information and event management', criticality: 'high' },
    { id: 'sec4', name: 'Symantec Endpoint', type: 'Security Components', description: 'Endpoint protection platform', criticality: 'medium' },
    { id: 'sec5', name: 'Qualys VMDR', type: 'Security Components', description: 'Vulnerability management', criticality: 'medium' },
    { id: 'sec6', name: 'Azure AD', type: 'Security Components', description: 'Identity and access management', criticality: 'critical' }
  ];

  const mockTeams = [
    { id: 'team1', name: 'CS Team', type: 'Teams', description: 'Control Systems team' },
    { id: 'team2', name: 'CA Team', type: 'Teams', description: 'Control Applications team' },
    { id: 'team3', name: 'CoA Team', type: 'Teams', description: 'Coordination Applications team' },
    { id: 'team4', name: 'ITP Team', type: 'Teams', description: 'IT Production team' },
    { id: 'team5', name: 'ITO Team', type: 'Teams', description: 'IT Operations team' },
    { id: 'team6', name: 'INFRA Team', type: 'Teams', description: 'Infrastructure team' }
  ];

  const mockVendors = [
    { id: 'vendor1', name: 'IBM', type: 'Vendors', description: 'Enterprise software and services' },
    { id: 'vendor2', name: 'Oracle', type: 'Vendors', description: 'Database and enterprise applications' },
    { id: 'vendor3', name: 'AspenTech', type: 'Vendors', description: 'Process optimization software' },
    { id: 'vendor4', name: 'LabVantage', type: 'Vendors', description: 'Laboratory informatics solutions' },
    { id: 'vendor5', name: 'Microsoft', type: 'Vendors', description: 'Cloud and productivity solutions' },
    { id: 'vendor6', name: 'Cisco', type: 'Vendors', description: 'Networking and security solutions' }
  ];

  const mockICSLevels = [
    { id: 'ics0', name: 'Level 0 - Field Devices', type: 'ICS Levels', description: 'Sensors, actuators, and field devices' },
    { id: 'ics1', name: 'Level 1 - Control Systems', type: 'ICS Levels', description: 'PLCs, DCS, and control systems' },
    { id: 'ics2', name: 'Level 2 - Supervisory', type: 'ICS Levels', description: 'HMI and supervisory systems' },
    { id: 'ics3', name: 'Level 3 - Operations', type: 'ICS Levels', description: 'Manufacturing operations management' },
    { id: 'ics3.5', name: 'Level 3.5 - DMZ', type: 'ICS Levels', description: 'Demilitarized zone systems' },
    { id: 'ics3.7', name: 'Level 3.7 - Historian', type: 'ICS Levels', description: 'Data historians and analytics' },
    { id: 'ics4', name: 'Level 4 - Enterprise', type: 'ICS Levels', description: 'Enterprise business systems' }
  ];

  // Mock relationships data
  const mockRelationships = [
    {
      id: 'rel1',
      sourceId: 'app1',
      targetId: 'tech1',
      type: 'dependency',
      strength: 'critical',
      direction: 'bidirectional',
      description: 'IBM Maximo runs on Windows Server 2019 infrastructure',
      impact: 'high',
      owner: 'CS Team',
      lastUpdated: '2024-07-20',
      criticality: 'critical'
    },
    {
      id: 'rel2',
      sourceId: 'app2',
      targetId: 'tech4',
      type: 'integration',
      strength: 'high',
      direction: 'unidirectional',
      description: 'Oracle ERP integrates with Azure SQL Database for data storage',
      impact: 'medium',
      owner: 'ITP Team',
      lastUpdated: '2024-07-18',
      criticality: 'high'
    },
    {
      id: 'rel3',
      sourceId: 'sec1',
      targetId: 'tech3',
      type: 'support',
      strength: 'critical',
      direction: 'bidirectional',
      description: 'Palo Alto Firewall provides security for Cisco network infrastructure',
      impact: 'high',
      owner: 'Network Team',
      lastUpdated: '2024-07-22',
      criticality: 'critical'
    },
    {
      id: 'rel4',
      sourceId: 'bf1',
      targetId: 'app1',
      type: 'ownership',
      strength: 'high',
      direction: 'unidirectional',
      description: 'Production Planning function utilizes IBM Maximo for asset management',
      impact: 'medium',
      owner: 'CA Team',
      lastUpdated: '2024-07-15',
      criticality: 'medium'
    },
    {
      id: 'rel5',
      sourceId: 'team1',
      targetId: 'app5',
      type: 'ownership',
      strength: 'high',
      direction: 'unidirectional',
      description: 'CS Team manages and maintains Wonderware HMI systems',
      impact: 'medium',
      owner: 'CS Team',
      lastUpdated: '2024-07-19',
      criticality: 'high'
    }
  ];

  const relationshipTypes = [
    { id: 'dependency', label: 'Dependencies', description: 'System dependencies and requirements' },
    { id: 'integration', label: 'Integrations', description: 'Data and process integrations' },
    { id: 'ownership', label: 'Ownership', description: 'Team and organizational ownership' },
    { id: 'support', label: 'Support', description: 'Technical support relationships' }
  ];

  // Get data based on selected axis
  const getAxisData = (axisType) => {
    switch (axisType) {
      case 'Business Functions': return mockBusinessFunctions;
      case 'Applications': return mockApplications;
      case 'Technologies': return mockTechnologies;
      case 'Security Components': return mockSecurityComponents;
      case 'Teams': return mockTeams;
      case 'Vendors': return mockVendors;
      case 'ICS Levels': return mockICSLevels;
      default: return [];
    }
  };

  const xAxisData = getAxisData(selectedXAxis);
  const yAxisData = getAxisData(selectedYAxis);

  // Generate hierarchical tree data
  const generateTreeData = () => {
    return [
      {
        id: 'business',
        name: 'Business Architecture',
        type: 'Business Functions',
        relationshipCount: 12,
        status: 'active',
        children: mockBusinessFunctions.map(bf => ({
          ...bf,
          relationshipCount: Math.floor(Math.random() * 8) + 1,
          status: 'active',
          children: mockApplications.filter(app => Math.random() > 0.7).map(app => ({
            ...app,
            relationshipCount: Math.floor(Math.random() * 5) + 1,
            status: Math.random() > 0.8 ? 'pending' : 'active'
          }))
        }))
      },
      {
        id: 'technology',
        name: 'Technology Architecture',
        type: 'Technologies',
        relationshipCount: 18,
        status: 'active',
        children: mockTechnologies.map(tech => ({
          ...tech,
          relationshipCount: Math.floor(Math.random() * 6) + 1,
          status: tech.status === 'Production' ? 'active' : tech.status === 'Development' ? 'pending' : 'inactive',
          children: mockSecurityComponents.filter(sec => Math.random() > 0.6).map(sec => ({
            ...sec,
            relationshipCount: Math.floor(Math.random() * 4) + 1,
            status: 'active'
          }))
        }))
      }
    ];
  };

  const handleCellClick = (xItem, yItem, relationship) => {
    setSelectedRelationship({
      source: xItem,
      target: yItem,
      relationship
    });
    setIsDetailsCollapsed(false);
  };

  const handleNodeClick = (node) => {
    console.log('Node clicked:', node);
  };

  const handleTypeToggle = (typeId, checked) => {
    if (checked) {
      setSelectedTypes([...selectedTypes, typeId]);
    } else {
      setSelectedTypes(selectedTypes.filter(id => id !== typeId));
    }
  };

  const handleToggleExpand = (nodePath) => {
    if (expandedNodes.includes(nodePath)) {
      setExpandedNodes(expandedNodes.filter(path => path !== nodePath));
    } else {
      setExpandedNodes([...expandedNodes, nodePath]);
    }
  };

  const handleExport = () => {
    console.log('Exporting relationship data...');
  };

  const handleReset = () => {
    setSelectedXAxis('Applications');
    setSelectedYAxis('Technologies');
    setViewMode('matrix');
    setZoomLevel(1);
    setSelectedRelationship(null);
    setSelectedTypes(['dependency', 'integration', 'ownership', 'support']);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      
      <div className={`
        transition-all duration-300 ease-in-out pt-16
        ${isControlsCollapsed ? 'ml-8' : 'ml-80'}
        ${isDetailsCollapsed ? 'mr-8' : 'mr-80'}
      `}>
        <div className="p-6">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  Architecture Relationships
                </h1>
                <p className="text-muted-foreground">
                  Interactive cross-architecture mapping and dependency visualization
                </p>
              </div>
              
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  iconName="Download"
                  iconPosition="left"
                  onClick={handleExport}
                >
                  Export Analysis
                </Button>
                <Button
                  variant="outline"
                  iconName="RefreshCw"
                  iconPosition="left"
                  onClick={handleReset}
                >
                  Reset View
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Main Visualization Area */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-6"
          >
            {viewMode === 'matrix' && (
              <RelationshipMatrix
                xAxisData={xAxisData}
                yAxisData={yAxisData}
                relationships={mockRelationships}
                selectedXAxis={selectedXAxis}
                selectedYAxis={selectedYAxis}
                onCellClick={handleCellClick}
                zoomLevel={zoomLevel}
              />
            )}

            {viewMode === 'network' && (
              <NetworkDiagram
                nodes={[...xAxisData, ...yAxisData]}
                relationships={mockRelationships}
                onNodeClick={handleNodeClick}
                selectedNode={selectedRelationship?.source}
                zoomLevel={zoomLevel}
              />
            )}

            {viewMode === 'hierarchy' && (
              <HierarchicalTree
                treeData={generateTreeData()}
                onNodeClick={handleNodeClick}
                selectedNode={selectedRelationship?.source}
                expandedNodes={expandedNodes}
                onToggleExpand={handleToggleExpand}
              />
            )}
          </motion.div>

          {/* Statistics Cards */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6"
          >
            {[
              { 
                title: 'Total Relationships', 
                value: '156', 
                change: '+12', 
                icon: 'Link',
                color: 'text-primary'
              },
              { 
                title: 'Critical Dependencies', 
                value: '23', 
                change: '+3', 
                icon: 'AlertTriangle',
                color: 'text-error'
              },
              { 
                title: 'Architecture Coverage', 
                value: '72%', 
                change: '+5%', 
                icon: 'Target',
                color: 'text-success'
              },
              { 
                title: 'Vendor Relationships', 
                value: '34', 
                change: '+2', 
                icon: 'Package',
                color: 'text-warning'
              }
            ].map((stat, index) => (
              <div
                key={index}
                className="bg-card border border-border rounded-lg p-4 enterprise-shadow-card"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                    <p className="text-xs text-success">
                      {stat.change} from last week
                    </p>
                  </div>
                  <div className={`p-2 rounded-lg bg-muted/30`}>
                    <Icon name={stat.icon} size={20} className={stat.color} />
                  </div>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Control Panel */}
      <RelationshipControls
        selectedXAxis={selectedXAxis}
        selectedYAxis={selectedYAxis}
        onXAxisChange={setSelectedXAxis}
        onYAxisChange={setSelectedYAxis}
        relationshipTypes={relationshipTypes}
        selectedTypes={selectedTypes}
        onTypeToggle={handleTypeToggle}
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        zoomLevel={zoomLevel}
        onZoomChange={setZoomLevel}
        onExport={handleExport}
        onReset={handleReset}
        isCollapsed={isControlsCollapsed}
        onToggleCollapse={() => setIsControlsCollapsed(!isControlsCollapsed)}
      />

      {/* Details Panel */}
      <RelationshipDetails
        selectedRelationship={selectedRelationship}
        onClose={() => setSelectedRelationship(null)}
        isCollapsed={isDetailsCollapsed}
        onToggleCollapse={() => setIsDetailsCollapsed(!isDetailsCollapsed)}
      />
    </div>
  );
};

export default ArchitectureRelationships;