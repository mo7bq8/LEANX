import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RelationshipDetails = ({
  selectedRelationship,
  onClose,
  isCollapsed,
  onToggleCollapse
}) => {
  if (!selectedRelationship) {
    return (
      <motion.div
        initial={{ x: 300 }}
        animate={{ x: isCollapsed ? 250 : 0 }}
        className="fixed right-0 top-16 bottom-0 w-80 bg-card border-l border-border enterprise-shadow-card z-30"
      >
        {/* Collapse Toggle */}
        <div className="absolute -left-10 top-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleCollapse}
            className="bg-card border border-border rounded-l-lg"
          >
            <Icon name={isCollapsed ? "ChevronLeft" : "ChevronRight"} size={16} />
          </Button>
        </div>

        <div className="p-6 h-full flex items-center justify-center">
          <div className="text-center">
            <Icon name="MousePointer" size={48} className="text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">Select a Relationship</h3>
            <p className="text-sm text-muted-foreground">
              Click on any cell in the matrix to view detailed relationship information
            </p>
          </div>
        </div>
      </motion.div>
    );
  }

  const { source, target, relationship } = selectedRelationship;

  const getImpactLevel = (level) => {
    const levels = {
      high: { color: 'text-error', bg: 'bg-error/10', icon: 'AlertTriangle' },
      medium: { color: 'text-warning', bg: 'bg-warning/10', icon: 'AlertCircle' },
      low: { color: 'text-success', bg: 'bg-success/10', icon: 'CheckCircle' }
    };
    return levels[level] || levels.low;
  };

  const impactStyle = getImpactLevel(relationship?.impact || 'low');

  return (
    <motion.div
      initial={{ x: 300 }}
      animate={{ x: isCollapsed ? 250 : 0 }}
      className="fixed right-0 top-16 bottom-0 w-80 bg-card border-l border-border enterprise-shadow-card z-30 overflow-y-auto"
    >
      {/* Collapse Toggle */}
      <div className="absolute -left-10 top-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          className="bg-card border border-border rounded-l-lg"
        >
          <Icon name={isCollapsed ? "ChevronLeft" : "ChevronRight"} size={16} />
        </Button>
      </div>

      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Link" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Relationship Details</h3>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <Icon name="X" size={16} />
          </Button>
        </div>

        {/* Relationship Overview */}
        <div className="bg-muted/30 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-foreground">Connection</span>
            <div className={`px-2 py-1 rounded text-xs font-medium ${impactStyle.bg} ${impactStyle.color}`}>
              {relationship?.strength || 'Unknown'} Impact
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="flex-1 text-center">
              <div className="text-sm font-medium text-foreground">{source.name}</div>
              <div className="text-xs text-muted-foreground">{source.type}</div>
            </div>
            <Icon name="ArrowRight" size={16} className="text-muted-foreground" />
            <div className="flex-1 text-center">
              <div className="text-sm font-medium text-foreground">{target.name}</div>
              <div className="text-xs text-muted-foreground">{target.type}</div>
            </div>
          </div>
        </div>

        {/* Relationship Properties */}
        {relationship && (
          <div className="space-y-4">
            <h4 className="text-sm font-semibold text-foreground">Properties</h4>
            
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Type:</span>
                <span className="text-sm text-foreground capitalize">{relationship.type}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Direction:</span>
                <span className="text-sm text-foreground capitalize">{relationship.direction || 'bidirectional'}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Criticality:</span>
                <span className={`text-sm capitalize ${
                  relationship.criticality === 'critical' ? 'text-error' :
                  relationship.criticality === 'high' ? 'text-warning' :
                  relationship.criticality === 'medium'? 'text-accent' : 'text-success'
                }`}>
                  {relationship.criticality || 'low'}
                </span>
              </div>
              
              {relationship.owner && (
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Owner:</span>
                  <span className="text-sm text-foreground">{relationship.owner}</span>
                </div>
              )}
              
              {relationship.lastUpdated && (
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Last Updated:</span>
                  <span className="text-sm text-foreground">{relationship.lastUpdated}</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Description */}
        {relationship?.description && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-foreground">Description</h4>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {relationship.description}
            </p>
          </div>
        )}

        {/* Impact Analysis */}
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-foreground">Impact Analysis</h4>
          <div className="bg-muted/20 rounded-lg p-3 space-y-2">
            <div className="flex items-center space-x-2">
              <Icon name={impactStyle.icon} size={16} className={impactStyle.color} />
              <span className="text-sm font-medium text-foreground">
                {relationship?.impact === 'high' ? 'High Impact' :
                 relationship?.impact === 'medium'? 'Medium Impact' : 'Low Impact'}
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              {relationship?.impact === 'high' 
                ? `Changes to this relationship may significantly affect system operations and require careful planning.`
                : relationship?.impact === 'medium'
                ? `Moderate impact on related systems. Standard change management procedures apply.`
                : `Low impact relationship. Changes can be implemented with minimal risk.`
              }
            </p>
          </div>
        </div>

        {/* Change History */}
        <div className="space-y-3">
          <h4 className="text-sm font-semibold text-foreground">Recent Changes</h4>
          <div className="space-y-2">
            {[
              {
                date: '2024-07-20',
                action: 'Relationship strength updated',
                user: 'Sarah Chen',
                details: 'Changed from Medium to High impact'
              },
              {
                date: '2024-07-15',
                action: 'Owner assignment',
                user: 'Mike Rodriguez',
                details: 'Assigned to CS Team for maintenance'
              },
              {
                date: '2024-07-10',
                action: 'Relationship created',
                user: 'Sarah Chen',
                details: 'Initial relationship mapping'
              }
            ].map((change, index) => (
              <div key={index} className="bg-muted/20 rounded-lg p-3">
                <div className="flex justify-between items-start mb-1">
                  <span className="text-xs font-medium text-foreground">{change.action}</span>
                  <span className="text-xs text-muted-foreground">{change.date}</span>
                </div>
                <p className="text-xs text-muted-foreground mb-1">{change.details}</p>
                <span className="text-xs text-accent">by {change.user}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 pt-4 border-t border-border">
          <Button
            variant="outline"
            iconName="Edit"
            iconPosition="left"
            fullWidth
          >
            Edit Relationship
          </Button>
          <Button
            variant="outline"
            iconName="Share"
            iconPosition="left"
            fullWidth
          >
            Share Analysis
          </Button>
          <Button
            variant="ghost"
            iconName="Trash2"
            iconPosition="left"
            fullWidth
            className="text-error hover:text-error"
          >
            Remove Relationship
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default RelationshipDetails;