import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const RelationshipMatrix = ({ 
  xAxisData, 
  yAxisData, 
  relationships, 
  selectedXAxis, 
  selectedYAxis,
  onCellClick,
  zoomLevel = 1 
}) => {
  const [hoveredCell, setHoveredCell] = useState(null);

  // Generate matrix data based on relationships
  const matrixData = useMemo(() => {
    const matrix = {};
    
    xAxisData.forEach(xItem => {
      matrix[xItem.id] = {};
      yAxisData.forEach(yItem => {
        const relationship = relationships.find(rel => 
          (rel.sourceId === xItem.id && rel.targetId === yItem.id) ||
          (rel.sourceId === yItem.id && rel.targetId === xItem.id)
        );
        matrix[xItem.id][yItem.id] = relationship || null;
      });
    });
    
    return matrix;
  }, [xAxisData, yAxisData, relationships]);

  const getRelationshipColor = (relationship) => {
    if (!relationship) return 'bg-muted/20';
    
    switch (relationship.strength) {
      case 'critical': return 'bg-error/80';
      case 'high': return 'bg-warning/80';
      case 'medium': return 'bg-accent/80';
      case 'low': return 'bg-success/80';
      default: return 'bg-muted/40';
    }
  };

  const getRelationshipIcon = (relationship) => {
    if (!relationship) return null;
    
    switch (relationship.type) {
      case 'dependency': return 'ArrowRight';
      case 'integration': return 'Link';
      case 'ownership': return 'User';
      case 'support': return 'Wrench';
      default: return 'Circle';
    }
  };

  return (
    <div className="relative bg-card rounded-lg border border-border overflow-hidden">
      {/* Matrix Header */}
      <div className="p-4 border-b border-border bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Grid3X3" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">
              {selectedXAxis} vs {selectedYAxis} Relationships
            </h3>
          </div>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>{xAxisData.length} × {yAxisData.length} matrix</span>
          </div>
        </div>
      </div>

      {/* Matrix Container */}
      <div className="relative overflow-auto" style={{ maxHeight: '600px' }}>
        <div 
          className="relative"
          style={{ 
            transform: `scale(${zoomLevel})`,
            transformOrigin: 'top left'
          }}
        >
          {/* Y-Axis Labels */}
          <div className="flex">
            <div className="w-48 flex-shrink-0"></div>
            <div className="flex">
              {xAxisData.map((xItem, xIndex) => (
                <div
                  key={xItem.id}
                  className="w-24 h-12 flex items-center justify-center border-r border-border bg-muted/20 text-xs font-medium text-foreground p-1"
                  title={xItem.name}
                >
                  <span className="truncate transform -rotate-45 origin-center">
                    {xItem.name}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Matrix Rows */}
          {yAxisData.map((yItem, yIndex) => (
            <div key={yItem.id} className="flex border-b border-border">
              {/* X-Axis Label */}
              <div className="w-48 flex-shrink-0 h-12 flex items-center px-3 bg-muted/20 border-r border-border">
                <span className="text-xs font-medium text-foreground truncate" title={yItem.name}>
                  {yItem.name}
                </span>
              </div>

              {/* Matrix Cells */}
              <div className="flex">
                {xAxisData.map((xItem, xIndex) => {
                  const relationship = matrixData[xItem.id]?.[yItem.id];
                  const cellKey = `${xItem.id}-${yItem.id}`;
                  
                  return (
                    <motion.div
                      key={cellKey}
                      className={`
                        w-24 h-12 border-r border-border cursor-pointer relative
                        flex items-center justify-center
                        ${getRelationshipColor(relationship)}
                        hover:ring-2 hover:ring-primary/50 transition-all duration-200
                      `}
                      whileHover={{ scale: 1.05 }}
                      onMouseEnter={() => setHoveredCell({ xItem, yItem, relationship })}
                      onMouseLeave={() => setHoveredCell(null)}
                      onClick={() => onCellClick && onCellClick(xItem, yItem, relationship)}
                    >
                      {relationship && (
                        <Icon 
                          name={getRelationshipIcon(relationship)} 
                          size={16} 
                          className="text-white" 
                        />
                      )}
                      
                      {/* Hover Tooltip */}
                      {hoveredCell?.xItem.id === xItem.id && hoveredCell?.yItem.id === yItem.id && (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 z-50 bg-popover border border-border rounded-lg shadow-lg p-3 min-w-64"
                        >
                          <div className="text-sm">
                            <div className="font-semibold text-foreground mb-2">
                              {xItem.name} ↔ {yItem.name}
                            </div>
                            {relationship ? (
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Type:</span>
                                  <span className="text-foreground capitalize">{relationship.type}</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-muted-foreground">Strength:</span>
                                  <span className={`capitalize ${
                                    relationship.strength === 'critical' ? 'text-error' :
                                    relationship.strength === 'high' ? 'text-warning' :
                                    relationship.strength === 'medium'? 'text-accent' : 'text-success'
                                  }`}>
                                    {relationship.strength}
                                  </span>
                                </div>
                                {relationship.description && (
                                  <div className="mt-2 text-xs text-muted-foreground">
                                    {relationship.description}
                                  </div>
                                )}
                              </div>
                            ) : (
                              <div className="text-muted-foreground">No relationship</div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="p-4 border-t border-border bg-muted/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-foreground">Relationship Strength:</span>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 bg-error/80 rounded"></div>
                <span className="text-xs text-muted-foreground">Critical</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 bg-warning/80 rounded"></div>
                <span className="text-xs text-muted-foreground">High</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 bg-accent/80 rounded"></div>
                <span className="text-xs text-muted-foreground">Medium</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 bg-success/80 rounded"></div>
                <span className="text-xs text-muted-foreground">Low</span>
              </div>
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Click cells to view detailed relationship information
          </div>
        </div>
      </div>
    </div>
  );
};

export default RelationshipMatrix;