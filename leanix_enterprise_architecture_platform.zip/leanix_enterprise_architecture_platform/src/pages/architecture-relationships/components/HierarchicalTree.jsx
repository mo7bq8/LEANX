import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const HierarchicalTree = ({ 
  treeData, 
  onNodeClick, 
  selectedNode,
  expandedNodes,
  onToggleExpand 
}) => {
  const [hoveredNode, setHoveredNode] = useState(null);

  const getNodeIcon = (nodeType) => {
    switch (nodeType) {
      case 'Business Functions': return 'Building';
      case 'Applications': return 'Layers';
      case 'Technologies': return 'Server';
      case 'Security Components': return 'Shield';
      case 'Teams': return 'Users';
      case 'Vendors': return 'Package';
      default: return 'Circle';
    }
  };

  const getNodeColor = (nodeType) => {
    switch (nodeType) {
      case 'Business Functions': return 'text-blue-600 bg-blue-50';
      case 'Applications': return 'text-emerald-600 bg-emerald-50';
      case 'Technologies': return 'text-amber-600 bg-amber-50';
      case 'Security Components': return 'text-red-600 bg-red-50';
      case 'Teams': return 'text-purple-600 bg-purple-50';
      case 'Vendors': return 'text-sky-600 bg-sky-50';
      default: return 'text-slate-600 bg-slate-50';
    }
  };

  const TreeNode = ({ node, level = 0, parentPath = '' }) => {
    const nodePath = parentPath ? `${parentPath}.${node.id}` : node.id;
    const isExpanded = expandedNodes.includes(nodePath);
    const hasChildren = node.children && node.children.length > 0;
    const isSelected = selectedNode?.id === node.id;

    return (
      <div className="relative">
        {/* Node */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: level * 0.1 }}
          className={`
            flex items-center space-x-2 p-2 rounded-lg cursor-pointer
            transition-all duration-200 hover:bg-muted/50
            ${isSelected ? 'bg-primary/10 border border-primary/20' : ''}
          `}
          style={{ marginLeft: `${level * 24}px` }}
          onMouseEnter={() => setHoveredNode(node)}
          onMouseLeave={() => setHoveredNode(null)}
          onClick={() => onNodeClick(node)}
        >
          {/* Expand/Collapse Button */}
          {hasChildren && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onToggleExpand(nodePath);
              }}
              className="p-1 hover:bg-muted rounded transition-colors"
            >
              <Icon 
                name={isExpanded ? "ChevronDown" : "ChevronRight"} 
                size={14} 
                className="text-muted-foreground"
              />
            </button>
          )}
          
          {!hasChildren && <div className="w-6"></div>}

          {/* Node Icon */}
          <div className={`p-1.5 rounded ${getNodeColor(node.type)}`}>
            <Icon 
              name={getNodeIcon(node.type)} 
              size={16} 
            />
          </div>

          {/* Node Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm font-medium text-foreground truncate">
                  {node.name}
                </span>
                <div className="text-xs text-muted-foreground">
                  {node.type}
                  {node.relationshipCount && (
                    <span className="ml-2">
                      • {node.relationshipCount} connection{node.relationshipCount !== 1 ? 's' : ''}
                    </span>
                  )}
                </div>
              </div>
              
              {/* Status Indicators */}
              <div className="flex items-center space-x-1">
                {node.criticality && (
                  <div className={`
                    px-2 py-0.5 rounded text-xs font-medium
                    ${node.criticality === 'critical' ? 'bg-red-100 text-red-700' :
                      node.criticality === 'high' ? 'bg-amber-100 text-amber-700' :
                      node.criticality === 'medium'? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}
                  `}>
                    {node.criticality}
                  </div>
                )}
                
                {node.status && (
                  <div className={`
                    w-2 h-2 rounded-full
                    ${node.status === 'active' ? 'bg-green-500' :
                      node.status === 'inactive' ? 'bg-red-500' :
                      node.status === 'pending'? 'bg-amber-500' : 'bg-slate-400'}
                  `}
                  title={`Status: ${node.status}`}
                  />
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Children */}
        <AnimatePresence>
          {hasChildren && isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              {node.children.map((child, index) => (
                <TreeNode
                  key={child.id}
                  node={child}
                  level={level + 1}
                  parentPath={nodePath}
                />
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Hover Tooltip */}
        {hoveredNode?.id === node.id && node.description && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute left-full top-0 ml-4 z-50 bg-popover border border-border rounded-lg shadow-lg p-3 max-w-64"
          >
            <div className="text-sm">
              <div className="font-semibold text-foreground mb-1">{node.name}</div>
              <div className="text-xs text-muted-foreground mb-2">{node.type}</div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                {node.description}
              </p>
              {node.owner && (
                <div className="text-xs text-muted-foreground mt-2">
                  <span className="font-medium">Owner:</span> {node.owner}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </div>
    );
  };

  return (
    <div className="relative bg-card rounded-lg border border-border overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="GitBranch" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Hierarchical Tree View</h3>
          </div>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>{treeData.length} root nodes</span>
          </div>
        </div>
      </div>

      {/* Tree Content */}
      <div className="p-4 overflow-auto" style={{ maxHeight: '600px' }}>
        <div className="space-y-1">
          {treeData.map((rootNode) => (
            <TreeNode key={rootNode.id} node={rootNode} />
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border bg-muted/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-foreground">Legend:</span>
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span className="text-xs text-muted-foreground">Active</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                <span className="text-xs text-muted-foreground">Pending</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                <span className="text-xs text-muted-foreground">Inactive</span>
              </div>
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Click to expand/collapse • Hover for details
          </div>
        </div>
      </div>
    </div>
  );
};

export default HierarchicalTree;