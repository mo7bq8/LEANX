import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const RelationshipControls = ({
  selectedXAxis,
  selectedYAxis,
  onXAxisChange,
  onYAxisChange,
  relationshipTypes,
  selectedTypes,
  onTypeToggle,
  viewMode,
  onViewModeChange,
  zoomLevel,
  onZoomChange,
  onExport,
  onReset,
  isCollapsed,
  onToggleCollapse
}) => {
  const axisOptions = [
    { value: 'Business Functions', label: 'Business Functions' },
    { value: 'Applications', label: 'Applications' },
    { value: 'Technologies', label: 'Technologies' },
    { value: 'Security Components', label: 'Security Components' },
    { value: 'Teams', label: 'Teams' },
    { value: 'Vendors', label: 'Vendors' },
    { value: 'ICS Levels', label: 'ICS Levels' }
  ];

  const viewModeOptions = [
    { value: 'matrix', label: 'Matrix View', icon: 'Grid3X3' },
    { value: 'network', label: 'Network Diagram', icon: 'Network' },
    { value: 'hierarchy', label: 'Hierarchical Tree', icon: 'GitBranch' }
  ];

  return (
    <motion.div
      initial={{ x: -300 }}
      animate={{ x: isCollapsed ? -250 : 0 }}
      className="fixed left-0 top-16 bottom-0 w-80 bg-card border-r border-border enterprise-shadow-card z-30 overflow-y-auto"
    >
      {/* Collapse Toggle */}
      <div className="absolute -right-10 top-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleCollapse}
          className="bg-card border border-border rounded-r-lg"
        >
          <Icon name={isCollapsed ? "ChevronRight" : "ChevronLeft"} size={16} />
        </Button>
      </div>

      <div className="p-6 space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-2">
          <Icon name="Settings" size={20} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Relationship Controls</h3>
        </div>

        {/* Axis Selection */}
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              X-Axis (Horizontal)
            </label>
            <Select
              options={axisOptions}
              value={selectedXAxis}
              onChange={onXAxisChange}
              placeholder="Select X-axis data"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Y-Axis (Vertical)
            </label>
            <Select
              options={axisOptions}
              value={selectedYAxis}
              onChange={onYAxisChange}
              placeholder="Select Y-axis data"
            />
          </div>
        </div>

        {/* View Mode Selection */}
        <div className="space-y-3">
          <label className="text-sm font-medium text-foreground">View Mode</label>
          <div className="grid grid-cols-1 gap-2">
            {viewModeOptions.map((mode) => (
              <Button
                key={mode.value}
                variant={viewMode === mode.value ? "default" : "outline"}
                onClick={() => onViewModeChange(mode.value)}
                className="justify-start"
                iconName={mode.icon}
                iconPosition="left"
              >
                {mode.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Relationship Type Filters */}
        <div className="space-y-3">
          <label className="text-sm font-medium text-foreground">Relationship Types</label>
          <div className="space-y-2">
            {relationshipTypes.map((type) => (
              <Checkbox
                key={type.id}
                label={type.label}
                description={type.description}
                checked={selectedTypes.includes(type.id)}
                onChange={(e) => onTypeToggle(type.id, e.target.checked)}
              />
            ))}
          </div>
        </div>

        {/* Zoom Controls */}
        <div className="space-y-3">
          <label className="text-sm font-medium text-foreground">Zoom Level</label>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => onZoomChange(Math.max(0.5, zoomLevel - 0.1))}
              disabled={zoomLevel <= 0.5}
            >
              <Icon name="ZoomOut" size={16} />
            </Button>
            <div className="flex-1 text-center">
              <span className="text-sm text-muted-foreground">
                {Math.round(zoomLevel * 100)}%
              </span>
            </div>
            <Button
              variant="outline"
              size="icon"
              onClick={() => onZoomChange(Math.min(2, zoomLevel + 0.1))}
              disabled={zoomLevel >= 2}
            >
              <Icon name="ZoomIn" size={16} />
            </Button>
          </div>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={zoomLevel}
            onChange={(e) => onZoomChange(parseFloat(e.target.value))}
            className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
          />
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-4 border-t border-border">
          <Button
            variant="outline"
            onClick={onExport}
            iconName="Download"
            iconPosition="left"
            fullWidth
          >
            Export Relationships
          </Button>
          <Button
            variant="ghost"
            onClick={onReset}
            iconName="RotateCcw"
            iconPosition="left"
            fullWidth
          >
            Reset View
          </Button>
        </div>

        {/* Statistics */}
        <div className="bg-muted/30 rounded-lg p-4 space-y-2">
          <h4 className="text-sm font-medium text-foreground">Current View Stats</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div>
              <span className="text-muted-foreground">X-Axis Items:</span>
              <span className="text-foreground font-medium ml-1">24</span>
            </div>
            <div>
              <span className="text-muted-foreground">Y-Axis Items:</span>
              <span className="text-foreground font-medium ml-1">18</span>
            </div>
            <div>
              <span className="text-muted-foreground">Relationships:</span>
              <span className="text-foreground font-medium ml-1">156</span>
            </div>
            <div>
              <span className="text-muted-foreground">Coverage:</span>
              <span className="text-foreground font-medium ml-1">72%</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default RelationshipControls;