import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const NetworkDiagram = ({ 
  nodes, 
  relationships, 
  onNodeClick, 
  selectedNode,
  zoomLevel = 1 
}) => {
  const svgRef = useRef(null);
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const [hoveredNode, setHoveredNode] = useState(null);

  useEffect(() => {
    const updateDimensions = () => {
      if (svgRef.current) {
        const rect = svgRef.current.getBoundingClientRect();
        setDimensions({ width: rect.width, height: rect.height });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  // Calculate node positions using force-directed layout simulation
  const calculateNodePositions = () => {
    const centerX = dimensions.width / 2;
    const centerY = dimensions.height / 2;
    const radius = Math.min(dimensions.width, dimensions.height) * 0.3;

    return nodes.map((node, index) => {
      const angle = (index / nodes.length) * 2 * Math.PI;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      
      return {
        ...node,
        x,
        y,
        connections: relationships.filter(rel => 
          rel.sourceId === node.id || rel.targetId === node.id
        ).length
      };
    });
  };

  const positionedNodes = calculateNodePositions();

  const getNodeColor = (node) => {
    switch (node.type) {
      case 'Business Functions': return '#2563EB';
      case 'Applications': return '#059669';
      case 'Technologies': return '#D97706';
      case 'Security Components': return '#DC2626';
      case 'Teams': return '#7C3AED';
      case 'Vendors': return '#0EA5E9';
      default: return '#64748B';
    }
  };

  const getNodeSize = (connections) => {
    return Math.max(20, Math.min(40, 20 + connections * 2));
  };

  const drawConnection = (source, target, relationship) => {
    const sourceNode = positionedNodes.find(n => n.id === source);
    const targetNode = positionedNodes.find(n => n.id === target);
    
    if (!sourceNode || !targetNode) return null;

    const strokeWidth = relationship.strength === 'critical' ? 3 : 
                      relationship.strength === 'high' ? 2 : 1;
    const strokeColor = relationship.strength === 'critical' ? '#DC2626' :
                       relationship.strength === 'high' ? '#D97706' :
                       relationship.strength === 'medium' ? '#0EA5E9' : '#64748B';

    return (
      <line
        key={`${source}-${target}`}
        x1={sourceNode.x}
        y1={sourceNode.y}
        x2={targetNode.x}
        y2={targetNode.y}
        stroke={strokeColor}
        strokeWidth={strokeWidth}
        opacity={0.6}
        className="transition-all duration-200"
      />
    );
  };

  return (
    <div className="relative bg-card rounded-lg border border-border overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-border bg-muted/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Network" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Network Diagram</h3>
          </div>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>{nodes.length} nodes</span>
            <span>•</span>
            <span>{relationships.length} connections</span>
          </div>
        </div>
      </div>

      {/* Network Visualization */}
      <div className="relative" style={{ height: '600px' }}>
        <svg
          ref={svgRef}
          width="100%"
          height="100%"
          className="absolute inset-0"
          style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center' }}
        >
          {/* Connections */}
          <g className="connections">
            {relationships.map(relationship => 
              drawConnection(relationship.sourceId, relationship.targetId, relationship)
            )}
          </g>

          {/* Nodes */}
          <g className="nodes">
            {positionedNodes.map(node => (
              <g key={node.id}>
                <circle
                  cx={node.x}
                  cy={node.y}
                  r={getNodeSize(node.connections)}
                  fill={getNodeColor(node)}
                  stroke={selectedNode?.id === node.id ? '#2563EB' : 'white'}
                  strokeWidth={selectedNode?.id === node.id ? 3 : 2}
                  className="cursor-pointer transition-all duration-200 hover:stroke-primary hover:stroke-2"
                  onMouseEnter={() => setHoveredNode(node)}
                  onMouseLeave={() => setHoveredNode(null)}
                  onClick={() => onNodeClick(node)}
                />
                
                {/* Node Label */}
                <text
                  x={node.x}
                  y={node.y + getNodeSize(node.connections) + 15}
                  textAnchor="middle"
                  className="text-xs font-medium fill-foreground pointer-events-none"
                  style={{ fontSize: '10px' }}
                >
                  {node.name.length > 12 ? `${node.name.substring(0, 12)}...` : node.name}
                </text>

                {/* Connection Count Badge */}
                {node.connections > 0 && (
                  <circle
                    cx={node.x + getNodeSize(node.connections) * 0.7}
                    cy={node.y - getNodeSize(node.connections) * 0.7}
                    r="8"
                    fill="#2563EB"
                    className="pointer-events-none"
                  />
                )}
                {node.connections > 0 && (
                  <text
                    x={node.x + getNodeSize(node.connections) * 0.7}
                    y={node.y - getNodeSize(node.connections) * 0.7 + 3}
                    textAnchor="middle"
                    className="text-xs font-bold fill-white pointer-events-none"
                    style={{ fontSize: '8px' }}
                  >
                    {node.connections}
                  </text>
                )}
              </g>
            ))}
          </g>
        </svg>

        {/* Node Tooltip */}
        {hoveredNode && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute bg-popover border border-border rounded-lg shadow-lg p-3 pointer-events-none z-50"
            style={{
              left: hoveredNode.x + 20,
              top: hoveredNode.y - 50,
              transform: 'translate(-50%, -100%)'
            }}
          >
            <div className="text-sm">
              <div className="font-semibold text-foreground">{hoveredNode.name}</div>
              <div className="text-xs text-muted-foreground mt-1">{hoveredNode.type}</div>
              <div className="text-xs text-muted-foreground">
                {hoveredNode.connections} connection{hoveredNode.connections !== 1 ? 's' : ''}
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {/* Legend */}
      <div className="p-4 border-t border-border bg-muted/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-foreground">Node Types:</span>
            <div className="flex items-center space-x-3">
              {[
                { type: 'Business Functions', color: '#2563EB' },
                { type: 'Applications', color: '#059669' },
                { type: 'Technologies', color: '#D97706' },
                { type: 'Security Components', color: '#DC2626' }
              ].map(item => (
                <div key={item.type} className="flex items-center space-x-1">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span className="text-xs text-muted-foreground">{item.type}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            Node size indicates connection count • Click nodes for details
          </div>
        </div>
      </div>
    </div>
  );
};

export default NetworkDiagram;