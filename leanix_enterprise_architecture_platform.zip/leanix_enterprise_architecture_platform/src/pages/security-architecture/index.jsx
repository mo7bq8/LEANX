import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import SecurityTable from './components/SecurityTable';
import SecuritySidebar from './components/SecuritySidebar';
import ICSLevelsVisualization from './components/ICSLevelsVisualization';
import NetworkArchitecture from './components/NetworkArchitecture';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import securityService from '../../services/securityService';

const SecurityArchitecture = () => {
  const [selectedComponent, setSelectedComponent] = useState(null);
  const [activeView, setActiveView] = useState('table');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [securityComponents, setSecurityComponents] = useState([]);
  const [statistics, setStatistics] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load security components data from SQLite
  useEffect(() => {
    loadSecurityComponents();
    loadStatistics();
  }, []);

  const loadSecurityComponents = async () => {
    try {
      setLoading(true);
      const data = await securityService.getAllSecurityComponents();
      setSecurityComponents(data);
      setError(null);
    } catch (err) {
      console.error('Failed to load security components:', err);
      setError('Failed to load security components');
    } finally {
      setLoading(false);
    }
  };

  const loadStatistics = async () => {
    try {
      const stats = await securityService.getStatistics();
      setStatistics(stats);
    } catch (err) {
      console.error('Failed to load statistics:', err);
    }
  };

  const handleComponentSelect = (component) => {
    setSelectedComponent(component);
    setIsSidebarOpen(true);
  };

  const handleCloseSidebar = () => {
    setIsSidebarOpen(false);
    setSelectedComponent(null);
  };

  const handleLevelSelect = (level) => {
    // Filter components by ICS level if needed
    console.log('Selected ICS Level:', level);
  };

  useEffect(() => {
    document.title = 'Security Architecture - LeanIX Enterprise Architecture Platform';
  }, []);

  const viewOptions = [
    { id: 'table', label: 'Components Table', icon: 'Table' },
    { id: 'ics', label: 'ICS Levels', icon: 'Layers' },
    { id: 'network', label: 'Network Architecture', icon: 'Network' }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Sidebar />
        <main className="pt-16 lg:ml-64">
          <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading security components...</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Sidebar />
        <main className="pt-16 lg:ml-64">
          <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
            <div className="text-center">
              <Icon name="AlertCircle" size={48} className="text-error mx-auto mb-4" />
              <p className="text-error mb-4">{error}</p>
              <button
                onClick={() => {
                  setError(null);
                  loadSecurityComponents();
                }}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              >
                Retry
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      
      <main className="pt-16 lg:ml-64">
        <div className="p-6">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Security Architecture</h1>
                <p className="text-muted-foreground mt-2">
                  Comprehensive security component management with criticality assessment and compliance tracking
                </p>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 bg-card border border-border rounded-lg p-1">
                  {viewOptions.map((option) => (
                    <Button
                      key={option.id}
                      variant={activeView === option.id ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setActiveView(option.id)}
                      className="flex items-center space-x-2"
                    >
                      <Icon name={option.icon} size={16} />
                      <span className="hidden md:inline">{option.label}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Statistics Cards */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
          >
            <div className="bg-card rounded-lg border border-border p-6 enterprise-shadow-card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Total Components</p>
                  <p className="text-2xl font-bold text-foreground">{statistics?.totalComponents || securityComponents.length}</p>
                </div>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Icon name="Shield" size={24} className="text-primary" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <Icon name="TrendingUp" size={16} className="text-success mr-1" />
                <span className="text-success">+2.5%</span>
                <span className="text-muted-foreground ml-1">from last month</span>
              </div>
            </div>

            <div className="bg-card rounded-lg border border-border p-6 enterprise-shadow-card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Critical Components</p>
                  <p className="text-2xl font-bold text-error">
                    {statistics?.criticalComponents || securityComponents.filter(c => c.criticality === 'Critical').length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-error/10 rounded-lg flex items-center justify-center">
                  <Icon name="AlertTriangle" size={24} className="text-error" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <Icon name="AlertCircle" size={16} className="text-warning mr-1" />
                <span className="text-warning">Requires attention</span>
              </div>
            </div>

            <div className="bg-card rounded-lg border border-border p-6 enterprise-shadow-card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Compliance Rate</p>
                  <p className="text-2xl font-bold text-success">
                    {statistics?.complianceRate || Math.round((securityComponents.filter(c => c.criticality === 'Low' || c.criticality === 'Medium').length / securityComponents.length) * 100) || 0}%
                  </p>
                </div>
                <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
                  <Icon name="CheckCircle" size={24} className="text-success" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <Icon name="TrendingUp" size={16} className="text-success mr-1" />
                <span className="text-success">+5.2%</span>
                <span className="text-muted-foreground ml-1">improvement</span>
              </div>
            </div>

            <div className="bg-card rounded-lg border border-border p-6 enterprise-shadow-card">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Avg Risk Score</p>
                  <p className="text-2xl font-bold text-foreground">
                    {statistics?.avgRiskScore || (securityComponents.length > 0 ? 
                      (securityComponents.reduce((sum, c) => sum + (c.risk_score || 0), 0) / securityComponents.length).toFixed(1) : '0')}
                  </p>
                </div>
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                  <Icon name="BarChart3" size={24} className="text-accent" />
                </div>
              </div>
              <div className="mt-4 flex items-center text-sm">
                <Icon name="TrendingDown" size={16} className="text-success mr-1" />
                <span className="text-success">-0.3</span>
                <span className="text-muted-foreground ml-1">risk reduction</span>
              </div>
            </div>
          </motion.div>

          {/* Main Content */}
          <div className="flex flex-col lg:flex-row gap-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className={`flex-1 ${isSidebarOpen ? 'lg:mr-80' : ''} enterprise-transition-layout`}
            >
              {activeView === 'table' && (
                <SecurityTable
                  securityComponents={securityComponents}
                  onComponentSelect={handleComponentSelect}
                  selectedComponent={selectedComponent}
                />
              )}
              
              {activeView === 'ics' && (
                <ICSLevelsVisualization
                  securityComponents={securityComponents}
                  onLevelSelect={handleLevelSelect}
                />
              )}
              
              {activeView === 'network' && (
                <NetworkArchitecture
                  securityComponents={securityComponents}
                />
              )}
            </motion.div>

            {/* Sidebar */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ 
                opacity: isSidebarOpen ? 1 : 0,
                x: isSidebarOpen ? 0 : 20
              }}
              transition={{ duration: 0.3 }}
              className={`fixed top-16 right-0 bottom-0 z-50 lg:relative lg:top-0 lg:right-auto lg:bottom-auto lg:z-auto ${
                isSidebarOpen ? 'block' : 'hidden lg:block'
              }`}
            >
              <SecuritySidebar
                selectedComponent={selectedComponent}
                onClose={handleCloseSidebar}
              />
            </motion.div>
          </div>
        </div>
      </main>

      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={handleCloseSidebar}
        />
      )}
    </div>
  );
};

export default SecurityArchitecture;