import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ICSLevelsVisualization = ({ securityComponents, onLevelSelect }) => {
  const [selectedLevel, setSelectedLevel] = useState(null);

  const icsLevels = [
    { level: '0', name: 'Enterprise Network', description: 'Corporate network and business systems', color: 'bg-slate-500' },
    { level: '1', name: 'Site Business Planning', description: 'Site-wide logistics and planning', color: 'bg-blue-500' },
    { level: '2', name: 'Area Supervisory Control', description: 'Area control and monitoring', color: 'bg-green-500' },
    { level: '3', name: 'Site Operations', description: 'Site manufacturing operations', color: 'bg-yellow-500' },
    { level: '3.5', name: 'Local Operations', description: 'Local control room operations', color: 'bg-orange-500' },
    { level: '3.7', name: 'Intelligent Devices', description: 'Smart field devices and sensors', color: 'bg-red-500' },
    { level: '4', name: 'Basic Control', description: 'Basic process control systems', color: 'bg-purple-500' },
    { level: '5', name: 'Field Devices', description: 'Physical field devices and actuators', color: 'bg-pink-500' }
  ];

  const getComponentCountForLevel = (level) => {
    return securityComponents.filter(component => component.icsLevel === level).length;
  };

  const getCriticalityDistribution = (level) => {
    const levelComponents = securityComponents.filter(component => component.icsLevel === level);
    const distribution = { Critical: 0, High: 0, Medium: 0, Low: 0 };
    levelComponents.forEach(component => {
      distribution[component.criticality] = (distribution[component.criticality] || 0) + 1;
    });
    return distribution;
  };

  const handleLevelClick = (level) => {
    setSelectedLevel(selectedLevel === level ? null : level);
    if (onLevelSelect) {
      onLevelSelect(selectedLevel === level ? null : level);
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border enterprise-shadow-card p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">ICS Levels Security Distribution</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Security components mapped across industrial control system hierarchy
          </p>
        </div>
        <Button variant="outline" onClick={() => setSelectedLevel(null)}>
          <Icon name="RotateCcw" size={16} className="mr-2" />
          Reset View
        </Button>
      </div>

      {/* ICS Levels Hierarchy */}
      <div className="space-y-3 mb-6">
        {icsLevels.map((level) => {
          const componentCount = getComponentCountForLevel(level.level);
          const distribution = getCriticalityDistribution(level.level);
          const isSelected = selectedLevel === level.level;

          return (
            <div
              key={level.level}
              className={`border border-border rounded-lg p-4 cursor-pointer enterprise-transition ${
                isSelected ? 'ring-2 ring-primary bg-primary/5' : 'hover:bg-muted/30'
              }`}
              onClick={() => handleLevelClick(level.level)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className={`w-12 h-12 ${level.color} rounded-lg flex items-center justify-center text-white font-bold`}>
                    {level.level}
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground">{level.name}</h4>
                    <p className="text-sm text-muted-foreground">{level.description}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-6">
                  <div className="text-right">
                    <div className="text-lg font-semibold text-foreground">{componentCount}</div>
                    <div className="text-xs text-muted-foreground">Components</div>
                  </div>
                  <Icon 
                    name={isSelected ? "ChevronUp" : "ChevronDown"} 
                    size={20} 
                    className="text-muted-foreground" 
                  />
                </div>
              </div>

              {/* Criticality Distribution Bar */}
              {componentCount > 0 && (
                <div className="mt-4">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-xs text-muted-foreground">Criticality Distribution:</span>
                    <div className="flex items-center space-x-4 text-xs">
                      {distribution.Critical > 0 && (
                        <span className="flex items-center space-x-1">
                          <div className="w-2 h-2 bg-error rounded-full" />
                          <span>{distribution.Critical} Critical</span>
                        </span>
                      )}
                      {distribution.High > 0 && (
                        <span className="flex items-center space-x-1">
                          <div className="w-2 h-2 bg-warning rounded-full" />
                          <span>{distribution.High} High</span>
                        </span>
                      )}
                      {distribution.Medium > 0 && (
                        <span className="flex items-center space-x-1">
                          <div className="w-2 h-2 bg-accent rounded-full" />
                          <span>{distribution.Medium} Medium</span>
                        </span>
                      )}
                      {distribution.Low > 0 && (
                        <span className="flex items-center space-x-1">
                          <div className="w-2 h-2 bg-success rounded-full" />
                          <span>{distribution.Low} Low</span>
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2">
                    <div className="h-2 rounded-full flex">
                      {distribution.Critical > 0 && (
                        <div 
                          className="bg-error rounded-l-full" 
                          style={{ width: `${(distribution.Critical / componentCount) * 100}%` }}
                        />
                      )}
                      {distribution.High > 0 && (
                        <div 
                          className="bg-warning" 
                          style={{ width: `${(distribution.High / componentCount) * 100}%` }}
                        />
                      )}
                      {distribution.Medium > 0 && (
                        <div 
                          className="bg-accent" 
                          style={{ width: `${(distribution.Medium / componentCount) * 100}%` }}
                        />
                      )}
                      {distribution.Low > 0 && (
                        <div 
                          className="bg-success rounded-r-full" 
                          style={{ width: `${(distribution.Low / componentCount) * 100}%` }}
                        />
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Expanded Details */}
              {isSelected && componentCount > 0 && (
                <div className="mt-4 pt-4 border-t border-border">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h5 className="text-sm font-medium text-foreground mb-2">Environment Distribution</h5>
                      <div className="space-y-1">
                        {['Azure Cloud', 'Windows Server', 'Linux'].map(env => {
                          const count = securityComponents.filter(c => 
                            c.icsLevel === level.level && c.environment === env
                          ).length;
                          if (count === 0) return null;
                          return (
                            <div key={env} className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">{env}</span>
                              <span className="text-foreground">{count}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    <div>
                      <h5 className="text-sm font-medium text-foreground mb-2">Team Ownership</h5>
                      <div className="space-y-1">
                        {['CS Team', 'INFRA Team', 'Network Team'].map(team => {
                          const count = securityComponents.filter(c => 
                            c.icsLevel === level.level && c.teamOwnership === team
                          ).length;
                          if (count === 0) return null;
                          return (
                            <div key={team} className="flex items-center justify-between text-sm">
                              <span className="text-muted-foreground">{team}</span>
                              <span className="text-foreground">{count}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-muted/30 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-foreground">{securityComponents.length}</div>
          <div className="text-sm text-muted-foreground">Total Components</div>
        </div>
        <div className="bg-error/10 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-error">
            {securityComponents.filter(c => c.criticality === 'Critical').length}
          </div>
          <div className="text-sm text-muted-foreground">Critical</div>
        </div>
        <div className="bg-warning/10 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-warning">
            {securityComponents.filter(c => c.criticality === 'High').length}
          </div>
          <div className="text-sm text-muted-foreground">High Risk</div>
        </div>
        <div className="bg-success/10 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-success">
            {Math.round((securityComponents.filter(c => c.criticality === 'Low' || c.criticality === 'Medium').length / securityComponents.length) * 100)}%
          </div>
          <div className="text-sm text-muted-foreground">Compliant</div>
        </div>
      </div>
    </div>
  );
};

export default ICSLevelsVisualization;