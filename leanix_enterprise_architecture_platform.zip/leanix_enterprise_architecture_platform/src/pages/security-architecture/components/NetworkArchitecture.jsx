import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const NetworkArchitecture = ({ securityComponents }) => {
  const [selectedZone, setSelectedZone] = useState(null);

  const networkZones = [
    {
      id: 'it',
      name: 'IT Network',
      description: 'Corporate IT infrastructure and business applications',
      color: 'bg-blue-500',
      borderColor: 'border-blue-500',
      components: securityComponents.filter(c => 
        c.environment === 'Azure Cloud' || c.environment === 'Windows Server'
      )
    },
    {
      id: 'ot',
      name: 'OT Network',
      description: 'Operational technology and industrial control systems',
      color: 'bg-orange-500',
      borderColor: 'border-orange-500',
      components: securityComponents.filter(c => 
        c.icsLevel >= '2' && c.icsLevel <= '5'
      )
    },
    {
      id: 'dmz',
      name: 'DMZ',
      description: 'Demilitarized zone for external-facing services',
      color: 'bg-red-500',
      borderColor: 'border-red-500',
      components: securityComponents.filter(c => 
        c.criticality === 'Critical' && c.environment === 'Linux'
      )
    }
  ];

  const securityControls = [
    { name: 'Firewall', icon: 'Shield', position: 'between-it-dmz' },
    { name: 'IDS/IPS', icon: 'Eye', position: 'between-dmz-ot' },
    { name: 'Network Segmentation', icon: 'Network', position: 'center' },
    { name: 'Access Control', icon: 'Lock', position: 'all-zones' }
  ];

  const handleZoneClick = (zone) => {
    setSelectedZone(selectedZone?.id === zone.id ? null : zone);
  };

  return (
    <div className="bg-card rounded-lg border border-border enterprise-shadow-card p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Network Architecture Overview</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Security component placement across IT/OT/DMZ boundaries
          </p>
        </div>
        <Button variant="outline" onClick={() => setSelectedZone(null)}>
          <Icon name="RotateCcw" size={16} className="mr-2" />
          Reset View
        </Button>
      </div>

      {/* Network Diagram */}
      <div className="relative bg-muted/20 rounded-lg p-8 mb-6 min-h-96">
        {/* Network Zones */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 h-full">
          {networkZones.map((zone, index) => (
            <div
              key={zone.id}
              className={`relative border-2 ${zone.borderColor} rounded-lg p-4 cursor-pointer enterprise-transition ${
                selectedZone?.id === zone.id ? 'ring-2 ring-primary bg-primary/5' : 'hover:bg-muted/30'
              }`}
              onClick={() => handleZoneClick(zone)}
            >
              {/* Zone Header */}
              <div className="flex items-center space-x-3 mb-4">
                <div className={`w-8 h-8 ${zone.color} rounded-lg flex items-center justify-center`}>
                  <Icon 
                    name={zone.id === 'it' ? 'Building' : zone.id === 'ot' ? 'Cog' : 'Globe'} 
                    size={16} 
                    color="white" 
                  />
                </div>
                <div>
                  <h4 className="font-medium text-foreground">{zone.name}</h4>
                  <p className="text-xs text-muted-foreground">{zone.description}</p>
                </div>
              </div>

              {/* Component Count */}
              <div className="mb-4">
                <div className="text-2xl font-bold text-foreground">{zone.components.length}</div>
                <div className="text-sm text-muted-foreground">Security Components</div>
              </div>

              {/* Criticality Breakdown */}
              <div className="space-y-2">
                {['Critical', 'High', 'Medium', 'Low'].map(criticality => {
                  const count = zone.components.filter(c => c.criticality === criticality).length;
                  if (count === 0) return null;
                  
                  const colorClass = {
                    'Critical': 'text-error',
                    'High': 'text-warning',
                    'Medium': 'text-accent',
                    'Low': 'text-success'
                  }[criticality];

                  return (
                    <div key={criticality} className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">{criticality}</span>
                      <span className={`font-medium ${colorClass}`}>{count}</span>
                    </div>
                  );
                })}
              </div>

              {/* Security Controls Indicator */}
              <div className="absolute top-2 right-2">
                <div className="flex items-center space-x-1">
                  {securityControls.filter(control => 
                    control.position === 'all-zones' || control.position.includes(zone.id)
                  ).map((control, idx) => (
                    <div key={idx} className="w-6 h-6 bg-success/20 rounded-full flex items-center justify-center">
                      <Icon name={control.icon} size={12} className="text-success" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Security Control Connections */}
        <div className="absolute inset-0 pointer-events-none">
          {/* Connection lines between zones */}
          <svg className="w-full h-full">
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" 
                      refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="currentColor" className="text-muted-foreground" />
              </marker>
            </defs>
            
            {/* IT to DMZ connection */}
            <line x1="33%" y1="50%" x2="66%" y2="50%" 
                  stroke="currentColor" strokeWidth="2" strokeDasharray="5,5"
                  className="text-muted-foreground" markerEnd="url(#arrowhead)" />
            
            {/* DMZ to OT connection */}
            <line x1="66%" y1="50%" x2="90%" y2="50%" 
                  stroke="currentColor" strokeWidth="2" strokeDasharray="5,5"
                  className="text-muted-foreground" markerEnd="url(#arrowhead)" />
          </svg>
        </div>
      </div>

      {/* Selected Zone Details */}
      {selectedZone && (
        <div className="bg-muted/30 rounded-lg p-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className={`w-10 h-10 ${selectedZone.color} rounded-lg flex items-center justify-center`}>
              <Icon 
                name={selectedZone.id === 'it' ? 'Building' : selectedZone.id === 'ot' ? 'Cog' : 'Globe'} 
                size={20} 
                color="white" 
              />
            </div>
            <div>
              <h4 className="text-lg font-medium text-foreground">{selectedZone.name} Details</h4>
              <p className="text-sm text-muted-foreground">{selectedZone.description}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Components by Team */}
            <div>
              <h5 className="text-sm font-medium text-foreground mb-3">Team Ownership</h5>
              <div className="space-y-2">
                {['CS Team', 'INFRA Team', 'Network Team'].map(team => {
                  const count = selectedZone.components.filter(c => c.teamOwnership === team).length;
                  if (count === 0) return null;
                  return (
                    <div key={team} className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">{team}</span>
                      <span className="text-sm font-medium text-foreground">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Components by Environment */}
            <div>
              <h5 className="text-sm font-medium text-foreground mb-3">Environment Distribution</h5>
              <div className="space-y-2">
                {['Azure Cloud', 'Windows Server', 'Linux'].map(env => {
                  const count = selectedZone.components.filter(c => c.environment === env).length;
                  if (count === 0) return null;
                  return (
                    <div key={env} className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">{env}</span>
                      <span className="text-sm font-medium text-foreground">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Security Controls */}
            <div>
              <h5 className="text-sm font-medium text-foreground mb-3">Active Security Controls</h5>
              <div className="space-y-2">
                {securityControls.filter(control => 
                  control.position === 'all-zones' || control.position.includes(selectedZone.id)
                ).map((control, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Icon name={control.icon} size={16} className="text-success" />
                    <span className="text-sm text-foreground">{control.name}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Components */}
          <div className="mt-6">
            <h5 className="text-sm font-medium text-foreground mb-3">Recent Components</h5>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {selectedZone.components.slice(0, 4).map((component, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-card rounded-lg border border-border">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Icon name="Shield" size={16} className="text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-foreground truncate">{component.name}</div>
                    <div className="text-xs text-muted-foreground">{component.criticality} • {component.teamOwnership}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Security Controls Legend */}
      <div className="mt-6 pt-6 border-t border-border">
        <h5 className="text-sm font-medium text-foreground mb-3">Security Controls Legend</h5>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {securityControls.map((control, index) => (
            <div key={index} className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-success/20 rounded-full flex items-center justify-center">
                <Icon name={control.icon} size={12} className="text-success" />
              </div>
              <span className="text-sm text-foreground">{control.name}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NetworkArchitecture;