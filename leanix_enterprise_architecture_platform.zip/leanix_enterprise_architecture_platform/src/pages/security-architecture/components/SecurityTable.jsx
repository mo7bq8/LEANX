import React, { useState, useMemo } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const SecurityTable = ({ securityComponents, onComponentSelect, selectedComponent }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'asc' });
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const criticalityOptions = [
    { value: '', label: 'All Criticality Levels' },
    { value: 'Critical', label: 'Critical' },
    { value: 'High', label: 'High' },
    { value: 'Medium', label: 'Medium' },
    { value: 'Low', label: 'Low' }
  ];

  const environmentOptions = [
    { value: '', label: 'All Environments' },
    { value: 'Azure Cloud', label: 'Azure Cloud' },
    { value: 'Windows Server', label: 'Windows Server' },
    { value: 'Linux', label: 'Linux' }
  ];

  const teamOptions = [
    { value: '', label: 'All Teams' },
    { value: 'CS Team', label: 'CS Team' },
    { value: 'INFRA Team', label: 'INFRA Team' },
    { value: 'Network Team', label: 'Network Team' }
  ];

  const [filters, setFilters] = useState({
    criticality: '',
    environment: '',
    team: ''
  });

  const getCriticalityColor = (criticality) => {
    switch (criticality) {
      case 'Critical': return 'bg-error text-error-foreground';
      case 'High': return 'bg-warning text-warning-foreground';
      case 'Medium': return 'bg-accent text-accent-foreground';
      case 'Low': return 'bg-success text-success-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getICSLevelColor = (level) => {
    const colors = {
      '0': 'bg-slate-500 text-white',
      '1': 'bg-blue-500 text-white',
      '2': 'bg-green-500 text-white',
      '3': 'bg-yellow-500 text-white',
      '3.5': 'bg-orange-500 text-white',
      '3.7': 'bg-red-500 text-white',
      '4': 'bg-purple-500 text-white',
      '5': 'bg-pink-500 text-white'
    };
    return colors[level] || 'bg-muted text-muted-foreground';
  };

  const filteredAndSortedComponents = useMemo(() => {
    let filtered = securityComponents.filter(component => {
      const matchesSearch = component.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          component.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCriticality = !filters.criticality || component.criticality === filters.criticality;
      const matchesEnvironment = !filters.environment || component.environment === filters.environment;
      const matchesTeam = !filters.team || component.teamOwnership === filters.team;
      
      return matchesSearch && matchesCriticality && matchesEnvironment && matchesTeam;
    });

    if (sortConfig.key) {
      filtered.sort((a, b) => {
        let aValue = a[sortConfig.key];
        let bValue = b[sortConfig.key];
        
        if (typeof aValue === 'string') {
          aValue = aValue.toLowerCase();
          bValue = bValue.toLowerCase();
        }
        
        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [securityComponents, searchQuery, filters, sortConfig]);

  const paginatedComponents = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredAndSortedComponents.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredAndSortedComponents, currentPage]);

  const totalPages = Math.ceil(filteredAndSortedComponents.length / itemsPerPage);

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleFilterChange = (filterType, value) => {
    setFilters(prev => ({ ...prev, [filterType]: value }));
    setCurrentPage(1);
  };

  const clearFilters = () => {
    setFilters({ criticality: '', environment: '', team: '' });
    setSearchQuery('');
    setCurrentPage(1);
  };

  return (
    <div className="bg-card rounded-lg border border-border enterprise-shadow-card">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Security Components</h2>
            <p className="text-sm text-muted-foreground mt-1">
              {filteredAndSortedComponents.length} of {securityComponents.length} components
            </p>
          </div>
          <Button variant="outline" onClick={clearFilters}>
            <Icon name="RotateCcw" size={16} className="mr-2" />
            Clear Filters
          </Button>
        </div>

        {/* Search and Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Input
            type="search"
            placeholder="Search components..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full"
          />
          <Select
            options={criticalityOptions}
            value={filters.criticality}
            onChange={(value) => handleFilterChange('criticality', value)}
            placeholder="Filter by criticality"
          />
          <Select
            options={environmentOptions}
            value={filters.environment}
            onChange={(value) => handleFilterChange('environment', value)}
            placeholder="Filter by environment"
          />
          <Select
            options={teamOptions}
            value={filters.team}
            onChange={(value) => handleFilterChange('team', value)}
            placeholder="Filter by team"
          />
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="text-left p-4 font-medium text-muted-foreground">
                <button
                  onClick={() => handleSort('name')}
                  className="flex items-center space-x-2 hover:text-foreground enterprise-transition"
                >
                  <span>Component Name</span>
                  <Icon 
                    name={sortConfig.key === 'name' && sortConfig.direction === 'desc' ? 'ChevronDown' : 'ChevronUp'} 
                    size={16} 
                  />
                </button>
              </th>
              <th className="text-left p-4 font-medium text-muted-foreground">
                <button
                  onClick={() => handleSort('criticality')}
                  className="flex items-center space-x-2 hover:text-foreground enterprise-transition"
                >
                  <span>Criticality</span>
                  <Icon 
                    name={sortConfig.key === 'criticality' && sortConfig.direction === 'desc' ? 'ChevronDown' : 'ChevronUp'} 
                    size={16} 
                  />
                </button>
              </th>
              <th className="text-left p-4 font-medium text-muted-foreground">Environment</th>
              <th className="text-left p-4 font-medium text-muted-foreground">Team Ownership</th>
              <th className="text-left p-4 font-medium text-muted-foreground">ICS Level</th>
              <th className="text-left p-4 font-medium text-muted-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {paginatedComponents.map((component) => (
              <tr 
                key={component.id}
                className={`border-b border-border hover:bg-muted/30 enterprise-transition cursor-pointer ${
                  selectedComponent?.id === component.id ? 'bg-accent/10' : ''
                }`}
                onClick={() => onComponentSelect(component)}
              >
                <td className="p-4">
                  <div>
                    <div className="font-medium text-foreground">{component.name}</div>
                    <div className="text-sm text-muted-foreground truncate max-w-xs">
                      {component.description}
                    </div>
                  </div>
                </td>
                <td className="p-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getCriticalityColor(component.criticality)}`}>
                    {component.criticality}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={component.environment === 'Azure Cloud' ? 'Cloud' : 'Server'} 
                      size={16} 
                      className="text-muted-foreground" 
                    />
                    <span className="text-sm text-foreground">{component.environment}</span>
                  </div>
                </td>
                <td className="p-4">
                  <span className="text-sm text-foreground">{component.teamOwnership}</span>
                </td>
                <td className="p-4">
                  <span className={`inline-flex items-center px-2 py-1 rounded text-xs font-medium ${getICSLevelColor(component.icsLevel)}`}>
                    Level {component.icsLevel}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex items-center space-x-2">
                    <Button variant="ghost" size="icon">
                      <Icon name="Eye" size={16} />
                    </Button>
                    <Button variant="ghost" size="icon">
                      <Icon name="Edit" size={16} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between p-4 border-t border-border">
          <div className="text-sm text-muted-foreground">
            Showing {((currentPage - 1) * itemsPerPage) + 1} to {Math.min(currentPage * itemsPerPage, filteredAndSortedComponents.length)} of {filteredAndSortedComponents.length} results
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              <Icon name="ChevronLeft" size={16} />
            </Button>
            <span className="text-sm text-foreground">
              Page {currentPage} of {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              <Icon name="ChevronRight" size={16} />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SecurityTable;