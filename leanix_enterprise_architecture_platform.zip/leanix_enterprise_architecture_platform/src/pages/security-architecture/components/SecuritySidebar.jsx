import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SecuritySidebar = ({ selectedComponent, onClose }) => {
  if (!selectedComponent) {
    return (
      <div className="w-full lg:w-80 bg-card border-l border-border p-6">
        <div className="text-center py-12">
          <Icon name="Shield" size={48} className="mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">Select a Security Component</h3>
          <p className="text-sm text-muted-foreground">
            Choose a component from the table to view detailed information and compliance status.
          </p>
        </div>
      </div>
    );
  }

  const getCriticalityColor = (criticality) => {
    switch (criticality) {
      case 'Critical': return 'text-error';
      case 'High': return 'text-warning';
      case 'Medium': return 'text-accent';
      case 'Low': return 'text-success';
      default: return 'text-muted-foreground';
    }
  };

  const getComplianceStatus = (criticality) => {
    switch (criticality) {
      case 'Critical': return { status: 'Compliant', color: 'text-success', icon: 'CheckCircle' };
      case 'High': return { status: 'Under Review', color: 'text-warning', icon: 'AlertCircle' };
      case 'Medium': return { status: 'Compliant', color: 'text-success', icon: 'CheckCircle' };
      case 'Low': return { status: 'Compliant', color: 'text-success', icon: 'CheckCircle' };
      default: return { status: 'Unknown', color: 'text-muted-foreground', icon: 'HelpCircle' };
    }
  };

  const compliance = getComplianceStatus(selectedComponent.criticality);

  return (
    <div className="w-full lg:w-80 bg-card border-l border-border">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Component Details</h3>
          <Button variant="ghost" size="icon" onClick={onClose} className="lg:hidden">
            <Icon name="X" size={20} />
          </Button>
        </div>
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="Shield" size={20} className="text-primary" />
          </div>
          <div>
            <h4 className="font-medium text-foreground">{selectedComponent.name}</h4>
            <p className="text-sm text-muted-foreground">{selectedComponent.category}</p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6 overflow-y-auto">
        {/* Description */}
        <div>
          <h5 className="text-sm font-medium text-foreground mb-2">Description</h5>
          <p className="text-sm text-muted-foreground leading-relaxed">
            {selectedComponent.description}
          </p>
        </div>

        {/* Key Information */}
        <div className="space-y-4">
          <div>
            <h5 className="text-sm font-medium text-foreground mb-3">Key Information</h5>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Criticality Level</span>
                <span className={`text-sm font-medium ${getCriticalityColor(selectedComponent.criticality)}`}>
                  {selectedComponent.criticality}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Environment</span>
                <span className="text-sm text-foreground">{selectedComponent.environment}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Team Ownership</span>
                <span className="text-sm text-foreground">{selectedComponent.teamOwnership}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">ICS Level</span>
                <span className="text-sm text-foreground">Level {selectedComponent.icsLevel}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Compliance Status */}
        <div>
          <h5 className="text-sm font-medium text-foreground mb-3">Compliance Status</h5>
          <div className="bg-muted/50 rounded-lg p-4">
            <div className="flex items-center space-x-3 mb-3">
              <Icon name={compliance.icon} size={20} className={compliance.color} />
              <div>
                <div className="text-sm font-medium text-foreground">{compliance.status}</div>
                <div className="text-xs text-muted-foreground">Last updated: {selectedComponent.lastUpdated}</div>
              </div>
            </div>
            <div className="text-xs text-muted-foreground">
              Component meets current security standards and compliance requirements.
            </div>
          </div>
        </div>

        {/* Risk Assessment */}
        <div>
          <h5 className="text-sm font-medium text-foreground mb-3">Risk Assessment</h5>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Risk Score</span>
              <span className="text-sm font-medium text-foreground">{selectedComponent.riskScore}/10</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className={`h-2 rounded-full ${
                  selectedComponent.riskScore <= 3 ? 'bg-success' :
                  selectedComponent.riskScore <= 6 ? 'bg-warning' : 'bg-error'
                }`}
                style={{ width: `${(selectedComponent.riskScore / 10) * 100}%` }}
              />
            </div>
            <div className="text-xs text-muted-foreground">
              Based on criticality, environment exposure, and compliance status.
            </div>
          </div>
        </div>

        {/* Related Dependencies */}
        <div>
          <h5 className="text-sm font-medium text-foreground mb-3">Related Dependencies</h5>
          <div className="space-y-2">
            {selectedComponent.dependencies.map((dep, index) => (
              <div key={index} className="flex items-center space-x-3 p-2 bg-muted/30 rounded-lg">
                <Icon name="ArrowRight" size={14} className="text-muted-foreground" />
                <span className="text-sm text-foreground">{dep}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Audit Trail */}
        <div>
          <h5 className="text-sm font-medium text-foreground mb-3">Recent Activity</h5>
          <div className="space-y-3">
            {selectedComponent.auditTrail.slice(0, 3).map((entry, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-foreground">{entry.action}</div>
                  <div className="text-xs text-muted-foreground">
                    {entry.user} • {entry.timestamp}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 border-t border-border">
          <div className="space-y-2">
            <Button variant="default" className="w-full">
              <Icon name="Edit" size={16} className="mr-2" />
              Edit Component
            </Button>
            <Button variant="outline" className="w-full">
              <Icon name="FileText" size={16} className="mr-2" />
              Generate Report
            </Button>
            <Button variant="outline" className="w-full">
              <Icon name="History" size={16} className="mr-2" />
              View Full Audit Trail
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecuritySidebar;