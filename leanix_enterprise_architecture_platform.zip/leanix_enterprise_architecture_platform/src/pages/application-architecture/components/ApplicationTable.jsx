import React, { useState, useMemo } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const ApplicationTable = ({ 
  applications, 
  selectedApplications, 
  onSelectionChange, 
  onApplicationSelect,
  sortConfig,
  onSort,
  viewMode 
}) => {
  const [hoveredRow, setHoveredRow] = useState(null);

  const handleSelectAll = (checked) => {
    if (checked) {
      onSelectionChange(applications.map(app => app.id));
    } else {
      onSelectionChange([]);
    }
  };

  const handleRowSelect = (appId, checked) => {
    if (checked) {
      onSelectionChange([...selectedApplications, appId]);
    } else {
      onSelectionChange(selectedApplications.filter(id => id !== appId));
    }
  };

  const getSortIcon = (column) => {
    if (sortConfig.key !== column) return 'ArrowUpDown';
    return sortConfig.direction === 'asc' ? 'ArrowUp' : 'ArrowDown';
  };

  const getICSLevelColor = (level) => {
    const colors = {
      '4': 'bg-error text-error-foreground',
      '3.7': 'bg-warning text-warning-foreground',
      '3.5': 'bg-accent text-accent-foreground',
      '3': 'bg-success text-success-foreground'
    };
    return colors[level] || 'bg-muted text-muted-foreground';
  };

  const getStatusColor = (status) => {
    const colors = {
      'Production': 'bg-success/10 text-success border-success/20',
      'Development': 'bg-accent/10 text-accent border-accent/20',
      'Testing': 'bg-warning/10 text-warning border-warning/20',
      'Deprecated': 'bg-error/10 text-error border-error/20'
    };
    return colors[status] || 'bg-muted/10 text-muted-foreground border-muted/20';
  };

  if (viewMode === 'card') {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {applications.map((app) => (
          <div
            key={app.id}
            className="bg-card border border-border rounded-lg p-4 hover:shadow-md enterprise-transition cursor-pointer"
            onClick={() => onApplicationSelect(app)}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <h3 className="font-semibold text-foreground mb-1">{app.name}</h3>
                <p className="text-sm text-muted-foreground">{app.description}</p>
              </div>
              <Checkbox
                checked={selectedApplications.includes(app.id)}
                onChange={(e) => handleRowSelect(app.id, e.target.checked)}
                className="ml-2"
                onClick={(e) => e.stopPropagation()}
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">ICS Level</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${getICSLevelColor(app.icsLevel)}`}>
                  {app.icsLevel}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Group</span>
                <span className="text-xs font-medium text-foreground">{app.group}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Vendor</span>
                <span className="text-xs font-medium text-foreground">{app.vendor}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Status</span>
                <span className={`px-2 py-1 rounded text-xs font-medium border ${getStatusColor(app.status)}`}>
                  {app.status}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50 border-b border-border">
            <tr>
              <th className="w-12 px-4 py-3">
                <Checkbox
                  checked={selectedApplications.length === applications.length && applications.length > 0}
                  indeterminate={selectedApplications.length > 0 && selectedApplications.length < applications.length}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                />
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-foreground">
                <Button
                  variant="ghost"
                  onClick={() => onSort('name')}
                  className="h-auto p-0 font-semibold hover:bg-transparent"
                >
                  Application Name
                  <Icon name={getSortIcon('name')} size={14} className="ml-1" />
                </Button>
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-foreground">
                <Button
                  variant="ghost"
                  onClick={() => onSort('icsLevel')}
                  className="h-auto p-0 font-semibold hover:bg-transparent"
                >
                  ICS Level
                  <Icon name={getSortIcon('icsLevel')} size={14} className="ml-1" />
                </Button>
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-foreground">
                <Button
                  variant="ghost"
                  onClick={() => onSort('group')}
                  className="h-auto p-0 font-semibold hover:bg-transparent"
                >
                  Group
                  <Icon name={getSortIcon('group')} size={14} className="ml-1" />
                </Button>
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-foreground">
                <Button
                  variant="ghost"
                  onClick={() => onSort('businessProcess')}
                  className="h-auto p-0 font-semibold hover:bg-transparent"
                >
                  Business Process
                  <Icon name={getSortIcon('businessProcess')} size={14} className="ml-1" />
                </Button>
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-foreground">
                <Button
                  variant="ghost"
                  onClick={() => onSort('vendor')}
                  className="h-auto p-0 font-semibold hover:bg-transparent"
                >
                  Vendor
                  <Icon name={getSortIcon('vendor')} size={14} className="ml-1" />
                </Button>
              </th>
              <th className="text-left px-4 py-3 text-sm font-semibold text-foreground">
                <Button
                  variant="ghost"
                  onClick={() => onSort('status')}
                  className="h-auto p-0 font-semibold hover:bg-transparent"
                >
                  Status
                  <Icon name={getSortIcon('status')} size={14} className="ml-1" />
                </Button>
              </th>
              <th className="w-20 px-4 py-3 text-sm font-semibold text-foreground">Actions</th>
            </tr>
          </thead>
          <tbody>
            {applications.map((app, index) => (
              <tr
                key={app.id}
                className={`border-b border-border hover:bg-muted/30 enterprise-transition cursor-pointer ${
                  index % 2 === 0 ? 'bg-background' : 'bg-muted/10'
                }`}
                onMouseEnter={() => setHoveredRow(app.id)}
                onMouseLeave={() => setHoveredRow(null)}
                onClick={() => onApplicationSelect(app)}
              >
                <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                  <Checkbox
                    checked={selectedApplications.includes(app.id)}
                    onChange={(e) => handleRowSelect(app.id, e.target.checked)}
                  />
                </td>
                <td className="px-4 py-3">
                  <div>
                    <div className="font-medium text-foreground">{app.name}</div>
                    <div className="text-sm text-muted-foreground truncate max-w-xs">
                      {app.description}
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${getICSLevelColor(app.icsLevel)}`}>
                    Level {app.icsLevel}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className="text-sm text-foreground">{app.group}</span>
                </td>
                <td className="px-4 py-3">
                  <span className="text-sm text-foreground">{app.businessProcess}</span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-6 h-6 bg-muted rounded flex items-center justify-center">
                      <span className="text-xs font-medium text-muted-foreground">
                        {app.vendor.charAt(0)}
                      </span>
                    </div>
                    <span className="text-sm text-foreground">{app.vendor}</span>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium border ${getStatusColor(app.status)}`}>
                    {app.status}
                  </span>
                </td>
                <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center space-x-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => onApplicationSelect(app)}
                    >
                      <Icon name="Eye" size={14} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                    >
                      <Icon name="Edit" size={14} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ApplicationTable;