import React from 'react';
import Button from '../../../components/ui/Button';


const ViewControls = ({
  viewMode,
  onViewModeChange,
  selectedCount,
  onBulkAction,
  onExport,
  onAddApplication
}) => {
  const viewModes = [
    { id: 'table', label: 'Table View', icon: 'Table' },
    { id: 'card', label: 'Card View', icon: 'Grid3X3' },
    { id: 'matrix', label: 'Relationship Matrix', icon: 'Network' }
  ];

  const bulkActions = [
    { id: 'edit', label: 'Bulk Edit', icon: 'Edit' },
    { id: 'export', label: 'Export Selected', icon: 'Download' },
    { id: 'archive', label: 'Archive', icon: 'Archive' },
    { id: 'delete', label: 'Delete', icon: 'Trash2' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between">
        {/* Left Section - View Mode Toggle */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
            {viewModes.map((mode) => (
              <Button
                key={mode.id}
                variant={viewMode === mode.id ? 'default' : 'ghost'}
                size="sm"
                onClick={() => onViewModeChange(mode.id)}
                iconName={mode.icon}
                iconPosition="left"
                className="text-xs"
              >
                {mode.label}
              </Button>
            ))}
          </div>

          {/* Bulk Actions */}
          {selectedCount > 0 && (
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">
                {selectedCount} selected
              </span>
              <div className="flex items-center space-x-1">
                {bulkActions.map((action) => (
                  <Button
                    key={action.id}
                    variant="outline"
                    size="sm"
                    onClick={() => onBulkAction(action.id)}
                    iconName={action.icon}
                    iconPosition="left"
                    className={action.id === 'delete' ? 'text-error hover:text-error' : ''}
                  >
                    {action.label}
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Section - Action Buttons */}
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={onExport}
            iconName="Download"
            iconPosition="left"
          >
            Export All
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            iconName="RefreshCw"
            iconPosition="left"
          >
            Refresh
          </Button>

          <Button
            variant="default"
            size="sm"
            onClick={onAddApplication}
            iconName="Plus"
            iconPosition="left"
          >
            Add Application
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ViewControls;