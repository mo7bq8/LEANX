import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RelationshipMatrix = ({ applications }) => {
  const [selectedApp, setSelectedApp] = useState(null);
  const [matrixView, setMatrixView] = useState('dependencies'); // dependencies, teams, vendors

  // Group applications by different criteria
  const groupedData = {
    dependencies: applications.reduce((acc, app) => {
      const group = app.businessProcess;
      if (!acc[group]) acc[group] = [];
      acc[group].push(app);
      return acc;
    }, {}),
    teams: applications.reduce((acc, app) => {
      const group = app.group;
      if (!acc[group]) acc[group] = [];
      acc[group].push(app);
      return acc;
    }, {}),
    vendors: applications.reduce((acc, app) => {
      const group = app.vendor;
      if (!acc[group]) acc[group] = [];
      acc[group].push(app);
      return acc;
    }, {})
  };

  const getICSLevelColor = (level) => {
    const colors = {
      '4': 'bg-error',
      '3.7': 'bg-warning',
      '3.5': 'bg-accent',
      '3': 'bg-success'
    };
    return colors[level] || 'bg-muted';
  };

  const getRelationshipStrength = (app1, app2) => {
    // Mock relationship strength calculation
    if (app1.vendor === app2.vendor) return 'strong';
    if (app1.businessProcess === app2.businessProcess) return 'medium';
    if (app1.group === app2.group) return 'weak';
    return 'none';
  };

  const getRelationshipColor = (strength) => {
    const colors = {
      'strong': 'bg-success',
      'medium': 'bg-warning',
      'weak': 'bg-accent',
      'none': 'bg-muted/30'
    };
    return colors[strength] || 'bg-muted/30';
  };

  const matrixViews = [
    { id: 'dependencies', label: 'Business Process Dependencies', icon: 'Workflow' },
    { id: 'teams', label: 'Team Relationships', icon: 'Users' },
    { id: 'vendors', label: 'Vendor Ecosystem', icon: 'Building' }
  ];

  const renderMatrixCell = (app1, app2) => {
    if (app1.id === app2.id) {
      return (
        <div className={`w-8 h-8 rounded ${getICSLevelColor(app1.icsLevel)} flex items-center justify-center`}>
          <span className="text-xs font-medium text-white">{app1.icsLevel}</span>
        </div>
      );
    }

    const strength = getRelationshipStrength(app1, app2);
    return (
      <div
        className={`w-8 h-8 rounded ${getRelationshipColor(strength)} cursor-pointer hover:scale-110 enterprise-transition`}
        title={`${app1.name} → ${app2.name}: ${strength} relationship`}
        onClick={() => setSelectedApp({ app1, app2, strength })}
      />
    );
  };

  const renderGroupMatrix = () => {
    const currentData = groupedData[matrixView];
    const groups = Object.keys(currentData);

    return (
      <div className="space-y-6">
        {groups.map((group, groupIndex) => (
          <div key={group} className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-foreground">{group}</h4>
              <span className="text-sm text-muted-foreground">
                {currentData[group].length} applications
              </span>
            </div>

            <div className="overflow-x-auto">
              <div className="inline-block min-w-full">
                <div className="grid gap-1" style={{ gridTemplateColumns: `120px repeat(${currentData[group].length}, 40px)` }}>
                  {/* Header row */}
                  <div></div>
                  {currentData[group].map((app) => (
                    <div
                      key={app.id}
                      className="w-8 h-8 flex items-center justify-center text-xs font-medium text-muted-foreground transform -rotate-45 origin-center"
                      title={app.name}
                    >
                      {app.name.substring(0, 3)}
                    </div>
                  ))}

                  {/* Matrix rows */}
                  {currentData[group].map((app1) => (
                    <React.Fragment key={app1.id}>
                      <div className="flex items-center text-sm font-medium text-foreground truncate pr-2">
                        {app1.name}
                      </div>
                      {currentData[group].map((app2) => (
                        <div key={app2.id} className="flex items-center justify-center">
                          {renderMatrixCell(app1, app2)}
                        </div>
                      ))}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Matrix View Controls */}
      <div className="bg-card border border-border rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Icon name="Network" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Relationship Matrix</h3>
          </div>
          
          <div className="flex items-center space-x-1 bg-muted rounded-lg p-1">
            {matrixViews.map((view) => (
              <Button
                key={view.id}
                variant={matrixView === view.id ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setMatrixView(view.id)}
                iconName={view.icon}
                iconPosition="left"
                className="text-xs"
              >
                {view.label}
              </Button>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center space-x-6 text-sm">
          <div className="flex items-center space-x-2">
            <span className="text-muted-foreground">Relationship Strength:</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-4 h-4 bg-success rounded"></div>
            <span className="text-muted-foreground">Strong</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-4 h-4 bg-warning rounded"></div>
            <span className="text-muted-foreground">Medium</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-4 h-4 bg-accent rounded"></div>
            <span className="text-muted-foreground">Weak</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-4 h-4 bg-muted/30 rounded"></div>
            <span className="text-muted-foreground">None</span>
          </div>
        </div>
      </div>

      {/* Matrix Display */}
      {renderGroupMatrix()}

      {/* Relationship Details Modal */}
      {selectedApp && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-card border border-border rounded-lg p-6 max-w-md w-full">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold text-foreground">Relationship Details</h4>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedApp(null)}
              >
                <Icon name="X" size={20} />
              </Button>
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                  <Icon name="Layers" size={16} color="white" />
                </div>
                <div>
                  <div className="font-medium text-foreground">{selectedApp.app1.name}</div>
                  <div className="text-sm text-muted-foreground">{selectedApp.app1.vendor}</div>
                </div>
              </div>

              <div className="flex items-center justify-center">
                <Icon name="ArrowRight" size={20} className="text-muted-foreground" />
              </div>

              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-accent rounded-lg flex items-center justify-center">
                  <Icon name="Layers" size={16} color="white" />
                </div>
                <div>
                  <div className="font-medium text-foreground">{selectedApp.app2.name}</div>
                  <div className="text-sm text-muted-foreground">{selectedApp.app2.vendor}</div>
                </div>
              </div>

              <div className="bg-muted/30 rounded-lg p-3">
                <div className="text-sm font-medium text-foreground mb-2">Relationship Strength</div>
                <div className={`inline-flex items-center space-x-2 px-2 py-1 rounded text-sm font-medium ${
                  selectedApp.strength === 'strong' ? 'bg-success/10 text-success' :
                  selectedApp.strength === 'medium' ? 'bg-warning/10 text-warning' :
                  selectedApp.strength === 'weak'? 'bg-accent/10 text-accent' : 'bg-muted/10 text-muted-foreground'
                }`}>
                  <div className={`w-3 h-3 rounded ${getRelationshipColor(selectedApp.strength)}`}></div>
                  <span className="capitalize">{selectedApp.strength}</span>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Common Vendor:</span>
                  <span className="text-foreground">
                    {selectedApp.app1.vendor === selectedApp.app2.vendor ? 'Yes' : 'No'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Same Business Process:</span>
                  <span className="text-foreground">
                    {selectedApp.app1.businessProcess === selectedApp.app2.businessProcess ? 'Yes' : 'No'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Same Group:</span>
                  <span className="text-foreground">
                    {selectedApp.app1.group === selectedApp.app2.group ? 'Yes' : 'No'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RelationshipMatrix;