import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ApplicationDetails = ({ application, onClose, isVisible }) => {
  const [activeTab, setActiveTab] = useState('overview');

  if (!application || !isVisible) return null;

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'Info' },
    { id: 'teams', label: 'Teams', icon: 'Users' },
    { id: 'technology', label: 'Technology', icon: 'Server' },
    { id: 'security', label: 'Security', icon: 'Shield' },
    { id: 'relationships', label: 'Relationships', icon: 'Network' }
  ];

  const getICSLevelColor = (level) => {
    const colors = {
      '4': 'bg-error text-error-foreground',
      '3.7': 'bg-warning text-warning-foreground',
      '3.5': 'bg-accent text-accent-foreground',
      '3': 'bg-success text-success-foreground'
    };
    return colors[level] || 'bg-muted text-muted-foreground';
  };

  const getStatusColor = (status) => {
    const colors = {
      'Production': 'bg-success/10 text-success border-success/20',
      'Development': 'bg-accent/10 text-accent border-accent/20',
      'Testing': 'bg-warning/10 text-warning border-warning/20',
      'Deprecated': 'bg-error/10 text-error border-error/20'
    };
    return colors[status] || 'bg-muted/10 text-muted-foreground border-muted/20';
  };

  const renderOverviewTab = () => (
    <div className="space-y-6">
      {/* Basic Information */}
      <div>
        <h4 className="text-sm font-semibold text-foreground mb-3">Basic Information</h4>
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Application ID</span>
            <span className="text-sm font-medium text-foreground">{application.id}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">ICS Level</span>
            <span className={`px-2 py-1 rounded text-xs font-medium ${getICSLevelColor(application.icsLevel)}`}>
              Level {application.icsLevel}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Status</span>
            <span className={`px-2 py-1 rounded text-xs font-medium border ${getStatusColor(application.status)}`}>
              {application.status}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Group</span>
            <span className="text-sm font-medium text-foreground">{application.group}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-muted-foreground">Vendor</span>
            <span className="text-sm font-medium text-foreground">{application.vendor}</span>
          </div>
        </div>
      </div>

      {/* Description */}
      <div>
        <h4 className="text-sm font-semibold text-foreground mb-3">Description</h4>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {application.description}
        </p>
      </div>

      {/* Business Process */}
      <div>
        <h4 className="text-sm font-semibold text-foreground mb-3">Business Process</h4>
        <div className="bg-muted/30 rounded-lg p-3">
          <div className="flex items-center space-x-2">
            <Icon name="Workflow" size={16} className="text-primary" />
            <span className="text-sm font-medium text-foreground">{application.businessProcess}</span>
          </div>
        </div>
      </div>

      {/* Criticality Assessment */}
      <div>
        <h4 className="text-sm font-semibold text-foreground mb-3">Criticality Assessment</h4>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-xs text-muted-foreground mb-1">Business Impact</div>
            <div className="text-sm font-medium text-foreground">{application.businessImpact || 'High'}</div>
          </div>
          <div className="bg-muted/30 rounded-lg p-3">
            <div className="text-xs text-muted-foreground mb-1">Technical Risk</div>
            <div className="text-sm font-medium text-foreground">{application.technicalRisk || 'Medium'}</div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderTeamsTab = () => (
    <div className="space-y-4">
      <h4 className="text-sm font-semibold text-foreground">Team Assignments</h4>
      <div className="space-y-3">
        {application.teams?.map((team, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-xs font-medium text-primary-foreground">{team.abbreviation}</span>
              </div>
              <div>
                <div className="text-sm font-medium text-foreground">{team.name}</div>
                <div className="text-xs text-muted-foreground">{team.role}</div>
              </div>
            </div>
            <div className="text-xs text-muted-foreground">{team.responsibility}</div>
          </div>
        )) || (
          <div className="text-center py-8 text-muted-foreground">
            <Icon name="Users" size={24} className="mx-auto mb-2 opacity-50" />
            <p className="text-sm">No team assignments found</p>
          </div>
        )}
      </div>
    </div>
  );

  const renderTechnologyTab = () => (
    <div className="space-y-4">
      <h4 className="text-sm font-semibold text-foreground">Technology Dependencies</h4>
      <div className="space-y-3">
        {application.technologies?.map((tech, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Server" size={16} className="text-accent" />
              <div>
                <div className="text-sm font-medium text-foreground">{tech.name}</div>
                <div className="text-xs text-muted-foreground">{tech.category}</div>
              </div>
            </div>
            <div className="text-xs text-muted-foreground">{tech.version}</div>
          </div>
        )) || (
          <div className="text-center py-8 text-muted-foreground">
            <Icon name="Server" size={24} className="mx-auto mb-2 opacity-50" />
            <p className="text-sm">No technology dependencies found</p>
          </div>
        )}
      </div>
    </div>
  );

  const renderSecurityTab = () => (
    <div className="space-y-4">
      <h4 className="text-sm font-semibold text-foreground">Security Mappings</h4>
      <div className="space-y-3">
        {application.securityControls?.map((control, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Shield" size={16} className="text-success" />
              <div>
                <div className="text-sm font-medium text-foreground">{control.name}</div>
                <div className="text-xs text-muted-foreground">{control.type}</div>
              </div>
            </div>
            <div className={`px-2 py-1 rounded text-xs font-medium ${
              control.status === 'Active' ? 'bg-success/10 text-success' : 'bg-warning/10 text-warning'
            }`}>
              {control.status}
            </div>
          </div>
        )) || (
          <div className="text-center py-8 text-muted-foreground">
            <Icon name="Shield" size={24} className="mx-auto mb-2 opacity-50" />
            <p className="text-sm">No security controls mapped</p>
          </div>
        )}
      </div>
    </div>
  );

  const renderRelationshipsTab = () => (
    <div className="space-y-4">
      <h4 className="text-sm font-semibold text-foreground">Application Relationships</h4>
      <div className="space-y-3">
        {application.relationships?.map((rel, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-3">
              <Icon name="Network" size={16} className="text-accent" />
              <div>
                <div className="text-sm font-medium text-foreground">{rel.targetApplication}</div>
                <div className="text-xs text-muted-foreground">{rel.type}</div>
              </div>
            </div>
            <div className="text-xs text-muted-foreground">{rel.direction}</div>
          </div>
        )) || (
          <div className="text-center py-8 text-muted-foreground">
            <Icon name="Network" size={24} className="mx-auto mb-2 opacity-50" />
            <p className="text-sm">No relationships found</p>
          </div>
        )}
      </div>
    </div>
  );

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return renderOverviewTab();
      case 'teams':
        return renderTeamsTab();
      case 'technology':
        return renderTechnologyTab();
      case 'security':
        return renderSecurityTab();
      case 'relationships':
        return renderRelationshipsTab();
      default:
        return renderOverviewTab();
    }
  };

  return (
    <div className="bg-card border border-border rounded-lg h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <Icon name="Layers" size={20} color="white" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">{application.name}</h3>
            <p className="text-sm text-muted-foreground">{application.vendor}</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClose}
        >
          <Icon name="X" size={20} />
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-border">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center space-x-2 px-4 py-3 text-sm font-medium border-b-2 enterprise-transition ${
              activeTab === tab.id
                ? 'border-primary text-primary bg-primary/5' :'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/30'
            }`}
          >
            <Icon name={tab.icon} size={16} />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 p-4 overflow-y-auto">
        {renderTabContent()}
      </div>

      {/* Footer Actions */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center justify-between">
          <div className="text-xs text-muted-foreground">
            Last updated: {new Date().toLocaleDateString()}
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" iconName="Edit" iconPosition="left">
              Edit
            </Button>
            <Button variant="outline" size="sm" iconName="ExternalLink" iconPosition="left">
              View Full Details
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApplicationDetails;