import React from 'react';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const FilterControls = ({
  filters,
  onFilterChange,
  onClearFilters,
  searchQuery,
  onSearchChange,
  resultCount,
  totalCount
}) => {
  const icsLevelOptions = [
    { value: '', label: 'All ICS Levels' },
    { value: '4', label: 'Level 4 - Critical' },
    { value: '3.7', label: 'Level 3.7 - High' },
    { value: '3.5', label: 'Level 3.5 - Medium' },
    { value: '3', label: 'Level 3 - Standard' }
  ];

  const groupOptions = [
    { value: '', label: 'All Groups' },
    { value: 'Operations', label: 'Operations' },
    { value: 'Engineering', label: 'Engineering' },
    { value: 'Maintenance', label: 'Maintenance' },
    { value: 'Safety', label: 'Safety' },
    { value: 'Quality', label: 'Quality' },
    { value: 'Production', label: 'Production' },
    { value: 'IT Infrastructure', label: 'IT Infrastructure' }
  ];

  const vendorOptions = [
    { value: '', label: 'All Vendors' },
    { value: 'IBM Maximo', label: 'IBM Maximo' },
    { value: 'Oracle', label: 'Oracle' },
    { value: 'Aspentech', label: 'Aspentech' },
    { value: 'Labvantage', label: 'Labvantage' },
    { value: 'Microsoft', label: 'Microsoft' },
    { value: 'SAP', label: 'SAP' },
    { value: 'Schneider Electric', label: 'Schneider Electric' }
  ];

  const businessProcessOptions = [
    { value: '', label: 'All Business Processes' },
    { value: 'Asset Management', label: 'Asset Management' },
    { value: 'Process Control', label: 'Process Control' },
    { value: 'Safety Management', label: 'Safety Management' },
    { value: 'Quality Control', label: 'Quality Control' },
    { value: 'Maintenance Planning', label: 'Maintenance Planning' },
    { value: 'Production Planning', label: 'Production Planning' },
    { value: 'Environmental Monitoring', label: 'Environmental Monitoring' },
    { value: 'Inventory Management', label: 'Inventory Management' }
  ];

  const statusOptions = [
    { value: '', label: 'All Statuses' },
    { value: 'Production', label: 'Production' },
    { value: 'Development', label: 'Development' },
    { value: 'Testing', label: 'Testing' },
    { value: 'Deprecated', label: 'Deprecated' }
  ];

  const hasActiveFilters = Object.values(filters).some(value => value !== '') || searchQuery !== '';

  return (
    <div className="bg-card border border-border rounded-lg p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="Filter" size={20} className="text-muted-foreground" />
          <h3 className="text-lg font-semibold text-foreground">Filter Applications</h3>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-sm text-muted-foreground">
            Showing <span className="font-medium text-foreground">{resultCount}</span> of{' '}
            <span className="font-medium text-foreground">{totalCount}</span> applications
          </div>
          {hasActiveFilters && (
            <Button
              variant="outline"
              size="sm"
              onClick={onClearFilters}
              iconName="X"
              iconPosition="left"
            >
              Clear Filters
            </Button>
          )}
        </div>
      </div>

      {/* Search Bar */}
      <div className="mb-4">
        <Input
          type="search"
          placeholder="Search applications by name, description, or any field..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="w-full"
        />
      </div>

      {/* Filter Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Select
          label="ICS Level"
          options={icsLevelOptions}
          value={filters.icsLevel}
          onChange={(value) => onFilterChange('icsLevel', value)}
          placeholder="Select ICS Level"
        />

        <Select
          label="Group"
          options={groupOptions}
          value={filters.group}
          onChange={(value) => onFilterChange('group', value)}
          placeholder="Select Group"
        />

        <Select
          label="Vendor"
          options={vendorOptions}
          value={filters.vendor}
          onChange={(value) => onFilterChange('vendor', value)}
          placeholder="Select Vendor"
          searchable
        />

        <Select
          label="Business Process"
          options={businessProcessOptions}
          value={filters.businessProcess}
          onChange={(value) => onFilterChange('businessProcess', value)}
          placeholder="Select Process"
          searchable
        />

        <Select
          label="Status"
          options={statusOptions}
          value={filters.status}
          onChange={(value) => onFilterChange('status', value)}
          placeholder="Select Status"
        />
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex items-center space-x-2 flex-wrap">
            <span className="text-sm text-muted-foreground">Active filters:</span>
            
            {searchQuery && (
              <div className="flex items-center space-x-1 bg-accent/10 text-accent px-2 py-1 rounded text-sm">
                <Icon name="Search" size={12} />
                <span>"{searchQuery}"</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-4 w-4 ml-1"
                  onClick={() => onSearchChange('')}
                >
                  <Icon name="X" size={10} />
                </Button>
              </div>
            )}

            {Object.entries(filters).map(([key, value]) => {
              if (!value) return null;
              
              const getFilterLabel = (key, value) => {
                switch (key) {
                  case 'icsLevel':
                    return `ICS Level: ${value}`;
                  case 'group':
                    return `Group: ${value}`;
                  case 'vendor':
                    return `Vendor: ${value}`;
                  case 'businessProcess':
                    return `Process: ${value}`;
                  case 'status':
                    return `Status: ${value}`;
                  default:
                    return `${key}: ${value}`;
                }
              };

              return (
                <div
                  key={key}
                  className="flex items-center space-x-1 bg-primary/10 text-primary px-2 py-1 rounded text-sm"
                >
                  <span>{getFilterLabel(key, value)}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-4 w-4 ml-1"
                    onClick={() => onFilterChange(key, '')}
                  >
                    <Icon name="X" size={10} />
                  </Button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterControls;