import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import FilterControls from './components/FilterControls';
import ViewControls from './components/ViewControls';
import ApplicationTable from './components/ApplicationTable';
import ApplicationDetails from './components/ApplicationDetails';
import RelationshipMatrix from './components/RelationshipMatrix';
import Icon from '../../components/AppIcon';
import applicationService from '../../services/applicationService';

const ApplicationArchitecture = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    icsLevel: '',
    group: '',
    vendor: '',
    businessProcess: '',
    status: ''
  });
  const [selectedApplications, setSelectedApplications] = useState([]);
  const [selectedApplication, setSelectedApplication] = useState(null);
  const [viewMode, setViewMode] = useState('table');
  const [sortConfig, setSortConfig] = useState({ key: 'name', direction: 'asc' });
  const [isDetailsVisible, setIsDetailsVisible] = useState(false);
  const [applications, setApplications] = useState([]);
  const [filterOptions, setFilterOptions] = useState({});
  const [statistics, setStatistics] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load applications data from SQLite
  useEffect(() => {
    loadApplications();
    loadFilterOptions();
    loadStatistics();
  }, []);

  const loadApplications = async () => {
    try {
      setLoading(true);
      const data = await applicationService.getAllApplications();
      setApplications(data);
      setError(null);
    } catch (err) {
      console.error('Failed to load applications:', err);
      setError('Failed to load applications');
    } finally {
      setLoading(false);
    }
  };

  const loadFilterOptions = async () => {
    try {
      const options = await applicationService.getFilterOptions();
      setFilterOptions(options);
    } catch (err) {
      console.error('Failed to load filter options:', err);
    }
  };

  const loadStatistics = async () => {
    try {
      const stats = await applicationService.getStatistics();
      setStatistics(stats);
    } catch (err) {
      console.error('Failed to load statistics:', err);
    }
  };

  // Filter and search applications
  const filteredApplications = useMemo(() => {
    let filtered = applications;

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(app =>
        app.name?.toLowerCase().includes(query) ||
        app.description?.toLowerCase().includes(query) ||
        app.vendor?.toLowerCase().includes(query) ||
        app.app_group?.toLowerCase().includes(query) ||
        app.business_process?.toLowerCase().includes(query) ||
        app.status?.toLowerCase().includes(query)
      );
    }

    // Apply filters
    Object.entries(filters).forEach(([key, value]) => {
      if (value) {
        const filterKey = key === 'group' ? 'app_group' : 
                         key === 'businessProcess' ? 'business_process' :
                         key === 'icsLevel' ? 'ics_level' : key;
        filtered = filtered.filter(app => app[filterKey] === value);
      }
    });

    // Apply sorting
    filtered.sort((a, b) => {
      const aValue = a[sortConfig.key];
      const bValue = b[sortConfig.key];
      
      if (sortConfig.direction === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });

    return filtered;
  }, [applications, searchQuery, filters, sortConfig]);

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleClearFilters = () => {
    setFilters({
      icsLevel: '',
      group: '',
      vendor: '',
      businessProcess: '',
      status: ''
    });
    setSearchQuery('');
  };

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleApplicationSelect = (application) => {
    setSelectedApplication(application);
    setIsDetailsVisible(true);
  };

  const handleBulkAction = async (action) => {
    try {
      console.log(`Bulk action: ${action} on applications:`, selectedApplications);
      
      const applicationIds = selectedApplications.map(app => app.id);
      
      switch (action) {
        case 'delete':
          if (!window.confirm(`Are you sure you want to delete ${selectedApplications.length} applications? This action cannot be undone.`)) {
            return;
          }
          await applicationService.bulkDeleteApplications(applicationIds);
          break;
        case 'update_status':
          await applicationService.bulkUpdateApplications(applicationIds, { status: 'Production' });
          break;
        default:
          console.warn('Unknown bulk action:', action);
      }

      // Reload data after bulk action
      await loadApplications();
      await loadStatistics();
      
      // Clear selections
      setSelectedApplications([]);
    } catch (err) {
      console.error('Error performing bulk action:', err);
      setError('Failed to perform bulk action');
    }
  };

  const handleExport = () => {
    console.log('Exporting applications data...');
    // Implementation for export functionality
  };

  const handleAddApplication = async () => {
    console.log('Adding new application...');
    // Implementation for add application functionality
    // This would typically open a modal or navigate to a form
  };

  // Set page title
  useEffect(() => {
    document.title = 'Application Architecture - LeanIX Enterprise Architecture Platform';
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Sidebar />
        <main className="pt-16 transition-all duration-300 ease-in-out lg:ml-64">
          <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading applications...</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Sidebar />
        <main className="pt-16 transition-all duration-300 ease-in-out lg:ml-64">
          <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
            <div className="text-center">
              <Icon name="AlertCircle" size={48} className="text-error mx-auto mb-4" />
              <p className="text-error mb-4">{error}</p>
              <button
                onClick={() => loadApplications()}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              >
                Retry
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      
      <main className="pt-16 transition-all duration-300 ease-in-out lg:ml-64">
        <div className="flex h-[calc(100vh-4rem)]">
          {/* Main Content Area */}
          <div className={`flex-1 p-6 overflow-y-auto transition-all duration-300 ${
            isDetailsVisible ? 'lg:mr-96' : ''
          }`}>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* Page Header */}
              <div className="mb-6">
                <h1 className="text-3xl font-bold text-foreground mb-2">Application Architecture</h1>
                <p className="text-muted-foreground">
                  Comprehensive management and visualization of organizational applications with ICS levels, 
                  vendor relationships, and business process mappings.
                </p>
                
                {/* Statistics */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
                  <div className="bg-card rounded-lg border border-border p-4">
                    <div className="text-2xl font-bold text-foreground">{statistics?.totalApplications || 0}</div>
                    <div className="text-sm text-muted-foreground">Total Applications</div>
                  </div>
                  <div className="bg-card rounded-lg border border-border p-4">
                    <div className="text-2xl font-bold text-success">{statistics?.productionApps || 0}</div>
                    <div className="text-sm text-muted-foreground">Production</div>
                  </div>
                  <div className="bg-card rounded-lg border border-border p-4">
                    <div className="text-2xl font-bold text-warning">{statistics?.developmentApps || 0}</div>
                    <div className="text-sm text-muted-foreground">Development</div>
                  </div>
                  <div className="bg-card rounded-lg border border-border p-4">
                    <div className="text-2xl font-bold text-error">{statistics?.criticalApps || 0}</div>
                    <div className="text-sm text-muted-foreground">Critical</div>
                  </div>
                </div>
              </div>

              {/* Filter Controls */}
              <FilterControls
                filters={filters}
                onFilterChange={handleFilterChange}
                onClearFilters={handleClearFilters}
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                resultCount={filteredApplications.length}
                totalCount={applications.length}
                filterOptions={filterOptions}
              />

              {/* View Controls */}
              <ViewControls
                viewMode={viewMode}
                onViewModeChange={setViewMode}
                selectedCount={selectedApplications.length}
                onBulkAction={handleBulkAction}
                onExport={handleExport}
                onAddApplication={handleAddApplication}
              />

              {/* Main Content */}
              {viewMode === 'matrix' ? (
                <RelationshipMatrix applications={filteredApplications} />
              ) : (
                <ApplicationTable
                  applications={filteredApplications}
                  selectedApplications={selectedApplications}
                  onSelectionChange={setSelectedApplications}
                  onApplicationSelect={handleApplicationSelect}
                  sortConfig={sortConfig}
                  onSort={handleSort}
                  viewMode={viewMode}
                />
              )}
            </motion.div>
          </div>

          {/* Right Sidebar - Application Details */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: isDetailsVisible ? 0 : '100%' }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="fixed right-0 top-16 bottom-0 w-96 bg-background border-l border-border z-30 lg:relative lg:top-0"
          >
            <ApplicationDetails
              application={selectedApplication}
              onClose={() => setIsDetailsVisible(false)}
              isVisible={isDetailsVisible}
            />
          </motion.div>
        </div>
      </main>
    </div>
  );
};

export default ApplicationArchitecture;