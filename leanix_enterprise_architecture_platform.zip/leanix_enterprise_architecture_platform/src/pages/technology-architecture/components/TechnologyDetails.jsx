import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { motion, AnimatePresence } from 'framer-motion';

const TechnologyDetails = ({ 
  technology, 
  onClose, 
  onEdit, 
  onStatusUpdate 
}) => {
  const [activeTab, setActiveTab] = useState('overview');

  if (!technology) {
    return (
      <div className="bg-card rounded-lg border border-border enterprise-shadow-card p-6">
        <div className="text-center py-12">
          <Icon name="Server" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-2">No Technology Selected</h3>
          <p className="text-muted-foreground">Select a technology from the table to view details</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Overview', icon: 'Info' },
    { id: 'teams', label: 'Teams', icon: 'Users' },
    { id: 'dependencies', label: 'Dependencies', icon: 'Network' },
    { id: 'history', label: 'History', icon: 'Clock' }
  ];

  const getStatusColor = (status) => {
    switch (status) {
      case 'Production': return 'text-success bg-success/10 border-success/20';
      case 'Development': return 'text-warning bg-warning/10 border-warning/20';
      case 'Planned': return 'text-accent bg-accent/10 border-accent/20';
      case 'Deprecated': return 'text-error bg-error/10 border-error/20';
      default: return 'text-muted-foreground bg-muted border-border';
    }
  };

  const getTeamColor = (team) => {
    const colors = {
      'CS': 'bg-blue-100 text-blue-800 border-blue-200',
      'CA': 'bg-green-100 text-green-800 border-green-200',
      'CoA': 'bg-purple-100 text-purple-800 border-purple-200',
      'ITP': 'bg-orange-100 text-orange-800 border-orange-200',
      'ITO': 'bg-red-100 text-red-800 border-red-200'
    };
    return colors[team] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="bg-card rounded-lg border border-border enterprise-shadow-card">
      {/* Header */}
      <div className="p-6 border-b border-border">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name="Server" size={24} className="text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-foreground">{technology.name}</h2>
              <p className="text-muted-foreground">{technology.category}</p>
              <div className="flex items-center space-x-2 mt-2">
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(technology.status)}`}>
                  {technology.status}
                </span>
                <span className="text-sm text-muted-foreground">
                  Version {technology.version}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              onClick={() => onEdit(technology)}
              iconName="Edit"
              iconPosition="left"
            >
              Edit
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
            >
              <Icon name="X" size={20} />
            </Button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-border">
        <nav className="flex space-x-8 px-6">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center space-x-2 py-4 border-b-2 text-sm font-medium enterprise-transition ${
                activeTab === tab.id
                  ? 'border-primary text-primary' :'border-transparent text-muted-foreground hover:text-foreground hover:border-muted'
              }`}
            >
              <Icon name={tab.icon} size={16} />
              <span>{tab.label}</span>
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      <div className="p-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-medium text-foreground mb-3">Technology Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">Vendor</label>
                        <p className="text-foreground">{technology.vendor}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">License Type</label>
                        <p className="text-foreground">{technology.licenseType}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">Installation Date</label>
                        <p className="text-foreground">{formatDate(technology.installationDate)}</p>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">Support Level</label>
                        <p className="text-foreground">{technology.supportLevel}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">End of Life</label>
                        <p className="text-foreground">{technology.endOfLife || 'Not specified'}</p>
                      </div>
                      <div>
                        <label className="text-sm font-medium text-muted-foreground">Cost Center</label>
                        <p className="text-foreground">{technology.costCenter}</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-md font-medium text-foreground mb-3">Description</h4>
                  <p className="text-muted-foreground leading-relaxed">{technology.description}</p>
                </div>

                <div>
                  <h4 className="text-md font-medium text-foreground mb-3">Business Functions</h4>
                  <div className="flex flex-wrap gap-2">
                    {technology.businessFunctions.map((func, index) => (
                      <span
                        key={index}
                        className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-muted text-foreground"
                      >
                        {func}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'teams' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-foreground">Assigned Teams</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {technology.teams.map((team) => (
                    <div key={team} className={`p-4 rounded-lg border ${getTeamColor(team)}`}>
                      <div className="flex items-center space-x-3">
                        <Icon name="Users" size={20} />
                        <div>
                          <h4 className="font-medium">{team} Team</h4>
                          <p className="text-sm opacity-80">
                            {team === 'CS' && 'Cyber Security Team'}
                            {team === 'CA' && 'Control & Automation Team'}
                            {team === 'CoA' && 'Center of Automation Team'}
                            {team === 'ITP' && 'IT Production Team'}
                            {team === 'ITO' && 'IT Operations Team'}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'dependencies' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-foreground">Technology Dependencies</h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-md font-medium text-foreground mb-3">Depends On</h4>
                    <div className="space-y-2">
                      {technology.dependencies?.dependsOn?.map((dep, index) => (
                        <div key={index} className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
                          <Icon name="ArrowRight" size={16} className="text-muted-foreground" />
                          <span className="text-foreground">{dep}</span>
                        </div>
                      )) || <p className="text-muted-foreground">No dependencies</p>}
                    </div>
                  </div>
                  <div>
                    <h4 className="text-md font-medium text-foreground mb-3">Used By</h4>
                    <div className="space-y-2">
                      {technology.dependencies?.usedBy?.map((dep, index) => (
                        <div key={index} className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg">
                          <Icon name="ArrowLeft" size={16} className="text-muted-foreground" />
                          <span className="text-foreground">{dep}</span>
                        </div>
                      )) || <p className="text-muted-foreground">Not used by other technologies</p>}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'history' && (
              <div className="space-y-6">
                <h3 className="text-lg font-medium text-foreground">Change History</h3>
                <div className="space-y-4">
                  {technology.history?.map((entry, index) => (
                    <div key={index} className="flex space-x-4 p-4 bg-muted/30 rounded-lg">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <h4 className="text-sm font-medium text-foreground">{entry.action}</h4>
                          <span className="text-xs text-muted-foreground">{formatDate(entry.date)}</span>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{entry.description}</p>
                        <p className="text-xs text-muted-foreground">by {entry.user}</p>
                      </div>
                    </div>
                  )) || (
                    <p className="text-muted-foreground">No history available</p>
                  )}
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default TechnologyDetails;