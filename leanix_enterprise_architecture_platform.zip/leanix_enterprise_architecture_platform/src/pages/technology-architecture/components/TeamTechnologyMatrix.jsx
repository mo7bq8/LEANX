import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { motion } from 'framer-motion';

const TeamTechnologyMatrix = ({ 
  technologies, 
  onMatrixCellClick,
  isVisible,
  onToggle 
}) => {
  const [selectedTeam, setSelectedTeam] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);

  const teams = ['CS', 'CA', 'CoA', 'ITP', 'ITO'];
  const categories = ['Database', 'Middleware', 'Operating System', 'Development Tool', 'Security', 'Monitoring', 'Network', 'Cloud'];

  const getTeamTechnologyCount = (team, category = null) => {
    return technologies.filter(tech => {
      const hasTeam = tech.teams.includes(team);
      const hasCategory = category ? tech.category === category : true;
      return hasTeam && hasCategory;
    }).length;
  };

  const getCategoryTechnologyCount = (category) => {
    return technologies.filter(tech => tech.category === category).length;
  };

  const getTeamColor = (team) => {
    const colors = {
      'CS': 'bg-blue-500',
      'CA': 'bg-green-500',
      'CoA': 'bg-purple-500',
      'ITP': 'bg-orange-500',
      'ITO': 'bg-red-500'
    };
    return colors[team] || 'bg-gray-500';
  };

  const getIntensityClass = (count, maxCount) => {
    if (count === 0) return 'bg-muted';
    const intensity = count / maxCount;
    if (intensity > 0.8) return 'bg-primary';
    if (intensity > 0.6) return 'bg-primary/80';
    if (intensity > 0.4) return 'bg-primary/60';
    if (intensity > 0.2) return 'bg-primary/40';
    return 'bg-primary/20';
  };

  const maxCount = Math.max(...teams.flatMap(team => 
    categories.map(category => getTeamTechnologyCount(team, category))
  ));

  if (!isVisible) {
    return (
      <div className="bg-card rounded-lg border border-border enterprise-shadow-card p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Icon name="Grid3X3" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Team-Technology Matrix</h3>
          </div>
          <Button
            variant="outline"
            onClick={onToggle}
            iconName="Eye"
            iconPosition="left"
          >
            Show Matrix
          </Button>
        </div>
        <p className="text-muted-foreground mt-2">
          Interactive visualization of team-technology assignments across categories
        </p>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      className="bg-card rounded-lg border border-border enterprise-shadow-card"
    >
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Icon name="Grid3X3" size={20} className="text-primary" />
            <h3 className="text-lg font-semibold text-foreground">Team-Technology Matrix</h3>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              onClick={() => {
                setSelectedTeam(null);
                setSelectedCategory(null);
              }}
              size="sm"
            >
              Clear Selection
            </Button>
            <Button
              variant="ghost"
              onClick={onToggle}
              iconName="EyeOff"
              iconPosition="left"
              size="sm"
            >
              Hide Matrix
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Legend */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-foreground">Team Legend:</span>
            {teams.map(team => (
              <div key={team} className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${getTeamColor(team)}`} />
                <span className="text-sm text-foreground">{team}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>Intensity:</span>
            <div className="flex space-x-1">
              <div className="w-3 h-3 bg-primary/20 rounded" />
              <div className="w-3 h-3 bg-primary/40 rounded" />
              <div className="w-3 h-3 bg-primary/60 rounded" />
              <div className="w-3 h-3 bg-primary/80 rounded" />
              <div className="w-3 h-3 bg-primary rounded" />
            </div>
            <span>High</span>
          </div>
        </div>

        {/* Matrix */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                <th className="text-left p-3 text-sm font-medium text-foreground">Category</th>
                {teams.map(team => (
                  <th 
                    key={team} 
                    className={`text-center p-3 text-sm font-medium cursor-pointer enterprise-transition ${
                      selectedTeam === team ? 'bg-primary/10 text-primary' : 'text-foreground hover:bg-muted'
                    }`}
                    onClick={() => setSelectedTeam(selectedTeam === team ? null : team)}
                  >
                    <div className="flex items-center justify-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${getTeamColor(team)}`} />
                      <span>{team}</span>
                    </div>
                  </th>
                ))}
                <th className="text-center p-3 text-sm font-medium text-foreground">Total</th>
              </tr>
            </thead>
            <tbody>
              {categories.map(category => (
                <tr 
                  key={category}
                  className={`border-t border-border ${
                    selectedCategory === category ? 'bg-primary/5' : 'hover:bg-muted/30'
                  }`}
                >
                  <td 
                    className={`p-3 text-sm font-medium cursor-pointer enterprise-transition ${
                      selectedCategory === category ? 'text-primary' : 'text-foreground hover:text-primary'
                    }`}
                    onClick={() => setSelectedCategory(selectedCategory === category ? null : category)}
                  >
                    {category}
                  </td>
                  {teams.map(team => {
                    const count = getTeamTechnologyCount(team, category);
                    const isHighlighted = selectedTeam === team || selectedCategory === category;
                    
                    return (
                      <td 
                        key={`${team}-${category}`}
                        className="p-3 text-center"
                      >
                        <button
                          onClick={() => onMatrixCellClick(team, category)}
                          className={`w-12 h-12 rounded-lg flex items-center justify-center text-sm font-medium enterprise-transition ${
                            getIntensityClass(count, maxCount)
                          } ${
                            isHighlighted ? 'ring-2 ring-primary ring-offset-2' : 'hover:ring-2 hover:ring-primary/50 hover:ring-offset-1'
                          } ${
                            count > 0 ? 'text-white' : 'text-muted-foreground'
                          }`}
                        >
                          {count}
                        </button>
                      </td>
                    );
                  })}
                  <td className="p-3 text-center">
                    <span className="inline-flex items-center justify-center w-12 h-8 bg-muted rounded-lg text-sm font-medium text-foreground">
                      {getCategoryTechnologyCount(category)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-border">
                <td className="p-3 text-sm font-medium text-foreground">Total</td>
                {teams.map(team => (
                  <td key={team} className="p-3 text-center">
                    <span className="inline-flex items-center justify-center w-12 h-8 bg-muted rounded-lg text-sm font-medium text-foreground">
                      {getTeamTechnologyCount(team)}
                    </span>
                  </td>
                ))}
                <td className="p-3 text-center">
                  <span className="inline-flex items-center justify-center w-12 h-8 bg-primary/10 text-primary rounded-lg text-sm font-medium">
                    {technologies.length}
                  </span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Selection Info */}
        {(selectedTeam || selectedCategory) && (
          <div className="mt-6 p-4 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="Info" size={16} className="text-primary" />
              <span className="text-sm font-medium text-foreground">Selection Details</span>
            </div>
            {selectedTeam && (
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{selectedTeam} Team</span> is assigned to{' '}
                <span className="font-medium text-foreground">{getTeamTechnologyCount(selectedTeam)}</span> technologies
                {selectedCategory && ` in ${selectedCategory} category`}
              </p>
            )}
            {selectedCategory && !selectedTeam && (
              <p className="text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{selectedCategory}</span> category contains{' '}
                <span className="font-medium text-foreground">{getCategoryTechnologyCount(selectedCategory)}</span> technologies
              </p>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default TeamTechnologyMatrix;