import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const FilterPanel = ({ 
  filters, 
  onFilterChange, 
  onClearFilters, 
  resultCount,
  totalCount 
}) => {
  const teamOptions = [
    { value: 'CS', label: 'CS Team' },
    { value: 'CA', label: 'CA Team' },
    { value: 'CoA', label: 'CoA Team' },
    { value: 'ITP', label: 'ITP Team' },
    { value: 'ITO', label: 'ITO Team' }
  ];

  const statusOptions = [
    { value: 'Production', label: 'Production' },
    { value: 'Development', label: 'Development' },
    { value: 'Planned', label: 'Planned' },
    { value: 'Deprecated', label: 'Deprecated' }
  ];

  const categoryOptions = [
    { value: 'Database', label: 'Database Systems' },
    { value: 'Middleware', label: 'Middleware' },
    { value: 'Operating System', label: 'Operating Systems' },
    { value: 'Development Tool', label: 'Development Tools' },
    { value: 'Security', label: 'Security Tools' },
    { value: 'Monitoring', label: 'Monitoring & Analytics' },
    { value: 'Network', label: 'Network Infrastructure' },
    { value: 'Cloud', label: 'Cloud Services' }
  ];

  const businessFunctionOptions = [
    { value: 'Asset Management', label: 'Asset Management' },
    { value: 'Production Planning', label: 'Production Planning' },
    { value: 'Quality Control', label: 'Quality Control' },
    { value: 'Maintenance', label: 'Maintenance Operations' },
    { value: 'Safety Management', label: 'Safety Management' },
    { value: 'Environmental Compliance', label: 'Environmental Compliance' },
    { value: 'Supply Chain', label: 'Supply Chain Management' },
    { value: 'Financial Management', label: 'Financial Management' }
  ];

  const handleFilterChange = (key, value) => {
    onFilterChange({ ...filters, [key]: value });
  };

  const hasActiveFilters = Object.values(filters).some(value => 
    Array.isArray(value) ? value.length > 0 : value !== ''
  );

  return (
    <div className="bg-card rounded-lg border border-border enterprise-shadow-card p-6 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <Icon name="Filter" size={20} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Technology Filters</h3>
          <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-sm font-medium">
            {resultCount} of {totalCount} technologies
          </div>
        </div>
        {hasActiveFilters && (
          <Button
            variant="outline"
            onClick={onClearFilters}
            iconName="X"
            iconPosition="left"
            size="sm"
          >
            Clear All Filters
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {/* Search */}
        <div className="lg:col-span-2">
          <Input
            type="search"
            placeholder="Search technologies..."
            value={filters.search}
            onChange={(e) => handleFilterChange('search', e.target.value)}
            className="w-full"
          />
        </div>

        {/* Team Filter */}
        <Select
          placeholder="All Teams"
          multiple
          searchable
          clearable
          options={teamOptions}
          value={filters.teams}
          onChange={(value) => handleFilterChange('teams', value)}
        />

        {/* Status Filter */}
        <Select
          placeholder="All Statuses"
          multiple
          clearable
          options={statusOptions}
          value={filters.status}
          onChange={(value) => handleFilterChange('status', value)}
        />

        {/* Category Filter */}
        <Select
          placeholder="All Categories"
          multiple
          searchable
          clearable
          options={categoryOptions}
          value={filters.categories}
          onChange={(value) => handleFilterChange('categories', value)}
        />

        {/* Business Function Filter */}
        <Select
          placeholder="All Functions"
          multiple
          searchable
          clearable
          options={businessFunctionOptions}
          value={filters.businessFunctions}
          onChange={(value) => handleFilterChange('businessFunctions', value)}
        />
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex flex-wrap gap-2">
            {filters.search && (
              <div className="flex items-center space-x-2 bg-primary/10 text-primary px-3 py-1 rounded-full text-sm">
                <Icon name="Search" size={14} />
                <span>"{filters.search}"</span>
                <button
                  onClick={() => handleFilterChange('search', '')}
                  className="hover:bg-primary/20 rounded-full p-0.5 enterprise-transition"
                >
                  <Icon name="X" size={12} />
                </button>
              </div>
            )}
            
            {filters.teams.map(team => (
              <div key={team} className="flex items-center space-x-2 bg-accent/10 text-accent px-3 py-1 rounded-full text-sm">
                <Icon name="Users" size={14} />
                <span>{team}</span>
                <button
                  onClick={() => handleFilterChange('teams', filters.teams.filter(t => t !== team))}
                  className="hover:bg-accent/20 rounded-full p-0.5 enterprise-transition"
                >
                  <Icon name="X" size={12} />
                </button>
              </div>
            ))}

            {filters.status.map(status => (
              <div key={status} className="flex items-center space-x-2 bg-success/10 text-success px-3 py-1 rounded-full text-sm">
                <Icon name="Activity" size={14} />
                <span>{status}</span>
                <button
                  onClick={() => handleFilterChange('status', filters.status.filter(s => s !== status))}
                  className="hover:bg-success/20 rounded-full p-0.5 enterprise-transition"
                >
                  <Icon name="X" size={12} />
                </button>
              </div>
            ))}

            {filters.categories.map(category => (
              <div key={category} className="flex items-center space-x-2 bg-warning/10 text-warning px-3 py-1 rounded-full text-sm">
                <Icon name="Tag" size={14} />
                <span>{category}</span>
                <button
                  onClick={() => handleFilterChange('categories', filters.categories.filter(c => c !== category))}
                  className="hover:bg-warning/20 rounded-full p-0.5 enterprise-transition"
                >
                  <Icon name="X" size={12} />
                </button>
              </div>
            ))}

            {filters.businessFunctions.map(func => (
              <div key={func} className="flex items-center space-x-2 bg-secondary/10 text-secondary px-3 py-1 rounded-full text-sm">
                <Icon name="Building" size={14} />
                <span>{func}</span>
                <button
                  onClick={() => handleFilterChange('businessFunctions', filters.businessFunctions.filter(f => f !== func))}
                  className="hover:bg-secondary/20 rounded-full p-0.5 enterprise-transition"
                >
                  <Icon name="X" size={12} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default FilterPanel;