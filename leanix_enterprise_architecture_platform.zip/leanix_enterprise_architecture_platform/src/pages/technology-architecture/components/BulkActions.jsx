import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { motion, AnimatePresence } from 'framer-motion';

const BulkActions = ({ 
  selectedTechnologies, 
  onBulkStatusUpdate, 
  onBulkTeamAssignment,
  onBulkDelete,
  onExport,
  onClearSelection 
}) => {
  const [showBulkPanel, setShowBulkPanel] = useState(false);
  const [bulkAction, setBulkAction] = useState('');

  const statusOptions = [
    { value: 'Production', label: 'Production' },
    { value: 'Development', label: 'Development' },
    { value: 'Planned', label: 'Planned' },
    { value: 'Deprecated', label: 'Deprecated' }
  ];

  const teamOptions = [
    { value: 'CS', label: 'CS Team' },
    { value: 'CA', label: 'CA Team' },
    { value: 'CoA', label: 'CoA Team' },
    { value: 'ITP', label: 'ITP Team' },
    { value: 'ITO', label: 'ITO Team' }
  ];

  const actionOptions = [
    { value: 'status', label: 'Update Status' },
    { value: 'teams', label: 'Assign Teams' },
    { value: 'export', label: 'Export Data' },
    { value: 'delete', label: 'Delete Technologies' }
  ];

  const handleBulkAction = (action, value) => {
    switch (action) {
      case 'status':
        onBulkStatusUpdate(selectedTechnologies, value);
        break;
      case 'teams':
        onBulkTeamAssignment(selectedTechnologies, value);
        break;
      case 'export':
        onExport(selectedTechnologies);
        break;
      case 'delete':
        if (window.confirm(`Are you sure you want to delete ${selectedTechnologies.length} technologies?`)) {
          onBulkDelete(selectedTechnologies);
        }
        break;
    }
    setShowBulkPanel(false);
    setBulkAction('');
  };

  if (selectedTechnologies.length === 0) {
    return null;
  }

  return (
    <div className="bg-card rounded-lg border border-border enterprise-shadow-card mb-6">
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
              <Icon name="CheckSquare" size={16} className="text-primary" />
            </div>
            <div>
              <h3 className="text-sm font-medium text-foreground">
                {selectedTechnologies.length} technolog{selectedTechnologies.length === 1 ? 'y' : 'ies'} selected
              </h3>
              <p className="text-xs text-muted-foreground">
                Perform bulk actions on selected items
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowBulkPanel(!showBulkPanel)}
              iconName={showBulkPanel ? "ChevronUp" : "ChevronDown"}
              iconPosition="right"
            >
              Bulk Actions
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClearSelection}
              iconName="X"
            >
              Clear
            </Button>
          </div>
        </div>

        <AnimatePresence>
          {showBulkPanel && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-4 pt-4 border-t border-border"
            >
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Select
                  placeholder="Select action..."
                  options={actionOptions}
                  value={bulkAction}
                  onChange={setBulkAction}
                />

                {bulkAction === 'status' && (
                  <Select
                    placeholder="Select status..."
                    options={statusOptions}
                    value=""
                    onChange={(value) => handleBulkAction('status', value)}
                  />
                )}

                {bulkAction === 'teams' && (
                  <Select
                    placeholder="Select teams..."
                    multiple
                    options={teamOptions}
                    value={[]}
                    onChange={(value) => handleBulkAction('teams', value)}
                  />
                )}

                {bulkAction === 'export' && (
                  <Button
                    variant="outline"
                    onClick={() => handleBulkAction('export')}
                    iconName="Download"
                    iconPosition="left"
                    className="w-full"
                  >
                    Export Selected
                  </Button>
                )}

                {bulkAction === 'delete' && (
                  <Button
                    variant="destructive"
                    onClick={() => handleBulkAction('delete')}
                    iconName="Trash2"
                    iconPosition="left"
                    className="w-full"
                  >
                    Delete Selected
                  </Button>
                )}
              </div>

              {/* Quick Actions */}
              <div className="mt-4 flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction('status', 'Production')}
                  iconName="Play"
                  iconPosition="left"
                >
                  Mark as Production
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction('status', 'Development')}
                  iconName="Code"
                  iconPosition="left"
                >
                  Mark as Development
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleBulkAction('export')}
                  iconName="Download"
                  iconPosition="left"
                >
                  Export to CSV
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default BulkActions;