import React, { useState, useMemo } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

const TechnologyTable = ({ 
  technologies, 
  selectedTechnologies, 
  onSelectionChange, 
  onTechnologySelect,
  onStatusUpdate,
  onEdit,
  onDelete 
}) => {
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });

  const sortedTechnologies = useMemo(() => {
    if (!sortConfig.key) return technologies;

    return [...technologies].sort((a, b) => {
      let aValue = a[sortConfig.key];
      let bValue = b[sortConfig.key];

      if (sortConfig.key === 'teams') {
        aValue = aValue.length;
        bValue = bValue.length;
      }

      if (sortConfig.key === 'lastUpdated') {
        aValue = new Date(aValue);
        bValue = new Date(bValue);
      }

      if (aValue < bValue) {
        return sortConfig.direction === 'asc' ? -1 : 1;
      }
      if (aValue > bValue) {
        return sortConfig.direction === 'asc' ? 1 : -1;
      }
      return 0;
    });
  }, [technologies, sortConfig]);

  const handleSort = (key) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleSelectAll = (checked) => {
    if (checked) {
      onSelectionChange(technologies.map(tech => tech.id));
    } else {
      onSelectionChange([]);
    }
  };

  const handleSelectTechnology = (techId, checked) => {
    if (checked) {
      onSelectionChange([...selectedTechnologies, techId]);
    } else {
      onSelectionChange(selectedTechnologies.filter(id => id !== techId));
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Production': return 'text-success bg-success/10';
      case 'Development': return 'text-warning bg-warning/10';
      case 'Planned': return 'text-accent bg-accent/10';
      case 'Deprecated': return 'text-error bg-error/10';
      default: return 'text-muted-foreground bg-muted';
    }
  };

  const getTeamColor = (team) => {
    const colors = {
      'CS': 'bg-blue-100 text-blue-800',
      'CA': 'bg-green-100 text-green-800',
      'CoA': 'bg-purple-100 text-purple-800',
      'ITP': 'bg-orange-100 text-orange-800',
      'ITO': 'bg-red-100 text-red-800'
    };
    return colors[team] || 'bg-gray-100 text-gray-800';
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const isAllSelected = selectedTechnologies.length === technologies.length;
  const isIndeterminate = selectedTechnologies.length > 0 && selectedTechnologies.length < technologies.length;

  return (
    <div className="bg-card rounded-lg border border-border enterprise-shadow-card">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50 border-b border-border">
            <tr>
              <th className="w-12 px-4 py-3">
                <Checkbox
                  checked={isAllSelected}
                  indeterminate={isIndeterminate}
                  onChange={(e) => handleSelectAll(e.target.checked)}
                />
              </th>
              <th className="text-left px-4 py-3">
                <button
                  onClick={() => handleSort('name')}
                  className="flex items-center space-x-2 text-sm font-medium text-foreground hover:text-primary enterprise-transition"
                >
                  <span>Technology Name</span>
                  <Icon 
                    name={sortConfig.key === 'name' && sortConfig.direction === 'desc' ? 'ChevronDown' : 'ChevronUp'} 
                    size={16} 
                    className={sortConfig.key === 'name' ? 'text-primary' : 'text-muted-foreground'}
                  />
                </button>
              </th>
              <th className="text-left px-4 py-3">
                <button
                  onClick={() => handleSort('teams')}
                  className="flex items-center space-x-2 text-sm font-medium text-foreground hover:text-primary enterprise-transition"
                >
                  <span>Assigned Teams</span>
                  <Icon 
                    name={sortConfig.key === 'teams' && sortConfig.direction === 'desc' ? 'ChevronDown' : 'ChevronUp'} 
                    size={16} 
                    className={sortConfig.key === 'teams' ? 'text-primary' : 'text-muted-foreground'}
                  />
                </button>
              </th>
              <th className="text-left px-4 py-3">
                <span className="text-sm font-medium text-foreground">Business Functions</span>
              </th>
              <th className="text-left px-4 py-3">
                <button
                  onClick={() => handleSort('status')}
                  className="flex items-center space-x-2 text-sm font-medium text-foreground hover:text-primary enterprise-transition"
                >
                  <span>Status</span>
                  <Icon 
                    name={sortConfig.key === 'status' && sortConfig.direction === 'desc' ? 'ChevronDown' : 'ChevronUp'} 
                    size={16} 
                    className={sortConfig.key === 'status' ? 'text-primary' : 'text-muted-foreground'}
                  />
                </button>
              </th>
              <th className="text-left px-4 py-3">
                <button
                  onClick={() => handleSort('lastUpdated')}
                  className="flex items-center space-x-2 text-sm font-medium text-foreground hover:text-primary enterprise-transition"
                >
                  <span>Last Updated</span>
                  <Icon 
                    name={sortConfig.key === 'lastUpdated' && sortConfig.direction === 'desc' ? 'ChevronDown' : 'ChevronUp'} 
                    size={16} 
                    className={sortConfig.key === 'lastUpdated' ? 'text-primary' : 'text-muted-foreground'}
                  />
                </button>
              </th>
              <th className="text-center px-4 py-3 w-24">
                <span className="text-sm font-medium text-foreground">Actions</span>
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {sortedTechnologies.map((technology) => (
              <tr 
                key={technology.id} 
                className="hover:bg-muted/30 enterprise-transition cursor-pointer"
                onClick={() => onTechnologySelect(technology)}
              >
                <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                  <Checkbox
                    checked={selectedTechnologies.includes(technology.id)}
                    onChange={(e) => handleSelectTechnology(technology.id, e.target.checked)}
                  />
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Icon name="Server" size={16} className="text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{technology.name}</p>
                      <p className="text-xs text-muted-foreground">{technology.category}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1">
                    {technology.teams.map((team) => (
                      <span
                        key={team}
                        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getTeamColor(team)}`}
                      >
                        {team}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="text-sm text-foreground">
                    {technology.businessFunctions.slice(0, 2).map((func, index) => (
                      <div key={index} className="truncate">{func}</div>
                    ))}
                    {technology.businessFunctions.length > 2 && (
                      <div className="text-xs text-muted-foreground">
                        +{technology.businessFunctions.length - 2} more
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(technology.status)}`}>
                    {technology.status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="text-sm text-foreground">{formatDate(technology.lastUpdated)}</div>
                  <div className="text-xs text-muted-foreground">by {technology.updatedBy}</div>
                </td>
                <td className="px-4 py-3" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center space-x-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onEdit(technology)}
                      className="h-8 w-8"
                    >
                      <Icon name="Edit" size={14} />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => onDelete(technology.id)}
                      className="h-8 w-8 text-error hover:text-error"
                    >
                      <Icon name="Trash2" size={14} />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default TechnologyTable;