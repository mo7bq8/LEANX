import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const CategorySidebar = ({ 
  categories, 
  selectedCategory, 
  onCategorySelect,
  technologyCounts 
}) => {
  const [expandedCategories, setExpandedCategories] = useState(['Database', 'Middleware']);

  const toggleCategory = (categoryName) => {
    setExpandedCategories(prev => 
      prev.includes(categoryName) 
        ? prev.filter(cat => cat !== categoryName)
        : [...prev, categoryName]
    );
  };

  const getCategoryIcon = (category) => {
    const icons = {
      'Database': 'Database',
      'Middleware': 'Layers',
      'Operating System': 'Monitor',
      'Development Tool': 'Code',
      'Security': 'Shield',
      'Monitoring': 'Activity',
      'Network': 'Network',
      'Cloud': 'Cloud'
    };
    return icons[category] || 'Server';
  };

  return (
    <div className="bg-card rounded-lg border border-border enterprise-shadow-card h-fit">
      <div className="p-4 border-b border-border">
        <div className="flex items-center space-x-2">
          <Icon name="FolderTree" size={20} className="text-primary" />
          <h3 className="text-lg font-semibold text-foreground">Technology Categories</h3>
        </div>
      </div>

      <div className="p-2">
        {/* All Technologies */}
        <button
          onClick={() => onCategorySelect(null)}
          className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left enterprise-transition ${
            selectedCategory === null 
              ? 'bg-primary text-primary-foreground' 
              : 'text-foreground hover:bg-muted'
          }`}
        >
          <div className="flex items-center space-x-3">
            <Icon name="Grid3X3" size={16} />
            <span className="text-sm font-medium">All Technologies</span>
          </div>
          <span className={`text-xs px-2 py-1 rounded-full ${
            selectedCategory === null 
              ? 'bg-primary-foreground/20 text-primary-foreground' 
              : 'bg-muted text-muted-foreground'
          }`}>
            {Object.values(technologyCounts).reduce((sum, count) => sum + count, 0)}
          </span>
        </button>

        {/* Category Tree */}
        <div className="mt-2 space-y-1">
          {categories.map((category) => {
            const isExpanded = expandedCategories.includes(category.name);
            const isSelected = selectedCategory === category.name;
            const count = technologyCounts[category.name] || 0;

            return (
              <div key={category.name}>
                <div className="flex items-center">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => toggleCategory(category.name)}
                    className="h-8 w-8 mr-1"
                  >
                    <Icon 
                      name={isExpanded ? "ChevronDown" : "ChevronRight"} 
                      size={14} 
                    />
                  </Button>
                  <button
                    onClick={() => onCategorySelect(category.name)}
                    className={`flex-1 flex items-center justify-between px-2 py-2 rounded-lg text-left enterprise-transition ${
                      isSelected 
                        ? 'bg-primary text-primary-foreground' 
                        : 'text-foreground hover:bg-muted'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <Icon 
                        name={getCategoryIcon(category.name)} 
                        size={16} 
                        className={isSelected ? 'text-primary-foreground' : 'text-muted-foreground'}
                      />
                      <span className="text-sm font-medium">{category.name}</span>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      isSelected 
                        ? 'bg-primary-foreground/20 text-primary-foreground' 
                        : 'bg-muted text-muted-foreground'
                    }`}>
                      {count}
                    </span>
                  </button>
                </div>

                {/* Subcategories */}
                {isExpanded && category.subcategories && (
                  <div className="ml-6 mt-1 space-y-1">
                    {category.subcategories.map((subcategory) => (
                      <button
                        key={subcategory.name}
                        onClick={() => onCategorySelect(subcategory.name)}
                        className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-left enterprise-transition ${
                          selectedCategory === subcategory.name 
                            ? 'bg-primary/10 text-primary' :'text-muted-foreground hover:bg-muted hover:text-foreground'
                        }`}
                      >
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 rounded-full bg-current opacity-50" />
                          <span className="text-sm">{subcategory.name}</span>
                        </div>
                        <span className="text-xs px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground">
                          {subcategory.count || 0}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="p-4 border-t border-border">
        <h4 className="text-sm font-medium text-foreground mb-3">Quick Stats</h4>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Production</span>
            <span className="text-success font-medium">67</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Development</span>
            <span className="text-warning font-medium">23</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Planned</span>
            <span className="text-accent font-medium">12</span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Deprecated</span>
            <span className="text-error font-medium">6</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategorySidebar;