import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import FilterPanel from './components/FilterPanel';
import CategorySidebar from './components/CategorySidebar';
import TechnologyTable from './components/TechnologyTable';
import TechnologyDetails from './components/TechnologyDetails';
import TeamTechnologyMatrix from './components/TeamTechnologyMatrix';
import BulkActions from './components/BulkActions';
import technologyService from '../../services/technologyService';

const TechnologyArchitecture = () => {
  const [selectedTechnologies, setSelectedTechnologies] = useState([]);
  const [selectedTechnology, setSelectedTechnology] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [showMatrix, setShowMatrix] = useState(false);
  const [filters, setFilters] = useState({
    search: '',
    teams: [],
    status: [],
    categories: [],
    businessFunctions: []
  });
  const [technologies, setTechnologies] = useState([]);
  const [filterOptions, setFilterOptions] = useState({});
  const [statistics, setStatistics] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Mock categories data - this could be loaded from a separate service
  const mockCategories = [
    {
      name: "Database",
      subcategories: [
        { name: "Relational", count: 15 },
        { name: "NoSQL", count: 8 },
        { name: "Time Series", count: 5 }
      ]
    },
    {
      name: "Middleware",
      subcategories: [
        { name: "Message Queues", count: 6 },
        { name: "API Gateway", count: 4 },
        { name: "Data Integration", count: 7 }
      ]
    },
    {
      name: "Operating System",
      subcategories: [
        { name: "Windows Server", count: 12 },
        { name: "Linux", count: 18 },
        { name: "Unix", count: 3 }
      ]
    },
    {
      name: "Development Tool",
      subcategories: [
        { name: "IDE", count: 8 },
        { name: "Version Control", count: 5 },
        { name: "Testing", count: 6 }
      ]
    },
    {
      name: "Security",
      subcategories: [
        { name: "SIEM", count: 4 },
        { name: "Firewall", count: 6 },
        { name: "Identity Management", count: 5 }
      ]
    },
    {
      name: "Monitoring",
      subcategories: [
        { name: "Infrastructure", count: 9 },
        { name: "Application", count: 7 },
        { name: "Network", count: 5 }
      ]
    },
    {
      name: "Network",
      subcategories: [
        { name: "Switches", count: 12 },
        { name: "Routers", count: 8 },
        { name: "Wireless", count: 6 }
      ]
    },
    {
      name: "Cloud",
      subcategories: [
        { name: "IaaS", count: 5 },
        { name: "PaaS", count: 3 },
        { name: "SaaS", count: 8 }
      ]
    }
  ];

  // Load technologies data from SQLite
  useEffect(() => {
    loadTechnologies();
    loadFilterOptions();
    loadStatistics();
  }, []);

  const loadTechnologies = async () => {
    try {
      setLoading(true);
      const data = await technologyService.getAllTechnologies();
      setTechnologies(data);
      setError(null);
    } catch (err) {
      console.error('Failed to load technologies:', err);
      setError('Failed to load technologies');
    } finally {
      setLoading(false);
    }
  };

  const loadFilterOptions = async () => {
    try {
      const options = await technologyService.getFilterOptions();
      setFilterOptions(options);
    } catch (err) {
      console.error('Failed to load filter options:', err);
    }
  };

  const loadStatistics = async () => {
    try {
      const stats = await technologyService.getStatistics();
      setStatistics(stats);
    } catch (err) {
      console.error('Failed to load statistics:', err);
    }
  };

  // Calculate technology counts by category
  const technologyCounts = useMemo(() => {
    const counts = {};
    mockCategories.forEach(category => {
      counts[category.name] = technologies.filter(tech => tech.category === category.name).length;
    });
    return counts;
  }, [technologies]);

  // Filter technologies based on current filters
  const filteredTechnologies = useMemo(() => {
    return technologies.filter(technology => {
      // Search filter
      if (filters.search && !technology.name?.toLowerCase().includes(filters.search.toLowerCase()) &&
          !technology.vendor?.toLowerCase().includes(filters.search.toLowerCase()) &&
          !technology.description?.toLowerCase().includes(filters.search.toLowerCase())) {
        return false;
      }

      // Category filter (from sidebar)
      if (selectedCategory && technology.category !== selectedCategory) {
        return false;
      }

      // Teams filter
      if (filters.teams.length > 0 && !filters.teams.some(team => technology.teams?.includes(team))) {
        return false;
      }

      // Status filter
      if (filters.status.length > 0 && !filters.status.includes(technology.status)) {
        return false;
      }

      // Categories filter
      if (filters.categories.length > 0 && !filters.categories.includes(technology.category)) {
        return false;
      }

      // Business functions filter
      if (filters.businessFunctions.length > 0 && 
          !filters.businessFunctions.some(func => technology.businessFunctions?.includes(func))) {
        return false;
      }

      return true;
    });
  }, [technologies, filters, selectedCategory]);

  // Handle filter changes
  const handleFilterChange = (newFilters) => {
    setFilters(newFilters);
  };

  const handleClearFilters = () => {
    setFilters({
      search: '',
      teams: [],
      status: [],
      categories: [],
      businessFunctions: []
    });
    setSelectedCategory(null);
  };

  // Handle technology selection
  const handleTechnologySelect = (technology) => {
    setSelectedTechnology(technology);
  };

  // Handle category selection
  const handleCategorySelect = (category) => {
    setSelectedCategory(category);
  };

  // Handle bulk actions
  const handleBulkStatusUpdate = async (techIds, status) => {
    try {
      console.log('Bulk status update:', techIds, status);
      await technologyService.bulkUpdateTechnologies(techIds, { status, updatedBy: 'System' });
      await loadTechnologies();
      await loadStatistics();
      setSelectedTechnologies([]);
    } catch (err) {
      console.error('Error in bulk status update:', err);
      setError('Failed to update technology statuses');
    }
  };

  const handleBulkTeamAssignment = async (techIds, teams) => {
    try {
      console.log('Bulk team assignment:', techIds, teams);
      await technologyService.bulkUpdateTechnologies(techIds, { teams, updatedBy: 'System' });
      await loadTechnologies();
      setSelectedTechnologies([]);
    } catch (err) {
      console.error('Error in bulk team assignment:', err);
      setError('Failed to assign teams');
    }
  };

  const handleBulkDelete = async (techIds) => {
    try {
      if (!window.confirm(`Are you sure you want to delete ${techIds.length} technologies? This action cannot be undone.`)) {
        return;
      }
      
      console.log('Bulk delete:', techIds);
      await technologyService.bulkDeleteTechnologies(techIds);
      await loadTechnologies();
      await loadStatistics();
      setSelectedTechnologies([]);
    } catch (err) {
      console.error('Error in bulk delete:', err);
      setError('Failed to delete technologies');
    }
  };

  const handleExport = (techIds) => {
    console.log('Export technologies:', techIds);
    // Implementation would export technology data
  };

  // Handle CRUD operations
  const handleEdit = (technology) => {
    console.log('Edit technology:', technology);
    // Implementation would open edit modal
  };

  const handleDelete = async (techId) => {
    try {
      if (!window.confirm('Are you sure you want to delete this technology?')) {
        return;
      }
      
      console.log('Delete technology:', techId);
      await technologyService.deleteTechnology(techId);
      await loadTechnologies();
      await loadStatistics();
      
      // Clear selected technology if it was deleted
      if (selectedTechnology?.id === techId) {
        setSelectedTechnology(null);
      }
    } catch (err) {
      console.error('Error deleting technology:', err);
      setError('Failed to delete technology');
    }
  };

  const handleStatusUpdate = async (techId, status) => {
    try {
      console.log('Update status:', techId, status);
      await technologyService.updateTechnology(techId, { status, updatedBy: 'System' });
      await loadTechnologies();
      
      // Update selected technology if it was the one being updated
      if (selectedTechnology?.id === techId) {
        const updatedTech = await technologyService.getTechnologyById(techId);
        setSelectedTechnology(updatedTech);
      }
    } catch (err) {
      console.error('Error updating technology status:', err);
      setError('Failed to update technology status');
    }
  };

  // Handle matrix interactions
  const handleMatrixCellClick = (team, category) => {
    console.log('Matrix cell clicked:', team, category);
    setFilters(prev => ({
      ...prev,
      teams: [team],
      categories: [category]
    }));
  };

  // Clear selection when filters change
  useEffect(() => {
    setSelectedTechnologies([]);
  }, [filters, selectedCategory]);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Sidebar />
        <main className="pt-16 lg:ml-64">
          <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading technologies...</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Sidebar />
        <main className="pt-16 lg:ml-64">
          <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
            <div className="text-center">
              <Icon name="AlertCircle" size={48} className="text-error mx-auto mb-4" />
              <p className="text-error mb-4">{error}</p>
              <button
                onClick={() => {
                  setError(null);
                  loadTechnologies();
                }}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              >
                Retry
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      
      <main className="pt-16 lg:ml-64">
        <div className="p-6">
          {/* Page Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-8"
          >
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground">Technology Architecture</h1>
                <p className="text-muted-foreground mt-2">
                  Manage {statistics?.totalTechnologies || 0}+ technology entries with team assignments, business function linking, and lifecycle tracking
                </p>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  iconName="Upload"
                  iconPosition="left"
                >
                  Import Technologies
                </Button>
                <Button
                  variant="default"
                  iconName="Plus"
                  iconPosition="left"
                >
                  Add Technology
                </Button>
              </div>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-6">
              <div className="bg-card rounded-lg border border-border p-4 enterprise-shadow-card">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
                    <Icon name="Play" size={20} className="text-success" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{statistics?.productionCount || 0}</p>
                    <p className="text-sm text-muted-foreground">Production</p>
                  </div>
                </div>
              </div>
              <div className="bg-card rounded-lg border border-border p-4 enterprise-shadow-card">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
                    <Icon name="Code" size={20} className="text-warning" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{statistics?.developmentCount || 0}</p>
                    <p className="text-sm text-muted-foreground">Development</p>
                  </div>
                </div>
              </div>
              <div className="bg-card rounded-lg border border-border p-4 enterprise-shadow-card">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
                    <Icon name="Calendar" size={20} className="text-accent" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{statistics?.plannedCount || 0}</p>
                    <p className="text-sm text-muted-foreground">Planned</p>
                  </div>
                </div>
              </div>
              <div className="bg-card rounded-lg border border-border p-4 enterprise-shadow-card">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-error/10 rounded-lg flex items-center justify-center">
                    <Icon name="AlertTriangle" size={20} className="text-error" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-foreground">{statistics?.deprecatedCount || 0}</p>
                    <p className="text-sm text-muted-foreground">Deprecated</p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Filter Panel */}
          <FilterPanel
            filters={filters}
            onFilterChange={handleFilterChange}
            onClearFilters={handleClearFilters}
            resultCount={filteredTechnologies.length}
            totalCount={technologies.length}
            filterOptions={filterOptions}
          />

          {/* Bulk Actions */}
          <BulkActions
            selectedTechnologies={selectedTechnologies}
            onBulkStatusUpdate={handleBulkStatusUpdate}
            onBulkTeamAssignment={handleBulkTeamAssignment}
            onBulkDelete={handleBulkDelete}
            onExport={handleExport}
            onClearSelection={() => setSelectedTechnologies([])}
          />

          {/* Team-Technology Matrix */}
          <TeamTechnologyMatrix
            technologies={filteredTechnologies}
            onMatrixCellClick={handleMatrixCellClick}
            isVisible={showMatrix}
            onToggle={() => setShowMatrix(!showMatrix)}
          />

          {/* Main Content Layout */}
          <div className="grid grid-cols-12 gap-6">
            {/* Category Sidebar */}
            <div className="col-span-12 lg:col-span-3">
              <CategorySidebar
                categories={mockCategories}
                selectedCategory={selectedCategory}
                onCategorySelect={handleCategorySelect}
                technologyCounts={technologyCounts}
              />
            </div>

            {/* Technology Table */}
            <div className="col-span-12 lg:col-span-6">
              <TechnologyTable
                technologies={filteredTechnologies}
                selectedTechnologies={selectedTechnologies}
                onSelectionChange={setSelectedTechnologies}
                onTechnologySelect={handleTechnologySelect}
                onStatusUpdate={handleStatusUpdate}
                onEdit={handleEdit}
                onDelete={handleDelete}
              />
            </div>

            {/* Technology Details */}
            <div className="col-span-12 lg:col-span-3">
              <TechnologyDetails
                technology={selectedTechnology}
                onClose={() => setSelectedTechnology(null)}
                onEdit={handleEdit}
                onStatusUpdate={handleStatusUpdate}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default TechnologyArchitecture;