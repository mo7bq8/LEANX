import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const RecentActivity = () => {
  const activities = [
    {
      id: 1,
      type: 'application',
      action: 'updated',
      item: 'IBM Maximo Asset Management',
      user: 'Sarah Chen',
      timestamp: '2 hours ago',
      icon: 'Layers',
      color: 'text-blue-500'
    },
    {
      id: 2,
      type: 'security',
      action: 'added',
      item: 'Azure AD Security Control',
      user: 'Mike Rodriguez',
      timestamp: '4 hours ago',
      icon: 'Shield',
      color: 'text-red-500'
    },
    {
      id: 3,
      type: 'technology',
      action: 'assigned',
      item: 'Oracle Database 19c to CS Team',
      user: 'Jennifer Liu',
      timestamp: '6 hours ago',
      icon: 'Server',
      color: 'text-purple-500'
    },
    {
      id: 4,
      type: 'business',
      action: 'mapped',
      item: 'Process Control to ITP Team',
      user: 'David Kim',
      timestamp: '8 hours ago',
      icon: 'Building',
      color: 'text-green-500'
    },
    {
      id: 5,
      type: 'relationship',
      action: 'created',
      item: 'Application-Technology Link',
      user: 'Anna Thompson',
      timestamp: '1 day ago',
      icon: 'Network',
      color: 'text-orange-500'
    }
  ];

  const getActionColor = (action) => {
    const colors = {
      updated: 'text-blue-500',
      added: 'text-success',
      assigned: 'text-purple-500',
      mapped: 'text-green-500',
      created: 'text-orange-500',
      deleted: 'text-error'
    };
    return colors[action] || 'text-muted-foreground';
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 enterprise-shadow-card">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Recent Activity</h2>
          <p className="text-sm text-muted-foreground">Latest changes across architecture domains</p>
        </div>
        <Icon name="Activity" size={24} className="text-muted-foreground" />
      </div>

      <div className="space-y-4">
        {activities.map((activity, index) => (
          <motion.div
            key={activity.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="flex items-start space-x-3 p-3 hover:bg-muted/30 rounded-lg enterprise-transition"
          >
            <div className={`p-2 rounded-lg bg-muted/50 ${activity.color}`}>
              <Icon name={activity.icon} size={16} />
            </div>
            
            <div className="flex-1 min-w-0">
              <div className="flex items-center space-x-2 mb-1">
                <span className="text-sm font-medium text-foreground">{activity.user}</span>
                <span className={`text-sm font-medium ${getActionColor(activity.action)}`}>
                  {activity.action}
                </span>
              </div>
              <p className="text-sm text-muted-foreground truncate">{activity.item}</p>
              <p className="text-xs text-muted-foreground mt-1">{activity.timestamp}</p>
            </div>
            
            <Icon name="MoreHorizontal" size={16} className="text-muted-foreground cursor-pointer hover:text-foreground" />
          </motion.div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-border">
        <button className="w-full text-sm text-primary hover:text-primary/80 font-medium enterprise-transition">
          View All Activity
        </button>
      </div>
    </div>
  );
};

export default RecentActivity;