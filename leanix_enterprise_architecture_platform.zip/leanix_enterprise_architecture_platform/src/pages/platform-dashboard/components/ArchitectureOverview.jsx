import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const ArchitectureOverview = () => {
  const architectureLayers = [
    {
      id: 'business',
      name: 'Business Architecture',
      description: 'Organizational capabilities and business functions',
      components: 177,
      teams: 25,
      status: 'healthy',
      icon: 'Building',
      color: 'bg-blue-500'
    },
    {
      id: 'application',
      name: 'Application Architecture',
      description: 'Application portfolio and system integrations',
      components: 86,
      teams: 5,
      status: 'warning',
      icon: 'Layers',
      color: 'bg-green-500'
    },
    {
      id: 'technology',
      name: 'Technology Architecture',
      description: 'Infrastructure and technology stack',
      components: 104,
      teams: 5,
      status: 'healthy',
      icon: 'Server',
      color: 'bg-purple-500'
    },
    {
      id: 'security',
      name: 'Security Architecture',
      description: 'Security controls and compliance framework',
      components: 34,
      teams: 3,
      status: 'critical',
      icon: 'Shield',
      color: 'bg-red-500'
    }
  ];

  const getStatusColor = (status) => {
    const colors = {
      healthy: 'text-success bg-success/10',
      warning: 'text-warning bg-warning/10',
      critical: 'text-error bg-error/10'
    };
    return colors[status] || colors.healthy;
  };

  const getStatusIcon = (status) => {
    const icons = {
      healthy: 'CheckCircle',
      warning: 'AlertTriangle',
      critical: 'AlertCircle'
    };
    return icons[status] || icons.healthy;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 enterprise-shadow-card">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Architecture Overview</h2>
          <p className="text-sm text-muted-foreground">Enterprise architecture layers and health status</p>
        </div>
        <Icon name="Network" size={24} className="text-muted-foreground" />
      </div>

      <div className="space-y-4">
        {architectureLayers.map((layer, index) => (
          <motion.div
            key={layer.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-center space-x-4 p-4 bg-muted/30 rounded-lg hover:bg-muted/50 enterprise-transition cursor-pointer"
          >
            <div className={`w-12 h-12 ${layer.color} rounded-lg flex items-center justify-center`}>
              <Icon name={layer.icon} size={20} color="white" />
            </div>
            
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <h3 className="font-medium text-foreground">{layer.name}</h3>
                <div className={`flex items-center space-x-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(layer.status)}`}>
                  <Icon name={getStatusIcon(layer.status)} size={12} />
                  <span className="capitalize">{layer.status}</span>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-2">{layer.description}</p>
              <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                <span>{layer.components} Components</span>
                <span>•</span>
                <span>{layer.teams} Teams</span>
              </div>
            </div>
            
            <Icon name="ChevronRight" size={16} className="text-muted-foreground" />
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default ArchitectureOverview;