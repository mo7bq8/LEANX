import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';

const ComplianceOverview = () => {
  const complianceMetrics = [
    {
      id: 'ics-compliance',
      name: 'ICS Level Compliance',
      score: 87,
      status: 'good',
      details: '74 of 86 applications compliant',
      icon: 'Shield',
      trend: 'up'
    },
    {
      id: 'security-controls',
      name: 'Security Controls',
      score: 92,
      status: 'excellent',
      details: '31 of 34 controls implemented',
      icon: 'Lock',
      trend: 'up'
    },
    {
      id: 'vendor-compliance',
      name: 'Vendor Compliance',
      score: 78,
      status: 'warning',
      details: '3 vendors require attention',
      icon: 'Users',
      trend: 'down'
    },
    {
      id: 'architecture-coverage',
      name: 'Architecture Coverage',
      score: 95,
      status: 'excellent',
      details: 'All domains mapped',
      icon: 'Network',
      trend: 'stable'
    }
  ];

  const getScoreColor = (score) => {
    if (score >= 90) return 'text-success';
    if (score >= 75) return 'text-warning';
    return 'text-error';
  };

  const getStatusColor = (status) => {
    const colors = {
      excellent: 'bg-success/10 text-success',
      good: 'bg-blue-500/10 text-blue-500',
      warning: 'bg-warning/10 text-warning',
      critical: 'bg-error/10 text-error'
    };
    return colors[status] || colors.good;
  };

  const getTrendIcon = (trend) => {
    const icons = {
      up: 'TrendingUp',
      down: 'TrendingDown',
      stable: 'Minus'
    };
    return icons[trend] || icons.stable;
  };

  const getTrendColor = (trend) => {
    const colors = {
      up: 'text-success',
      down: 'text-error',
      stable: 'text-muted-foreground'
    };
    return colors[trend] || colors.stable;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-6 enterprise-shadow-card">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">Compliance Overview</h2>
          <p className="text-sm text-muted-foreground">Architecture compliance and risk assessment</p>
        </div>
        <Icon name="CheckCircle" size={24} className="text-muted-foreground" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {complianceMetrics.map((metric, index) => (
          <motion.div
            key={metric.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="p-4 bg-muted/20 rounded-lg border border-border/50"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-2">
                <Icon name={metric.icon} size={16} className="text-muted-foreground" />
                <h3 className="text-sm font-medium text-foreground">{metric.name}</h3>
              </div>
              <div className={`flex items-center space-x-1 ${getTrendColor(metric.trend)}`}>
                <Icon name={getTrendIcon(metric.trend)} size={12} />
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className={`text-2xl font-bold ${getScoreColor(metric.score)}`}>
                  {metric.score}%
                </span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(metric.status)}`}>
                  {metric.status}
                </span>
              </div>
              
              <div className="w-full bg-muted rounded-full h-2">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${metric.score}%` }}
                  transition={{ delay: index * 0.1 + 0.2, duration: 0.8 }}
                  className={`h-2 rounded-full ${
                    metric.score >= 90 ? 'bg-success' :
                    metric.score >= 75 ? 'bg-warning' : 'bg-error'
                  }`}
                />
              </div>
              
              <p className="text-xs text-muted-foreground">{metric.details}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Last updated: July 24, 2025 at 7:35 AM
          </div>
          <button className="text-sm text-primary hover:text-primary/80 font-medium enterprise-transition">
            Generate Report
          </button>
        </div>
      </div>
    </div>
  );
};

export default ComplianceOverview;