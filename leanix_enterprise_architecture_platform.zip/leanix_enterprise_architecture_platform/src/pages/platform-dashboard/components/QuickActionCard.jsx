import React from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QuickActionCard = ({ title, description, actions, icon, color = 'primary' }) => {
  const getColorClasses = (colorType) => {
    const colors = {
      primary: 'bg-primary/5 border-primary/20',
      success: 'bg-success/5 border-success/20',
      warning: 'bg-warning/5 border-warning/20',
      error: 'bg-error/5 border-error/20',
      accent: 'bg-accent/5 border-accent/20'
    };
    return colors[colorType] || colors.primary;
  };

  const getIconColor = (colorType) => {
    const colors = {
      primary: 'text-primary',
      success: 'text-success',
      warning: 'text-warning',
      error: 'text-error',
      accent: 'text-accent'
    };
    return colors[colorType] || colors.primary;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`
        bg-card border rounded-lg p-6 enterprise-shadow-card
        ${getColorClasses(color)}
      `}
    >
      <div className="flex items-start space-x-4">
        <div className={`p-3 rounded-lg bg-card border ${getIconColor(color)}`}>
          <Icon name={icon} size={24} />
        </div>
        
        <div className="flex-1 space-y-3">
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-1">{title}</h3>
            <p className="text-sm text-muted-foreground">{description}</p>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {actions.map((action, index) => (
              <Button
                key={index}
                variant={index === 0 ? 'default' : 'outline'}
                size="sm"
                onClick={action.onClick}
                iconName={action.icon}
                iconPosition="left"
              >
                {action.label}
              </Button>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default QuickActionCard;