import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import StatCard from './components/StatCard';
import QuickActionCard from './components/QuickActionCard';
import ArchitectureOverview from './components/ArchitectureOverview';
import RecentActivity from './components/RecentActivity';
import ComplianceOverview from './components/ComplianceOverview';

import Button from '../../components/ui/Button';

const PlatformDashboard = () => {
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000); // Update every minute

    return () => clearInterval(timer);
  }, []);

  // Mock dashboard statistics
  const dashboardStats = [
    {
      title: 'Business Functions',
      value: '177',
      change: '+12',
      changeType: 'positive',
      icon: 'Building',
      color: 'primary',
      description: 'Active business capabilities',
      onClick: () => navigate('/business-capabilities-management')
    },
    {
      title: 'Applications',
      value: '86',
      change: '+3',
      changeType: 'positive',
      icon: 'Layers',
      color: 'success',
      description: 'Managed applications',
      onClick: () => navigate('/application-architecture')
    },
    {
      title: 'Technologies',
      value: '104',
      change: '+8',
      changeType: 'positive',
      icon: 'Server',
      color: 'accent',
      description: 'Technology components',
      onClick: () => navigate('/technology-architecture')
    },
    {
      title: 'Security Controls',
      value: '34',
      change: '-2',
      changeType: 'negative',
      icon: 'Shield',
      color: 'warning',
      description: 'Active security measures',
      onClick: () => navigate('/security-architecture')
    }
  ];

  // Quick action configurations
  const quickActions = [
    {
      title: 'Application Mapping',
      description: 'Link applications to business functions and teams',
      icon: 'GitBranch',
      color: 'primary',
      actions: [
        {
          label: 'Map Applications',
          icon: 'Plus',
          onClick: () => navigate('/application-architecture')
        },
        {
          label: 'View Mappings',
          icon: 'Eye',
          onClick: () => navigate('/architecture-relationships')
        }
      ]
    },
    {
      title: 'Vendor Analysis',
      description: 'Analyze vendor relationships and technology dependencies',
      icon: 'Users',
      color: 'success',
      actions: [
        {
          label: 'Vendor Dashboard',
          icon: 'BarChart3',
          onClick: () => navigate('/application-architecture')
        },
        {
          label: 'Cost Analysis',
          icon: 'DollarSign',
          onClick: () => navigate('/application-architecture')
        }
      ]
    },
    {
      title: 'Compliance Reporting',
      description: 'Generate ICS level compliance and security reports',
      icon: 'FileText',
      color: 'warning',
      actions: [
        {
          label: 'Generate Report',
          icon: 'Download',
          onClick: () => console.log('Generate compliance report')
        },
        {
          label: 'View History',
          icon: 'History',
          onClick: () => console.log('View report history')
        }
      ]
    }
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      
      <main className="pt-16 lg:ml-64">
        <div className="p-6 space-y-6">
          {/* Dashboard Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0"
          >
            <div>
              <h1 className="text-3xl font-bold text-foreground">Platform Dashboard</h1>
              <p className="text-muted-foreground mt-1">
                Enterprise Architecture Management Center • {currentTime.toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </p>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                iconName="RefreshCw"
                iconPosition="left"
                onClick={() => window.location.reload()}
              >
                Refresh Data
              </Button>
              <Button
                variant="default"
                iconName="Download"
                iconPosition="left"
                onClick={() => console.log('Export dashboard')}
              >
                Export Dashboard
              </Button>
            </div>
          </motion.div>

          {/* Key Performance Indicators */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          >
            {dashboardStats.map((stat, index) => (
              <motion.div key={stat.title} variants={itemVariants}>
                <StatCard {...stat} />
              </motion.div>
            ))}
          </motion.div>

          {/* Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Architecture Overview */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-2 space-y-6"
            >
              <ArchitectureOverview />
              
              {/* Quick Actions */}
              <div className="space-y-4">
                <h2 className="text-xl font-semibold text-foreground">Quick Actions</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {quickActions.map((action, index) => (
                    <QuickActionCard key={action.title} {...action} />
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Right Column - Activity & Compliance */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="space-y-6"
            >
              <RecentActivity />
              <ComplianceOverview />
            </motion.div>
          </div>

          {/* System Status Footer */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="bg-card border border-border rounded-lg p-4 enterprise-shadow-card"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-success rounded-full animate-pulse"></div>
                <span className="text-sm font-medium text-foreground">System Status: All Services Operational</span>
              </div>
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <span>Last Sync: {currentTime.toLocaleTimeString('en-US', { 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}</span>
                <span>•</span>
                <span>Database: Connected</span>
                <span>•</span>
                <span>API: Healthy</span>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
};

export default PlatformDashboard;