import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const ToolbarActions = ({ 
  onCreateNode, 
  onBulkAction, 
  onExport, 
  onImport,
  selectedNodes,
  filterOptions,
  onFilterChange,
  currentFilters
}) => {
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [newNodeData, setNewNodeData] = useState({
    name: '',
    type: 'business-function',
    parentId: '',
    description: ''
  });

  const nodeTypeOptions = [
    { value: 'division', label: 'Division' },
    { value: 'group', label: 'Group' },
    { value: 'team', label: 'Team' },
    { value: 'business-function', label: 'Business Function' }
  ];

  const divisionOptions = [
    { value: 'admin', label: 'Admin Division' },
    { value: 'commercial', label: 'Commercial Division' }
  ];

  const teamTypeOptions = [
    { value: 'all', label: 'All Teams' },
    { value: 'CS', label: 'Cyber Security (CS)' },
    { value: 'CA', label: 'Control Automation (CA)' },
    { value: 'CoA', label: 'Control Architecture (CoA)' },
    { value: 'ITP', label: 'IT Production (ITP)' },
    { value: 'ITO', label: 'IT Operations (ITO)' }
  ];

  const handleCreateNode = () => {
    onCreateNode(newNodeData);
    setNewNodeData({ name: '', type: 'business-function', parentId: '', description: '' });
    setShowCreateModal(false);
  };

  const handleBulkAction = (action) => {
    onBulkAction(action, selectedNodes);
    setShowBulkActions(false);
  };

  const handleExport = (format) => {
    onExport(format, currentFilters);
  };

  return (
    <div className="bg-card border-b border-border p-4">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        {/* Left Section - Actions */}
        <div className="flex flex-wrap items-center gap-3">
          <Button
            onClick={() => setShowCreateModal(true)}
            iconName="Plus"
            iconPosition="left"
          >
            Create Node
          </Button>

          {selectedNodes.length > 0 && (
            <div className="relative">
              <Button
                variant="outline"
                onClick={() => setShowBulkActions(!showBulkActions)}
                iconName="MoreHorizontal"
                iconPosition="left"
              >
                Bulk Actions ({selectedNodes.length})
              </Button>

              {showBulkActions && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute top-full left-0 mt-2 w-48 bg-popover border border-border rounded-lg shadow-lg z-50"
                >
                  <div className="py-2">
                    <button
                      onClick={() => handleBulkAction('delete')}
                      className="flex items-center space-x-2 w-full px-3 py-2 text-sm text-error hover:bg-error/10 enterprise-transition"
                    >
                      <Icon name="Trash2" size={16} />
                      <span>Delete Selected</span>
                    </button>
                    <button
                      onClick={() => handleBulkAction('export')}
                      className="flex items-center space-x-2 w-full px-3 py-2 text-sm text-foreground hover:bg-muted enterprise-transition"
                    >
                      <Icon name="Download" size={16} />
                      <span>Export Selected</span>
                    </button>
                    <button
                      onClick={() => handleBulkAction('move')}
                      className="flex items-center space-x-2 w-full px-3 py-2 text-sm text-foreground hover:bg-muted enterprise-transition"
                    >
                      <Icon name="Move" size={16} />
                      <span>Move Selected</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </div>
          )}

          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleExport('csv')}
              iconName="FileText"
              iconPosition="left"
            >
              Export CSV
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleExport('json')}
              iconName="Code"
              iconPosition="left"
            >
              Export JSON
            </Button>
          </div>
        </div>

        {/* Right Section - Filters */}
        <div className="flex flex-wrap items-center gap-3">
          <Select
            options={divisionOptions}
            value={currentFilters.division}
            onChange={(value) => onFilterChange('division', value)}
            placeholder="Filter by Division"
            className="w-48"
          />

          <Select
            options={teamTypeOptions}
            value={currentFilters.teamType}
            onChange={(value) => onFilterChange('teamType', value)}
            placeholder="Filter by Team Type"
            className="w-48"
          />

          <Button
            variant="outline"
            size="sm"
            onClick={() => onFilterChange('reset')}
            iconName="RotateCcw"
            iconPosition="left"
          >
            Reset Filters
          </Button>
        </div>
      </div>

      {/* Create Node Modal */}
      {showCreateModal && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="fixed inset-0 bg-black/50 flex items-center justify-center z-100"
          onClick={() => setShowCreateModal(false)}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="bg-card border border-border rounded-lg p-6 w-full max-w-md mx-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-foreground">Create New Node</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowCreateModal(false)}
              >
                <Icon name="X" size={20} />
              </Button>
            </div>

            <div className="space-y-4">
              <Input
                label="Node Name"
                value={newNodeData.name}
                onChange={(e) => setNewNodeData({ ...newNodeData, name: e.target.value })}
                placeholder="Enter node name"
                required
              />

              <Select
                label="Node Type"
                options={nodeTypeOptions}
                value={newNodeData.type}
                onChange={(value) => setNewNodeData({ ...newNodeData, type: value })}
              />

              <Input
                label="Parent ID (Optional)"
                value={newNodeData.parentId}
                onChange={(e) => setNewNodeData({ ...newNodeData, parentId: e.target.value })}
                placeholder="Enter parent node ID"
              />

              <Input
                label="Description (Optional)"
                value={newNodeData.description}
                onChange={(e) => setNewNodeData({ ...newNodeData, description: e.target.value })}
                placeholder="Enter description"
              />
            </div>

            <div className="flex items-center justify-end space-x-3 mt-6">
              <Button
                variant="outline"
                onClick={() => setShowCreateModal(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreateNode}
                disabled={!newNodeData.name}
              >
                Create Node
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}

      {/* Active Filters Display */}
      {(currentFilters.division !== 'all' || currentFilters.teamType !== 'all') && (
        <div className="flex items-center space-x-2 mt-4 pt-4 border-t border-border">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          {currentFilters.division !== 'all' && (
            <span className="px-2 py-1 text-xs bg-primary/10 text-primary rounded-full flex items-center space-x-1">
              <span>Division: {currentFilters.division}</span>
              <button
                onClick={() => onFilterChange('division', 'all')}
                className="hover:bg-primary/20 rounded-full p-0.5"
              >
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
          {currentFilters.teamType !== 'all' && (
            <span className="px-2 py-1 text-xs bg-primary/10 text-primary rounded-full flex items-center space-x-1">
              <span>Team: {currentFilters.teamType}</span>
              <button
                onClick={() => onFilterChange('teamType', 'all')}
                className="hover:bg-primary/20 rounded-full p-0.5"
              >
                <Icon name="X" size={12} />
              </button>
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default ToolbarActions;