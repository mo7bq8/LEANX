import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';


const NodeDetailsPanel = ({ selectedNode, onUpdateNode, onDeleteNode }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({});

  if (!selectedNode) {
    return (
      <div className="h-full flex items-center justify-center bg-muted/20">
        <div className="text-center">
          <Icon name="MousePointer2" size={48} className="mx-auto mb-4 text-muted-foreground opacity-50" />
          <h3 className="text-lg font-medium text-muted-foreground mb-2">
            Select a Node
          </h3>
          <p className="text-sm text-muted-foreground max-w-sm">
            Click on any business function, division, group, or team in the organizational tree to view detailed information.
          </p>
        </div>
      </div>
    );
  }

  const handleEdit = () => {
    setIsEditing(true);
    setEditData({ ...selectedNode });
  };

  const handleSave = () => {
    onUpdateNode(editData);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setEditData({});
  };

  const getNodeTypeIcon = (type) => {
    switch (type) {
      case 'division': return 'Building2';
      case 'group': return 'Users';
      case 'team': return 'User';
      default: return 'Briefcase';
    }
  };

  const getNodeTypeColor = (type) => {
    switch (type) {
      case 'division': return 'text-blue-600 bg-blue-50';
      case 'group': return 'text-green-600 bg-green-50';
      case 'team': return 'text-purple-600 bg-purple-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.3 }}
      className="h-full bg-card overflow-y-auto"
    >
      {/* Header */}
      <div className="sticky top-0 bg-card border-b border-border p-6 z-10">
        <div className="flex items-start justify-between">
          <div className="flex items-start space-x-4">
            <div className={`p-3 rounded-lg ${getNodeTypeColor(selectedNode.type)}`}>
              <Icon name={getNodeTypeIcon(selectedNode.type)} size={24} />
            </div>
            <div className="flex-1">
              {isEditing ? (
                <Input
                  value={editData.name || ''}
                  onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                  className="text-xl font-semibold mb-2"
                />
              ) : (
                <h1 className="text-xl font-semibold text-foreground mb-2">
                  {selectedNode.name}
                </h1>
              )}
              <div className="flex items-center space-x-3">
                <span className="text-sm text-muted-foreground capitalize">
                  {selectedNode.type}
                </span>
                {selectedNode.abbreviation && (
                  <span className="px-2 py-1 text-xs font-medium bg-primary/10 text-primary rounded-full">
                    {selectedNode.abbreviation}
                  </span>
                )}
                {selectedNode.status && (
                  <span className={`
                    px-2 py-1 text-xs font-medium rounded-full
                    ${selectedNode.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}
                  `}>
                    {selectedNode.status}
                  </span>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {isEditing ? (
              <>
                <Button variant="outline" size="sm" onClick={handleCancel}>
                  Cancel
                </Button>
                <Button size="sm" onClick={handleSave}>
                  Save
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" size="sm" onClick={handleEdit}>
                  <Icon name="Edit2" size={16} className="mr-1" />
                  Edit
                </Button>
                <Button variant="destructive" size="sm" onClick={() => onDeleteNode(selectedNode.id)}>
                  <Icon name="Trash2" size={16} className="mr-1" />
                  Delete
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Basic Information */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-foreground">Basic Information</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-muted-foreground">ID</label>
              <p className="text-sm text-foreground mt-1">{selectedNode.id}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-muted-foreground">Type</label>
              <p className="text-sm text-foreground mt-1 capitalize">{selectedNode.type}</p>
            </div>
            {selectedNode.description && (
              <div className="md:col-span-2">
                <label className="text-sm font-medium text-muted-foreground">Description</label>
                {isEditing ? (
                  <Input
                    value={editData.description || ''}
                    onChange={(e) => setEditData({ ...editData, description: e.target.value })}
                    className="mt-1"
                  />
                ) : (
                  <p className="text-sm text-foreground mt-1">{selectedNode.description}</p>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Team Assignments */}
        {selectedNode.teamAssignments && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Team Assignments</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {selectedNode.teamAssignments.map((assignment, index) => (
                <div key={index} className="p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-foreground">
                      {assignment.team}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {assignment.role}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {assignment.members} members
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Business Process Mappings */}
        {selectedNode.businessProcesses && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Business Process Mappings</h2>
            <div className="space-y-2">
              {selectedNode.businessProcesses.map((process, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Icon name="GitBranch" size={16} className="text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium text-foreground">{process.name}</p>
                      <p className="text-xs text-muted-foreground">{process.category}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`
                      px-2 py-1 text-xs font-medium rounded-full
                      ${process.criticality === 'high' ? 'bg-red-100 text-red-800' :
                        process.criticality === 'medium'? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}
                    `}>
                      {process.criticality}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Application Linkages */}
        {selectedNode.applicationLinkages && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Application Linkages</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {selectedNode.applicationLinkages.map((app, index) => (
                <div key={index} className="p-4 border border-border rounded-lg">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Icon name="Package" size={20} className="text-primary" />
                      <div>
                        <h3 className="text-sm font-medium text-foreground">{app.name}</h3>
                        <p className="text-xs text-muted-foreground">{app.vendor}</p>
                      </div>
                    </div>
                    <span className={`
                      px-2 py-1 text-xs font-medium rounded-full
                      ${app.icsLevel === '4' ? 'bg-red-100 text-red-800' :
                        app.icsLevel === '3.7' ? 'bg-orange-100 text-orange-800' :
                        app.icsLevel === '3.5'? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}
                    `}>
                      ICS {app.icsLevel}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    Used by {app.usage} processes
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Cross-Architecture Relationships */}
        {selectedNode.relationships && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Cross-Architecture Relationships</h2>
            <div className="space-y-3">
              {selectedNode.relationships.map((rel, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <Icon name="ArrowRight" size={16} className="text-muted-foreground" />
                    <div>
                      <p className="text-sm font-medium text-foreground">{rel.target}</p>
                      <p className="text-xs text-muted-foreground">{rel.type}</p>
                    </div>
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {rel.strength}% dependency
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Statistics */}
        {selectedNode.statistics && (
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-foreground">Statistics</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(selectedNode.statistics).map(([key, value]) => (
                <div key={key} className="text-center p-4 bg-muted/30 rounded-lg">
                  <div className="text-2xl font-bold text-primary">{value}</div>
                  <div className="text-xs text-muted-foreground capitalize">
                    {key.replace(/([A-Z])/g, ' $1').trim()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default NodeDetailsPanel;