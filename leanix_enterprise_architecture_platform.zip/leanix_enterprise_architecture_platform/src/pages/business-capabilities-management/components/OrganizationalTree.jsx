import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

const OrganizationalTree = ({ 
  organizationalData, 
  selectedNode, 
  onNodeSelect, 
  expandedNodes, 
  onToggleExpand,
  searchQuery,
  onSearchChange 
}) => {
  const [viewMode, setViewMode] = useState('hierarchical');

  const teamColors = {
    'CS': 'bg-blue-100 text-blue-800 border-blue-200',
    'CA': 'bg-green-100 text-green-800 border-green-200',
    'CoA': 'bg-purple-100 text-purple-800 border-purple-200',
    'ITP': 'bg-orange-100 text-orange-800 border-orange-200',
    'ITO': 'bg-red-100 text-red-800 border-red-200'
  };

  const filteredData = useMemo(() => {
    if (!searchQuery) return organizationalData;
    
    const filterNode = (node) => {
      const matchesSearch = node.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           (node.abbreviation && node.abbreviation.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const filteredChildren = node.children ? node.children.map(filterNode).filter(Boolean) : [];
      
      if (matchesSearch || filteredChildren.length > 0) {
        return { ...node, children: filteredChildren };
      }
      
      return null;
    };

    return organizationalData.map(filterNode).filter(Boolean);
  }, [organizationalData, searchQuery]);

  const renderTreeNode = (node, level = 0) => {
    const hasChildren = node.children && node.children.length > 0;
    const isExpanded = expandedNodes.includes(node.id);
    const isSelected = selectedNode?.id === node.id;

    return (
      <motion.div
        key={node.id}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.2, delay: level * 0.05 }}
        className="select-none"
      >
        <div
          className={`
            flex items-center py-2 px-3 rounded-lg cursor-pointer enterprise-transition
            ${isSelected ? 'bg-primary/10 border border-primary/20' : 'hover:bg-muted/50'}
          `}
          style={{ marginLeft: `${level * 20}px` }}
          onClick={() => onNodeSelect(node)}
        >
          {hasChildren && (
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e.stopPropagation();
                onToggleExpand(node.id);
              }}
              className="h-6 w-6 mr-2"
            >
              <Icon 
                name={isExpanded ? "ChevronDown" : "ChevronRight"} 
                size={14} 
              />
            </Button>
          )}
          
          {!hasChildren && <div className="w-6 mr-2" />}
          
          <Icon 
            name={node.type === 'division' ? 'Building2' : 
                  node.type === 'group' ? 'Users' : 
                  node.type === 'team' ? 'User' : 'Briefcase'} 
            size={16} 
            className="mr-2 text-muted-foreground" 
          />
          
          <span className="text-sm font-medium text-foreground flex-1">
            {node.name}
          </span>
          
          {node.abbreviation && (
            <span className={`
              px-2 py-1 text-xs font-medium rounded-full border
              ${teamColors[node.abbreviation] || 'bg-gray-100 text-gray-800 border-gray-200'}
            `}>
              {node.abbreviation}
            </span>
          )}
          
          {node.count && (
            <span className="ml-2 text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
              {node.count}
            </span>
          )}
        </div>

        <AnimatePresence>
          {hasChildren && isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              {node.children.map(child => renderTreeNode(child, level + 1))}
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    );
  };

  return (
    <div className="h-full flex flex-col bg-card border-r border-border">
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-foreground">
            Organizational Structure
          </h2>
          <div className="flex items-center space-x-2">
            <Button
              variant={viewMode === 'hierarchical' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('hierarchical')}
            >
              <Icon name="TreePine" size={16} className="mr-1" />
              Tree
            </Button>
            <Button
              variant={viewMode === 'matrix' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('matrix')}
            >
              <Icon name="Grid3X3" size={16} className="mr-1" />
              Matrix
            </Button>
          </div>
        </div>

        {/* Search */}
        <Input
          type="search"
          placeholder="Search business functions, teams..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="mb-4"
        />

        {/* Team Legend */}
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-muted-foreground">Team Abbreviations</h3>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries({
              'CS': 'Cyber Security',
              'CA': 'Control Automation',
              'CoA': 'Control Architecture',
              'ITP': 'IT Production',
              'ITO': 'IT Operations'
            }).map(([abbr, full]) => (
              <div key={abbr} className="flex items-center space-x-2">
                <span className={`
                  px-2 py-1 text-xs font-medium rounded-full border
                  ${teamColors[abbr]}
                `}>
                  {abbr}
                </span>
                <span className="text-xs text-muted-foreground truncate">
                  {full}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tree Content */}
      <div className="flex-1 overflow-y-auto p-2">
        {viewMode === 'hierarchical' ? (
          <div className="space-y-1">
            {filteredData.map(node => renderTreeNode(node))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            <Icon name="Grid3X3" size={48} className="mx-auto mb-4 opacity-50" />
            <p>Matrix view coming soon</p>
          </div>
        )}
      </div>

      {/* Footer Stats */}
      <div className="p-4 border-t border-border bg-muted/30">
        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-foreground">177+</div>
            <div className="text-xs text-muted-foreground">Business Functions</div>
          </div>
          <div>
            <div className="text-lg font-semibold text-foreground">25</div>
            <div className="text-xs text-muted-foreground">Teams</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrganizationalTree;