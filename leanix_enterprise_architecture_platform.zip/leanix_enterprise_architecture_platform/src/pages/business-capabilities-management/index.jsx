import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '../../components/ui/Header';
import Sidebar from '../../components/ui/Sidebar';
import OrganizationalTree from './components/OrganizationalTree';
import NodeDetailsPanel from './components/NodeDetailsPanel';
import ToolbarActions from './components/ToolbarActions';
import Icon from '../../components/AppIcon';
import businessCapabilitiesService from '../../services/businessCapabilitiesService';

const BusinessCapabilitiesManagement = () => {
  const [selectedNode, setSelectedNode] = useState(null);
  const [expandedNodes, setExpandedNodes] = useState(['admin-div', 'commercial-div']);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedNodes, setSelectedNodes] = useState([]);
  const [currentFilters, setCurrentFilters] = useState({
    division: 'all',
    teamType: 'all'
  });
  const [organizationalData, setOrganizationalData] = useState([]);
  const [statistics, setStatistics] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load organizational data from SQLite
  useEffect(() => {
    loadOrganizationalData();
    loadStatistics();
  }, []);

  const loadOrganizationalData = async () => {
    try {
      setLoading(true);
      const data = await businessCapabilitiesService.getOrganizationalData();
      setOrganizationalData(data);
      setError(null);
    } catch (err) {
      console.error('Failed to load organizational data:', err);
      setError('Failed to load organizational data');
    } finally {
      setLoading(false);
    }
  };

  const loadStatistics = async () => {
    try {
      const stats = await businessCapabilitiesService.getStatistics();
      setStatistics(stats);
    } catch (err) {
      console.error('Failed to load statistics:', err);
    }
  };

  const handleNodeSelect = (node) => {
    setSelectedNode(node);
  };

  const handleToggleExpand = (nodeId) => {
    setExpandedNodes(prev => 
      prev.includes(nodeId) 
        ? prev.filter(id => id !== nodeId)
        : [...prev, nodeId]
    );
  };

  const handleSearchChange = (query) => {
    setSearchQuery(query);
  };

  const handleCreateNode = async (nodeData) => {
    try {
      console.log('Creating node:', nodeData);
      
      let result;
      switch (nodeData.type) {
        case 'division':
          result = await businessCapabilitiesService.createDivision(nodeData);
          break;
        case 'group':
          result = await businessCapabilitiesService.createGroup(nodeData);
          break;
        case 'team':
          result = await businessCapabilitiesService.createTeam(nodeData);
          break;
        default:
          throw new Error('Invalid node type');
      }

      // Reload data after creation
      await loadOrganizationalData();
      await loadStatistics();
      
      return result;
    } catch (err) {
      console.error('Error creating node:', err);
      setError('Failed to create node');
    }
  };

  const handleUpdateNode = async (updatedNode) => {
    try {
      console.log('Updating node:', updatedNode);
      
      let result;
      switch (updatedNode.type) {
        case 'division':
          result = await businessCapabilitiesService.updateDivision(updatedNode.id, updatedNode);
          break;
        case 'group':
          result = await businessCapabilitiesService.updateGroup(updatedNode.id, updatedNode);
          break;
        case 'team':
          result = await businessCapabilitiesService.updateTeam(updatedNode.id, updatedNode);
          break;
        default:
          throw new Error('Invalid node type');
      }

      // Reload data after update
      await loadOrganizationalData();
      
      // Update selected node if it was the one being edited
      if (selectedNode?.id === updatedNode.id) {
        setSelectedNode(updatedNode);
      }
      
      return result;
    } catch (err) {
      console.error('Error updating node:', err);
      setError('Failed to update node');
    }
  };

  const handleDeleteNode = async (nodeId, nodeType) => {
    try {
      if (!window.confirm('Are you sure you want to delete this node? This action cannot be undone.')) {
        return;
      }

      console.log('Deleting node:', nodeId, nodeType);
      
      let result;
      switch (nodeType) {
        case 'division':
          result = await businessCapabilitiesService.deleteDivision(nodeId);
          break;
        case 'group':
          result = await businessCapabilitiesService.deleteGroup(nodeId);
          break;
        case 'team':
          result = await businessCapabilitiesService.deleteTeam(nodeId);
          break;
        default:
          throw new Error('Invalid node type');
      }

      // Reload data after deletion
      await loadOrganizationalData();
      await loadStatistics();
      
      // Clear selected node if it was deleted
      if (selectedNode?.id === nodeId) {
        setSelectedNode(null);
      }
      
      return result;
    } catch (err) {
      console.error('Error deleting node:', err);
      setError('Failed to delete node');
    }
  };

  const handleBulkAction = async (action, nodes) => {
    try {
      console.log('Bulk action:', action, 'on nodes:', nodes);
      
      const nodeIds = nodes.map(node => node.id);
      
      switch (action) {
        case 'delete':
          if (!window.confirm(`Are you sure you want to delete ${nodes.length} nodes? This action cannot be undone.`)) {
            return;
          }
          await businessCapabilitiesService.bulkDeleteTeams(nodeIds);
          break;
        case 'update_status':
          await businessCapabilitiesService.bulkUpdateTeams(nodeIds, { status: 'active' });
          break;
        default:
          console.warn('Unknown bulk action:', action);
      }

      // Reload data after bulk action
      await loadOrganizationalData();
      await loadStatistics();
      
      // Clear selections
      setSelectedNodes([]);
    } catch (err) {
      console.error('Error performing bulk action:', err);
      setError('Failed to perform bulk action');
    }
  };

  const handleExport = (format, filters) => {
    console.log('Exporting in format:', format, 'with filters:', filters);
    // Implementation for export functionality
    // This could export to CSV, JSON, or other formats
  };

  const handleFilterChange = (filterType, value) => {
    if (filterType === 'reset') {
      setCurrentFilters({ division: 'all', teamType: 'all' });
    } else {
      setCurrentFilters(prev => ({ ...prev, [filterType]: value }));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Sidebar />
        <main className="pt-16 lg:ml-64">
          <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Loading organizational data...</p>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <Sidebar />
        <main className="pt-16 lg:ml-64">
          <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
            <div className="text-center">
              <Icon name="AlertCircle" size={48} className="text-error mx-auto mb-4" />
              <p className="text-error mb-4">{error}</p>
              <button
                onClick={() => loadOrganizationalData()}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90"
              >
                Retry
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <Sidebar />
      
      <main className="pt-16 lg:ml-64">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="h-[calc(100vh-4rem)] flex flex-col"
        >
          {/* Page Header */}
          <div className="bg-card border-b border-border p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-foreground mb-2">
                  Business Capabilities Management
                </h1>
                <p className="text-muted-foreground">
                  Visualize and manage organizational structure across business functions, divisions, and teams
                </p>
              </div>
              <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                <div className="text-center">
                  <div className="text-lg font-semibold text-foreground">{statistics?.totalFunctions || 0}+</div>
                  <div>Business Functions</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-semibold text-foreground">{statistics?.totalTeams || 0}</div>
                  <div>Teams</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-semibold text-foreground">{statistics?.totalDivisions || 0}</div>
                  <div>Divisions</div>
                </div>
              </div>
            </div>
          </div>

          {/* Toolbar */}
          <ToolbarActions
            onCreateNode={handleCreateNode}
            onBulkAction={handleBulkAction}
            onExport={handleExport}
            selectedNodes={selectedNodes}
            currentFilters={currentFilters}
            onFilterChange={handleFilterChange}
          />

          {/* Main Content */}
          <div className="flex-1 flex overflow-hidden">
            {/* Left Panel - Organizational Tree */}
            <div className="w-full lg:w-2/5 xl:w-1/3">
              <OrganizationalTree
                organizationalData={organizationalData}
                selectedNode={selectedNode}
                onNodeSelect={handleNodeSelect}
                expandedNodes={expandedNodes}
                onToggleExpand={handleToggleExpand}
                searchQuery={searchQuery}
                onSearchChange={handleSearchChange}
              />
            </div>

            {/* Right Panel - Node Details */}
            <div className="hidden lg:block lg:w-3/5 xl:w-2/3">
              <NodeDetailsPanel
                selectedNode={selectedNode}
                onUpdateNode={handleUpdateNode}
                onDeleteNode={handleDeleteNode}
              />
            </div>
          </div>

          {/* Mobile Node Details Modal */}
          {selectedNode && (
            <div className="lg:hidden fixed inset-0 bg-black/50 z-100 flex items-end">
              <motion.div
                initial={{ y: '100%' }}
                animate={{ y: 0 }}
                exit={{ y: '100%' }}
                className="bg-card rounded-t-lg w-full h-3/4 overflow-hidden"
              >
                <div className="flex items-center justify-between p-4 border-b border-border">
                  <h2 className="text-lg font-semibold text-foreground">Node Details</h2>
                  <button
                    onClick={() => setSelectedNode(null)}
                    className="p-2 hover:bg-muted rounded-lg enterprise-transition"
                  >
                    <Icon name="X" size={20} />
                  </button>
                </div>
                <div className="h-full overflow-y-auto">
                  <NodeDetailsPanel
                    selectedNode={selectedNode}
                    onUpdateNode={handleUpdateNode}
                    onDeleteNode={handleDeleteNode}
                  />
                </div>
              </motion.div>
            </div>
          )}
        </motion.div>
      </main>
    </div>
  );
};

export default BusinessCapabilitiesManagement;