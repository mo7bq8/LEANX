import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
// Add your imports here
import PlatformDashboard from "pages/platform-dashboard";
import BusinessCapabilitiesManagement from "pages/business-capabilities-management";
import ApplicationArchitecture from "pages/application-architecture";
import ArchitectureRelationships from "pages/architecture-relationships";
import TechnologyArchitecture from "pages/technology-architecture";
import SecurityArchitecture from "pages/security-architecture";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your routes here */}
        <Route path="/" element={<PlatformDashboard />} />
        <Route path="/platform-dashboard" element={<PlatformDashboard />} />
        <Route path="/business-capabilities-management" element={<BusinessCapabilitiesManagement />} />
        <Route path="/application-architecture" element={<ApplicationArchitecture />} />
        <Route path="/architecture-relationships" element={<ArchitectureRelationships />} />
        <Route path="/technology-architecture" element={<TechnologyArchitecture />} />
        <Route path="/security-architecture" element={<SecurityArchitecture />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;