import fs from 'fs';
import path from 'path';
import { format } from 'date-fns';

class BackupService {
  constructor() {
    this.backupDir = path.join(process.cwd(), 'backups');
    this.dbPath = path.join(process.cwd(), 'data', 'enterprise_architecture.db');
    this.maxBackups = 12; // Keep 12 weekly backups (3 months)
    this.init();
  }

  init() {
    // Ensure backup directory exists
    if (!fs.existsSync(this.backupDir)) {
      fs.mkdirSync(this.backupDir, { recursive: true });
    }

    // Schedule weekly backups (every Sunday at 2 AM)
    this.scheduleWeeklyBackup();
  }

  async createBackup() {
    try {
      const timestamp = format(new Date(), 'yyyy-MM-dd_HH-mm-ss');
      const backupFileName = `enterprise_architecture_backup_${timestamp}.db`;
      const backupPath = path.join(this.backupDir, backupFileName);

      // Copy database file
      if (fs.existsSync(this.dbPath)) {
        fs.copyFileSync(this.dbPath, backupPath);
        
        // Create backup metadata
        const metadataPath = path.join(this.backupDir, `${backupFileName}.meta`);
        const metadata = {
          createdAt: new Date().toISOString(),
          originalPath: this.dbPath,
          backupPath: backupPath,
          size: fs.statSync(backupPath).size,
          checksum: await this.calculateChecksum(backupPath)
        };
        
        fs.writeFileSync(metadataPath, JSON.stringify(metadata, null, 2));
        
        console.log(`Backup created successfully: ${backupFileName}`);
        
        // Cleanup old backups
        await this.cleanupOldBackups();
        
        return {
          success: true,
          backupPath,
          metadata
        };
      } else {
        throw new Error('Database file not found');
      }
    } catch (error) {
      console.error('Backup creation failed:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async restoreBackup(backupFileName) {
    try {
      const backupPath = path.join(this.backupDir, backupFileName);
      
      if (!fs.existsSync(backupPath)) {
        throw new Error('Backup file not found');
      }

      // Create current database backup before restore
      const currentBackupName = `pre_restore_${format(new Date(), 'yyyy-MM-dd_HH-mm-ss')}.db`;
      const currentBackupPath = path.join(this.backupDir, currentBackupName);
      
      if (fs.existsSync(this.dbPath)) {
        fs.copyFileSync(this.dbPath, currentBackupPath);
      }

      // Restore from backup
      fs.copyFileSync(backupPath, this.dbPath);
      
      console.log(`Database restored from: ${backupFileName}`);
      
      return {
        success: true,
        restoredFrom: backupFileName,
        currentBackup: currentBackupName
      };
    } catch (error) {
      console.error('Backup restoration failed:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  async listBackups() {
    try {
      const files = fs.readdirSync(this.backupDir);
      const backups = files
        .filter(file => file.endsWith('.db') && file.includes('backup'))
        .map(file => {
          const filePath = path.join(this.backupDir, file);
          const stats = fs.statSync(filePath);
          const metadataPath = path.join(this.backupDir, `${file}.meta`);
          
          let metadata = {};
          if (fs.existsSync(metadataPath)) {
            try {
              metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf8'));
            } catch (e) {
              console.warn(`Failed to read metadata for ${file}`);
            }
          }

          return {
            fileName: file,
            path: filePath,
            size: stats.size,
            createdAt: stats.birthtime,
            modifiedAt: stats.mtime,
            metadata
          };
        })
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

      return backups;
    } catch (error) {
      console.error('Failed to list backups:', error);
      return [];
    }
  }

  async cleanupOldBackups() {
    try {
      const backups = await this.listBackups();
      
      if (backups.length > this.maxBackups) {
        const backupsToDelete = backups.slice(this.maxBackups);
        
        for (const backup of backupsToDelete) {
          fs.unlinkSync(backup.path);
          
          // Delete metadata file if exists
          const metadataPath = `${backup.path}.meta`;
          if (fs.existsSync(metadataPath)) {
            fs.unlinkSync(metadataPath);
          }
          
          console.log(`Deleted old backup: ${backup.fileName}`);
        }
      }
    } catch (error) {
      console.error('Failed to cleanup old backups:', error);
    }
  }

  async calculateChecksum(filePath) {
    return new Promise((resolve, reject) => {
      const crypto = require('crypto');
      const hash = crypto.createHash('sha256');
      const stream = fs.createReadStream(filePath);
      
      stream.on('data', data => hash.update(data));
      stream.on('end', () => resolve(hash.digest('hex')));
      stream.on('error', reject);
    });
  }

  scheduleWeeklyBackup() {
    // Calculate time until next Sunday 2 AM
    const now = new Date();
    const nextSunday = new Date();
    nextSunday.setDate(now.getDate() + (7 - now.getDay())); // Next Sunday
    nextSunday.setHours(2, 0, 0, 0); // 2 AM

    // If it's already past 2 AM on Sunday, schedule for next week
    if (now.getDay() === 0 && now.getHours() >= 2) {
      nextSunday.setDate(nextSunday.getDate() + 7);
    }

    const timeUntilBackup = nextSunday.getTime() - now.getTime();

    setTimeout(() => {
      this.createBackup();
      // Schedule next weekly backup
      setInterval(() => {
        this.createBackup();
      }, 7 * 24 * 60 * 60 * 1000); // Weekly interval
    }, timeUntilBackup);

    console.log(`Next automatic backup scheduled for: ${nextSunday.toISOString()}`);
  }

  // Manual backup trigger
  async triggerManualBackup() {
    console.log('Triggering manual backup...');
    return await this.createBackup();
  }

  // Get backup statistics
  async getBackupStats() {
    try {
      const backups = await this.listBackups();
      const totalSize = backups.reduce((sum, backup) => sum + backup.size, 0);
      
      return {
        totalBackups: backups.length,
        totalSize,
        latestBackup: backups.length > 0 ? backups[0] : null,
        oldestBackup: backups.length > 0 ? backups[backups.length - 1] : null
      };
    } catch (error) {
      console.error('Failed to get backup stats:', error);
      return {
        totalBackups: 0,
        totalSize: 0,
        latestBackup: null,
        oldestBackup: null
      };
    }
  }
}

// Create singleton instance
const backupService = new BackupService();

export default backupService;