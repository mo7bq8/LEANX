import Database from 'better-sqlite3';
import path from 'path';

class SQLiteDatabase {
  constructor() {
    this.db = null;
    this.dbPath = path.join(process.cwd(), 'data', 'enterprise_architecture.db');
    this.init();
  }

  init() {
    try {
      // Ensure data directory exists
      const fs = require('fs');
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      this.db = new Database(this.dbPath);
      this.db.pragma('journal_mode = WAL');
      this.db.pragma('foreign_keys = ON');
      
      this.createTables();
      this.seedInitialData();
      
      console.log('SQLite database initialized successfully');
    } catch (error) {
      console.error('Database initialization error:', error);
      throw error;
    }
  }

  createTables() {
    // Business Capabilities tables
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS divisions (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT DEFAULT 'division',
        count INTEGER DEFAULT 0,
        status TEXT DEFAULT 'active',
        description TEXT,
        total_functions INTEGER DEFAULT 0,
        active_teams INTEGER DEFAULT 0,
        applications INTEGER DEFAULT 0,
        processes INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS groups (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT DEFAULT 'group',
        count INTEGER DEFAULT 0,
        division_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (division_id) REFERENCES divisions (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS teams (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT DEFAULT 'team',
        abbreviation TEXT,
        count INTEGER DEFAULT 0,
        group_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (group_id) REFERENCES groups (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS team_assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id TEXT,
        team TEXT,
        role TEXT,
        members INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS business_processes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team_id TEXT,
        name TEXT NOT NULL,
        category TEXT,
        criticality TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (team_id) REFERENCES teams (id) ON DELETE CASCADE
      )
    `);

    // Applications tables
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS applications (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT,
        ics_level TEXT,
        app_group TEXT,
        business_process TEXT,
        vendor TEXT,
        status TEXT DEFAULT 'Production',
        business_impact TEXT,
        technical_risk TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS application_teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id TEXT,
        name TEXT,
        abbreviation TEXT,
        role TEXT,
        responsibility TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (application_id) REFERENCES applications (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS application_technologies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id TEXT,
        name TEXT,
        category TEXT,
        version TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (application_id) REFERENCES applications (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS application_security_controls (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id TEXT,
        name TEXT,
        type TEXT,
        status TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (application_id) REFERENCES applications (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS application_relationships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        application_id TEXT,
        target_application TEXT,
        type TEXT,
        direction TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (application_id) REFERENCES applications (id) ON DELETE CASCADE
      )
    `);

    // Technologies tables
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS technologies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        category TEXT,
        version TEXT,
        vendor TEXT,
        license_type TEXT,
        support_level TEXT,
        cost_center TEXT,
        installation_date DATETIME,
        end_of_life DATE,
        last_updated DATETIME,
        updated_by TEXT,
        description TEXT,
        status TEXT DEFAULT 'Production',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS technology_teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        technology_id INTEGER,
        team TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (technology_id) REFERENCES technologies (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS technology_business_functions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        technology_id INTEGER,
        business_function TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (technology_id) REFERENCES technologies (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS technology_dependencies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        technology_id INTEGER,
        dependency_name TEXT,
        dependency_type TEXT, -- 'dependsOn' or 'usedBy'
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (technology_id) REFERENCES technologies (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS technology_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        technology_id INTEGER,
        action TEXT,
        description TEXT,
        date DATETIME,
        user TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (technology_id) REFERENCES technologies (id) ON DELETE CASCADE
      )
    `);

    // Security components tables
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS security_components (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        category TEXT,
        criticality TEXT,
        environment TEXT,
        team_ownership TEXT,
        ics_level TEXT,
        risk_score INTEGER,
        last_updated DATE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS security_dependencies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        security_component_id INTEGER,
        dependency_name TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (security_component_id) REFERENCES security_components (id) ON DELETE CASCADE
      )
    `);

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS security_audit_trail (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        security_component_id INTEGER,
        action TEXT,
        user TEXT,
        timestamp DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (security_component_id) REFERENCES security_components (id) ON DELETE CASCADE
      )
    `);

    // Relationships tables
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS relationships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_type TEXT, -- 'application', 'technology', 'security', 'business'
        source_id TEXT,
        target_type TEXT,
        target_id TEXT,
        relationship_type TEXT,
        strength INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Create indices for better performance
    this.db.exec(`
      CREATE INDEX IF NOT EXISTS idx_groups_division_id ON groups (division_id);
      CREATE INDEX IF NOT EXISTS idx_teams_group_id ON teams (group_id);
      CREATE INDEX IF NOT EXISTS idx_applications_status ON applications (status);
      CREATE INDEX IF NOT EXISTS idx_technologies_category ON technologies (category);
      CREATE INDEX IF NOT EXISTS idx_security_components_criticality ON security_components (criticality);
      CREATE INDEX IF NOT EXISTS idx_relationships_source ON relationships (source_type, source_id);
      CREATE INDEX IF NOT EXISTS idx_relationships_target ON relationships (target_type, target_id);
    `);
  }

  seedInitialData() {
    // Check if data already exists
    const existingData = this.db.prepare('SELECT COUNT(*) as count FROM divisions').get();
    if (existingData.count > 0) {
      return; // Data already seeded
    }

    // Begin transaction for data seeding
    const transaction = this.db.transaction(() => {
      // Seed divisions
      const insertDivision = this.db.prepare(`
        INSERT INTO divisions (id, name, type, count, status, description, total_functions, active_teams, applications, processes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      insertDivision.run(
        'admin-div',
        'Admin Division',
        'division',
        89,
        'active',
        'Administrative and support functions division managing corporate operations and governance.',
        89,
        12,
        34,
        156
      );

      insertDivision.run(
        'commercial-div',
        'Commercial Division',
        'division',
        88,
        'active',
        'Commercial operations division managing sales, marketing, and customer-facing business functions.',
        88,
        13,
        52,
        203
      );

      // Seed groups
      const insertGroup = this.db.prepare(`
        INSERT INTO groups (id, name, type, count, division_id)
        VALUES (?, ?, ?, ?, ?)
      `);

      insertGroup.run('admin-hr-group', 'Human Resources Group', 'group', 23, 'admin-div');
      insertGroup.run('admin-finance-group', 'Finance & Accounting Group', 'group', 34, 'admin-div');
      insertGroup.run('admin-legal-group', 'Legal & Compliance Group', 'group', 32, 'admin-div');
      insertGroup.run('commercial-sales-group', 'Sales & Marketing Group', 'group', 45, 'commercial-div');
      insertGroup.run('commercial-customer-group', 'Customer Success Group', 'group', 43, 'commercial-div');

      // Seed teams
      const insertTeam = this.db.prepare(`
        INSERT INTO teams (id, name, type, abbreviation, count, group_id)
        VALUES (?, ?, ?, ?, ?, ?)
      `);

      insertTeam.run('hr-cs-team', 'HR Cyber Security Team', 'team', 'CS', 8, 'admin-hr-group');
      insertTeam.run('hr-ca-team', 'HR Control Automation Team', 'team', 'CA', 6, 'admin-hr-group');
      insertTeam.run('hr-coa-team', 'HR Control Architecture Team', 'team', 'CoA', 9, 'admin-hr-group');
      insertTeam.run('finance-itp-team', 'Finance IT Production Team', 'team', 'ITP', 12, 'admin-finance-group');
      insertTeam.run('finance-ito-team', 'Finance IT Operations Team', 'team', 'ITO', 22, 'admin-finance-group');

      // Seed applications with comprehensive data
      const insertApplication = this.db.prepare(`
        INSERT INTO applications (id, name, description, ics_level, app_group, business_process, vendor, status, business_impact, technical_risk)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      insertApplication.run(
        'APP001',
        'Maximo Asset Management',
        'Comprehensive asset lifecycle management system for industrial equipment and infrastructure maintenance',
        '4',
        'Operations',
        'Asset Management',
        'IBM Maximo',
        'Production',
        'Critical',
        'Low'
      );

      insertApplication.run(
        'APP002',
        'Oracle Process Manufacturing',
        'Advanced process control and optimization platform for chemical and pharmaceutical manufacturing operations',
        '3.7',
        'Engineering',
        'Process Control',
        'Oracle',
        'Production',
        'High',
        'Medium'
      );

      // Continue seeding other sample data...
      console.log('Initial data seeded successfully');
    });

    transaction();
  }

  // Generic CRUD operations
  create(table, data) {
    try {
      const columns = Object.keys(data);
      const placeholders = columns.map(() => '?').join(', ');
      const sql = `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders})`;
      const stmt = this.db.prepare(sql);
      const result = stmt.run(...Object.values(data));
      return { id: result.lastInsertRowid, ...data };
    } catch (error) {
      console.error(`Error creating record in ${table}:`, error);
      throw error;
    }
  }

  read(table, conditions = {}, options = {}) {
    try {
      let sql = `SELECT * FROM ${table}`;
      const values = [];

      if (Object.keys(conditions).length > 0) {
        const whereClause = Object.keys(conditions)
          .map(key => `${key} = ?`)
          .join(' AND ');
        sql += ` WHERE ${whereClause}`;
        values.push(...Object.values(conditions));
      }

      if (options.orderBy) {
        sql += ` ORDER BY ${options.orderBy}`;
        if (options.orderDirection) {
          sql += ` ${options.orderDirection}`;
        }
      }

      if (options.limit) {
        sql += ` LIMIT ${options.limit}`;
      }

      const stmt = this.db.prepare(sql);
      return options.single ? stmt.get(...values) : stmt.all(...values);
    } catch (error) {
      console.error(`Error reading from ${table}:`, error);
      throw error;
    }
  }

  update(table, id, data) {
    try {
      const columns = Object.keys(data);
      const setClause = columns.map(col => `${col} = ?`).join(', ');
      const sql = `UPDATE ${table} SET ${setClause}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`;
      const stmt = this.db.prepare(sql);
      const result = stmt.run(...Object.values(data), id);
      return result.changes > 0;
    } catch (error) {
      console.error(`Error updating record in ${table}:`, error);
      throw error;
    }
  }

  delete(table, id) {
    try {
      const sql = `DELETE FROM ${table} WHERE id = ?`;
      const stmt = this.db.prepare(sql);
      const result = stmt.run(id);
      return result.changes > 0;
    } catch (error) {
      console.error(`Error deleting record from ${table}:`, error);
      throw error;
    }
  }

  // Custom queries with joins
  executeCustomQuery(sql, params = []) {
    try {
      const stmt = this.db.prepare(sql);
      return stmt.all(...params);
    } catch (error) {
      console.error('Error executing custom query:', error);
      throw error;
    }
  }

  // Close database connection
  close() {
    if (this.db) {
      this.db.close();
    }
  }

  // Get database instance for complex operations
  getDB() {
    return this.db;
  }
}

// Create singleton instance
const database = new SQLiteDatabase();

export default database;